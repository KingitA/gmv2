export interface Proveedor {
  id: string
  nombre: string
  sigla?: string
  codigo_proveedor?: string
  email?: string
  telefono?: string
  direccion?: string
  codigo_postal?: string
  localidad?: string
  codigo_provincia?: string
  telefono_oficina?: string
  telefono_vendedor?: string
  mail_vendedor?: string
  mail_oficina?: string
  cuit?: string
  categoria_iva?: string
  tipo_iva?: number // 1-9 según tabla
  condicion_pago?: "CC" | "E" // CC=Cuenta Corriente, E=Contado
  dias_vencimiento?: number // días para calcular vencimiento
  tipo_proveedor?: "mercaderia_general" | "servicios"
  banco_nombre?: string
  banco_cuenta?: string
  banco_numero_cuenta?: string
  banco_tipo_cuenta?: string
  tipo_pago?: string[]
  plazo_pago?: string
  retencion_iibb?: number
  retencion_ganancias?: number
  percepcion_iva?: number
  percepcion_iibb?: number
  activo: boolean
  created_at: string
  updated_at: string
}

export interface Articulo {
  id: string
  sku: string
  sigla?: string // 2 dígitos
  ean13?: string
  descripcion: string
  proveedor_id?: string
  proveedor?: Proveedor
  rubro?: "limpieza" | "perfumeria" | "bazar"
  categoria?: string
  subcategoria?: string
  unidad_medida: "unidad" | "bulto"
  unidades_por_bulto: number
  stock_actual: number
  precio_compra: number
  descuento1: number
  descuento2: number
  descuento3: number
  descuento4: number
  activo: boolean
  created_at: string
  updated_at: string
}

export interface PrecioCompraHistorial {
  id: string
  articulo_id: string
  proveedor_id: string
  precio_compra: number
  descuento1: number
  descuento2: number
  descuento3: number
  descuento4: number
  fecha_desde: string
  fecha_hasta?: string
}

export interface Devolucion {
  id: string
  comprobante_id: string
  articulo_codigo: string
  articulo_descripcion: string
  cantidad: number
  motivo: string
  estado: "pendiente" | "procesada" | "cancelada"
  tipo_nota: "NC" | "Reversa"
  created_at: string
  updated_at: string
}
