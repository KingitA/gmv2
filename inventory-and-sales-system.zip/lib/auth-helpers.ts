import { createClient } from "@/lib/supabase/server"

export async function getUserWithRoles(userId: string) {
  const supabase = await createClient()
  
  const { data, error } = await supabase
    .from('usuarios')
    .select(`
      id,
      email,
      nombre,
      telefono,
      estado,
      usuarios_roles(
        roles(
          nombre,
          descripcion
        )
      )
    `)
    .eq('id', userId)
    .single()

  if (error || !data) {
    return null
  }

  const roles = data.usuarios_roles?.map((ur: any) => ur.roles.nombre) || []
  
  return {
    ...data,
    roles
  }
}

export async function hasRole(userId: string, roleName: string): Promise<boolean> {
  const user = await getUserWithRoles(userId)
  return user?.roles?.includes(roleName) || false
}

export async function hasAnyRole(userId: string, roleNames: string[]): Promise<boolean> {
  const user = await getUserWithRoles(userId)
  return roleNames.some(role => user?.roles?.includes(role)) || false
}

export async function requireRole(userId: string, roleName: string) {
  const hasRequiredRole = await hasRole(userId, roleName)
  
  if (!hasRequiredRole) {
    throw new Error(`Usuario no tiene el rol requerido: ${roleName}`)
  }
  
  return true
}

export async function getVendedorInfo(userId: string) {
  const supabase = await createClient()
  
  const { data, error } = await supabase
    .from('vendedores_info')
    .select('*')
    .eq('usuario_id', userId)
    .single()

  return error ? null : data
}

export async function getClienteInfo(userId: string) {
  const supabase = await createClient()
  
  const { data, error } = await supabase
    .from('clientes_info')
    .select('*')
    .eq('usuario_id', userId)
    .single()

  return error ? null : data
}
