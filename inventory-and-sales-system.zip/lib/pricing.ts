// Sistema completo de cálculo de precios
// Incluye costos, márgenes, fletes, recargos e impuestos

import { createClient } from "@/lib/supabase/server"

// Tipos
export interface ArticuloPrecio {
  id: string
  descripcion: string
  precio_compra: number
  descuento1: number
  descuento2: number
  descuento3: number
  descuento4: number
  porcentaje_ganancia: number
  iva_compras: "factura" | "adquisicion_stock" | "mixto"
  iva_ventas: "factura" | "presupuesto"
  proveedor_id: string
  categoria: string
}

export interface ProveedorPrecio {
  id: string
  tipo_descuento: "cascada" | "sobre_lista"
  percepcion_iva: number
  percepcion_iibb: number
  retencion_ganancias: number
  retencion_iibb: number
}

export interface ClientePrecio {
  id: string
  nivel_puntaje: "PREMIUM" | "REGULAR" | "RIESGO" | "CRITICO"
  retira_en_deposito: boolean
  exento_iva: boolean
  exento_iibb: boolean
  percepcion_iibb: number
  vendedor_id: string
  nombre: string
}

export interface VendedorPrecio {
  id: string
  comision_perfumeria: number
  comision_bazar_limpieza: number
  nombre: string
}

export interface TransportePrecio {
  porcentaje_flete: number
}

export interface ConfiguracionPrecios {
  porcentaje_gastos_operativos: number
  iva_compras_porcentaje: number
  iva_ventas_porcentaje: number
  iva_mixto_porcentaje: number
}

export interface DesglosePrecio {
  // Costos
  precio_lista: number
  descuento1_monto: number
  descuento2_monto: number
  descuento3_monto: number
  descuento4_monto: number
  costo_bruto: number
  iva_compras_monto: number
  flete_compra_monto: number
  costo_final: number

  // Precio Base
  ganancia_monto: number
  gastos_operativos_monto: number
  precio_base: number

  // Precio Venta
  flete_venta_monto: number
  recargo_puntaje_porcentaje: number
  recargo_puntaje_monto: number
  precio_antes_comision: number
  comision_vendedor_porcentaje: number
  comision_vendedor_monto: number
  precio_venta_neto: number

  // Precio Final
  impuestos_monto: number
  tipo_impuesto: string
  precio_final: number
  precio_final_redondeado: number
}

// Constantes
const GASTOS_OPERATIVOS_DEFAULT = 3.0
const IVA_COMPRAS_DEFAULT = 21.0
const IVA_VENTAS_DEFAULT = 21.0
const IVA_MIXTO_DEFAULT = 10.5

// Función auxiliar para redondear
function redondear(valor: number): number {
  return Math.round(valor)
}

// PASO 1: Calcular Costo Bruto
export function calcularCostoBruto(
  precioLista: number,
  descuentos: { d1: number; d2: number; d3: number; d4: number },
  tipoDescuento: "cascada" | "sobre_lista",
): { costoBruto: number; desglose: any } {
  let precio = precioLista
  const desglose = {
    precio_lista: precioLista,
    descuento1_monto: 0,
    descuento2_monto: 0,
    descuento3_monto: 0,
    descuento4_monto: 0,
  }

  if (tipoDescuento === "cascada") {
    // Descuentos en cascada
    if (descuentos.d1 > 0) {
      desglose.descuento1_monto = precio * (descuentos.d1 / 100)
      precio = precio * (1 - descuentos.d1 / 100)
    }
    if (descuentos.d2 > 0) {
      desglose.descuento2_monto = precio * (descuentos.d2 / 100)
      precio = precio * (1 - descuentos.d2 / 100)
    }
    if (descuentos.d3 > 0) {
      desglose.descuento3_monto = precio * (descuentos.d3 / 100)
      precio = precio * (1 - descuentos.d3 / 100)
    }
  } else {
    // Descuentos sobre precio lista
    const descuentoTotal = descuentos.d1 + descuentos.d2 + descuentos.d3
    if (descuentoTotal > 0) {
      const montoDescuento = precioLista * (descuentoTotal / 100)
      desglose.descuento1_monto = precioLista * (descuentos.d1 / 100)
      desglose.descuento2_monto = precioLista * (descuentos.d2 / 100)
      desglose.descuento3_monto = precioLista * (descuentos.d3 / 100)
      precio = precioLista - montoDescuento
    }
  }

  // Descuento 4 (fuera de factura) siempre se aplica sobre el precio actual
  if (descuentos.d4 > 0) {
    desglose.descuento4_monto = precio * (descuentos.d4 / 100)
    precio = precio * (1 - descuentos.d4 / 100)
  }

  return {
    costoBruto: precio,
    desglose,
  }
}

// PASO 2: Calcular Costo Final
export function calcularCostoFinal(
  costoBruto: number,
  ivaComprasPorcentaje: number,
  fletePorcentaje: number,
  proveedor: ProveedorPrecio,
): { costoFinal: number; desglose: any } {
  // Flete se calcula sobre el costo bruto (antes de impuestos)
  const fleteMonto = costoBruto * (fletePorcentaje / 100)

  // IVA se calcula sobre el costo bruto
  const ivaMonto = costoBruto * (ivaComprasPorcentaje / 100)

  // Percepciones y retenciones
  const percepcionIvaMonto = costoBruto * (proveedor.percepcion_iva / 100)
  const percepcionIibbMonto = costoBruto * (proveedor.percepcion_iibb / 100)
  const retencionGananciasMonto = costoBruto * (proveedor.retencion_ganancias / 100)
  const retencionIibbMonto = costoBruto * (proveedor.retencion_iibb / 100)

  const costoFinal =
    costoBruto +
    ivaMonto +
    percepcionIvaMonto +
    percepcionIibbMonto +
    retencionGananciasMonto +
    retencionIibbMonto +
    fleteMonto

  return {
    costoFinal,
    desglose: {
      costo_bruto: costoBruto,
      iva_compras_monto: ivaMonto,
      percepcion_iva_monto: percepcionIvaMonto,
      percepcion_iibb_monto: percepcionIibbMonto,
      retencion_ganancias_monto: retencionGananciasMonto,
      retencion_iibb_monto: retencionIibbMonto,
      flete_compra_monto: fleteMonto,
    },
  }
}

// PASO 3: Calcular Precio Base
export function calcularPrecioBase(
  costoBruto: number,
  porcentajeGanancia: number,
  porcentajeGastosOperativos: number = GASTOS_OPERATIVOS_DEFAULT,
): { precioBase: number; desglose: any } {
  const gananciaMonto = costoBruto * (porcentajeGanancia / 100)
  const gastosOperativosMonto = costoBruto * (porcentajeGastosOperativos / 100)
  const precioBase = costoBruto + gananciaMonto + gastosOperativosMonto

  return {
    precioBase,
    desglose: {
      ganancia_monto: gananciaMonto,
      gastos_operativos_monto: gastosOperativosMonto,
    },
  }
}

// PASO 4: Calcular Precio Venta
export function calcularPrecioVenta(
  precioBase: number,
  cliente: ClientePrecio,
  vendedor: VendedorPrecio,
  fletePorcentaje: number,
  categoriaArticulo: string,
): { precioVentaNeto: number; desglose: any } {
  // Flete de venta (0% si retira en depósito)
  const fleteVentaMonto = cliente.retira_en_deposito ? 0 : precioBase * (fletePorcentaje / 100)

  // Recargo por puntaje del cliente
  let recargoPorcentaje = 0
  switch (cliente.nivel_puntaje) {
    case "PREMIUM":
      recargoPorcentaje = 0 // Sin recargo, flete bonificado
      break
    case "REGULAR":
      recargoPorcentaje = 0 // Sin recargo
      break
    case "RIESGO":
      recargoPorcentaje = 5 // +5% recargo
      break
    case "CRITICO":
      recargoPorcentaje = 15 // +15% recargo
      break
  }

  const recargoPuntajeMonto = precioBase * (recargoPorcentaje / 100)

  // Precio antes de comisión
  const precioAntesComision = precioBase + fleteVentaMonto + recargoPuntajeMonto

  // Comisión del vendedor (según categoría)
  const comisionPorcentaje =
    categoriaArticulo === "PERFUMERIA" ? vendedor.comision_perfumeria : vendedor.comision_bazar_limpieza

  // Dividir por (1 - comisión%) para incluir la comisión en el precio
  const precioVentaNeto = precioAntesComision / (1 - comisionPorcentaje / 100)
  const comisionMonto = precioVentaNeto - precioAntesComision

  return {
    precioVentaNeto,
    desglose: {
      flete_venta_monto: fleteVentaMonto,
      recargo_puntaje_porcentaje: recargoPorcentaje,
      recargo_puntaje_monto: recargoPuntajeMonto,
      precio_antes_comision: precioAntesComision,
      comision_vendedor_porcentaje: comisionPorcentaje,
      comision_vendedor_monto: comisionMonto,
    },
  }
}

// PASO 5: Calcular Precio Final (con impuestos)
export function calcularPrecioFinal(
  precioVentaNeto: number,
  articulo: ArticuloPrecio,
  cliente: ClientePrecio,
  config: ConfiguracionPrecios,
): { precioFinal: number; precioFinalRedondeado: number; desglose: any } {
  let impuestosMonto = 0
  let tipoImpuesto = ""

  // Determinar qué impuestos aplicar según la matriz
  if (articulo.iva_compras === "factura" && articulo.iva_ventas === "factura") {
    // +21% IVA discriminado + ret + percep
    if (!cliente.exento_iva) {
      impuestosMonto += precioVentaNeto * (config.iva_ventas_porcentaje / 100)
    }
    if (!cliente.exento_iibb) {
      impuestosMonto += precioVentaNeto * (cliente.percepcion_iibb / 100)
    }
    tipoImpuesto = "IVA 21% discriminado + percepciones"
  } else if (articulo.iva_compras === "factura" && articulo.iva_ventas === "presupuesto") {
    // +21% IVA incluido
    const precioConIva = precioVentaNeto * (1 + config.iva_ventas_porcentaje / 100)
    impuestosMonto = precioConIva - precioVentaNeto
    tipoImpuesto = "IVA 21% incluido"
  } else if (articulo.iva_compras === "adquisicion_stock" && articulo.iva_ventas === "factura") {
    // +21% IVA discriminado + ret + percep
    if (!cliente.exento_iva) {
      impuestosMonto += precioVentaNeto * (config.iva_ventas_porcentaje / 100)
    }
    if (!cliente.exento_iibb) {
      impuestosMonto += precioVentaNeto * (cliente.percepcion_iibb / 100)
    }
    tipoImpuesto = "IVA 21% discriminado + percepciones"
  } else if (articulo.iva_compras === "adquisicion_stock" && articulo.iva_ventas === "presupuesto") {
    // Sin impuestos
    impuestosMonto = 0
    tipoImpuesto = "Sin impuestos"
  } else if (articulo.iva_compras === "mixto" && articulo.iva_ventas === "factura") {
    // +21% IVA discriminado + ret + percep
    if (!cliente.exento_iva) {
      impuestosMonto += precioVentaNeto * (config.iva_ventas_porcentaje / 100)
    }
    if (!cliente.exento_iibb) {
      impuestosMonto += precioVentaNeto * (cliente.percepcion_iibb / 100)
    }
    tipoImpuesto = "IVA 21% discriminado + percepciones"
  } else if (articulo.iva_compras === "mixto" && articulo.iva_ventas === "presupuesto") {
    // +10.5% IVA incluido
    const precioConIva = precioVentaNeto * (1 + config.iva_mixto_porcentaje / 100)
    impuestosMonto = precioConIva - precioVentaNeto
    tipoImpuesto = "IVA 10.5% incluido"
  }

  const precioFinal = precioVentaNeto + impuestosMonto
  const precioFinalRedondeado = redondear(precioFinal)

  return {
    precioFinal,
    precioFinalRedondeado,
    desglose: {
      impuestos_monto: impuestosMonto,
      tipo_impuesto: tipoImpuesto,
    },
  }
}

// Función principal que calcula todo el desglose
export async function calcularPrecioCompleto(articuloId: string, clienteId: string): Promise<DesglosePrecio> {
  const supabase = await createClient()

  console.log("[v0] Calculando precio para artículo:", articuloId, "cliente:", clienteId)

  // Obtener artículo con proveedor y categoría
  const { data: articulo, error: errorArticulo } = await supabase
    .from("articulos")
    .select(`
      *,
      proveedor:proveedores(*),
      categoria:categorias(nombre)
    `)
    .eq("id", articuloId)
    .single()

  if (errorArticulo || !articulo) {
    console.error("[v0] Error obteniendo artículo:", errorArticulo)
    throw new Error("Artículo no encontrado")
  }

  // Obtener cliente con vendedor, localidad y zona
  const { data: cliente, error: errorCliente } = await supabase
    .from("clientes")
    .select(`
      *,
      vendedor:vendedores(*),
      localidad:localidades(
        id,
        nombre,
        zona:zonas(
          id,
          nombre,
          tipo_flete,
          porcentaje_flete,
          transporte:transportes(porcentaje_flete)
        )
      )
    `)
    .eq("id", clienteId)
    .single()

  if (errorCliente || !cliente) {
    console.error("[v0] Error obteniendo cliente:", errorCliente)
    throw new Error("Cliente no encontrado")
  }

  // Obtener configuración de precios
  let { data: config, error: errorConfig } = await supabase.from("configuracion_precios").select("*").limit(1).single()

  if (errorConfig || !config) {
    console.error("[v0] Error obteniendo configuración:", errorConfig)
    // Usar valores por defecto si no existe configuración
    config = {
      porcentaje_gastos_operativos: 3.0,
      iva_compras_porcentaje: 21.0,
      iva_ventas_porcentaje: 21.0,
      iva_mixto_porcentaje: 10.5,
    }
  }

  // Obtener porcentaje de flete de venta desde la zona del cliente
  let fletePorcentaje = 0
  if (cliente.localidad?.zona) {
    const zona = cliente.localidad.zona
    if (zona.tipo_flete === "transporte" && zona.transporte) {
      fletePorcentaje = zona.transporte.porcentaje_flete || 0
    } else if (zona.tipo_flete === "propio") {
      fletePorcentaje = zona.porcentaje_flete || 0
    }
  }

  console.log("[v0] Flete de venta:", fletePorcentaje, "%")

  // PASO 1: Costo Bruto
  const { costoBruto, desglose: desgloseCostoBruto } = calcularCostoBruto(
    articulo.precio_compra || 0,
    {
      d1: articulo.descuento1 || 0,
      d2: articulo.descuento2 || 0,
      d3: articulo.descuento3 || 0,
      d4: articulo.descuento4 || 0,
    },
    articulo.proveedor?.tipo_descuento || "cascada",
  )

  // PASO 2: Costo Final
  const { costoFinal, desglose: desgloseCostoFinal } = calcularCostoFinal(
    costoBruto,
    config.iva_compras_porcentaje,
    0, // Flete de compra (no se usa en este flujo)
    articulo.proveedor || {
      id: "",
      percepcion_iva: 0,
      percepcion_iibb: 0,
      retencion_ganancias: 0,
      retencion_iibb: 0,
    },
  )

  // PASO 3: Precio Base
  const { precioBase, desglose: desglosePrecioBase } = calcularPrecioBase(
    costoBruto,
    articulo.porcentaje_ganancia || 20,
    config.porcentaje_gastos_operativos,
  )

  // PASO 4: Precio Venta
  const categoriaNombre = articulo.categoria?.nombre || articulo.categoria || "BAZAR Y LIMPIEZA"
  const { precioVentaNeto, desglose: desglosePrecioVenta } = calcularPrecioVenta(
    precioBase,
    {
      id: cliente.id,
      nivel_puntaje: cliente.nivel_puntaje || "REGULAR",
      retira_en_deposito: cliente.retira_en_deposito || false,
      exento_iva: cliente.exento_iva || false,
      exento_iibb: cliente.exento_iibb || false,
      percepcion_iibb: cliente.percepcion_iibb || 0,
      vendedor_id: cliente.vendedor_id,
    },
    cliente.vendedor || {
      id: "",
      comision_perfumeria: 0,
      comision_bazar_limpieza: 0,
    },
    fletePorcentaje,
    categoriaNombre,
  )

  // PASO 5: Precio Final
  const {
    precioFinal,
    precioFinalRedondeado,
    desglose: desglosePrecioFinal,
  } = calcularPrecioFinal(
    precioVentaNeto,
    {
      id: articulo.id,
      descripcion: articulo.descripcion,
      precio_compra: articulo.precio_compra,
      descuento1: articulo.descuento1,
      descuento2: articulo.descuento2,
      descuento3: articulo.descuento3,
      descuento4: articulo.descuento4,
      porcentaje_ganancia: articulo.porcentaje_ganancia,
      iva_compras: articulo.iva_compras || "factura",
      iva_ventas: articulo.iva_ventas || "factura",
      proveedor_id: articulo.proveedor_id,
    },
    {
      id: cliente.id,
      nivel_puntaje: cliente.nivel_puntaje || "REGULAR",
      retira_en_deposito: cliente.retira_en_deposito || false,
      exento_iva: cliente.exento_iva || false,
      exento_iibb: cliente.exento_iibb || false,
      percepcion_iibb: cliente.percepcion_iibb || 0,
      vendedor_id: cliente.vendedor_id,
    },
    config,
  )

  console.log("[v0] Precio final calculado:", precioFinalRedondeado)

  // Retornar desglose completo
  return {
    ...desgloseCostoBruto,
    costo_bruto: costoBruto,
    ...desgloseCostoFinal,
    costo_final: costoFinal,
    ...desglosePrecioBase,
    precio_base: precioBase,
    ...desglosePrecioVenta,
    precio_venta_neto: precioVentaNeto,
    ...desglosePrecioFinal,
    precio_final: precioFinal,
    precio_final_redondeado: precioFinalRedondeado,
  }
}

// Función para calcular precios de todos los artículos para un cliente
export async function calcularPreciosCatalogo(clienteId: string): Promise<any[]> {
  const supabase = await createClient()

  // Obtener todos los artículos activos
  const { data: articulos } = await supabase.from("articulos").select("id, descripcion, categoria").eq("activo", true)

  if (!articulos) return []

  // Calcular precio de cada artículo
  const precios = await Promise.all(
    articulos.map(async (articulo) => {
      try {
        const desglose = await calcularPrecioCompleto(articulo.id, clienteId)
        return {
          articulo_id: articulo.id,
          descripcion: articulo.descripcion,
          categoria: articulo.categoria,
          precio_final: desglose.precio_final_redondeado,
          desglose,
        }
      } catch (error) {
        console.error(`Error calculando precio para artículo ${articulo.id}:`, error)
        return null
      }
    }),
  )

  return precios.filter(Boolean)
}
