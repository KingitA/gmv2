import Link from "next/link"
import { Card, CardDescription, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
import {
  Package,
  Users,
  ShoppingBag,
  Table2,
  FileText,
  ClipboardList,
  DollarSign,
  CreditCard,
  RotateCcw,
  Truck,
  Calendar,
  AlertCircle,
} from "lucide-react"
import { createClient } from "@supabase/supabase-js"

// Función para obtener datos del resumen
async function getResumenData() {
  const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!)

  const fechaHoy = new Date().toISOString().split("T")[0]
  const fecha7Dias = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split("T")[0]

  const { data: viajes } = await supabase
    .from("viajes")
    .select(`
      id,
      fecha,
      estado,
      chofer,
      nombre,
      zona:zonas(nombre)
    `)
    .gte("fecha", fechaHoy)
    .lte("fecha", fecha7Dias)
    .in("estado", ["programado", "en_preparacion", "pendiente"])
    .order("fecha", { ascending: true })
    .limit(5)

  // Pedidos pendientes
  const { data: pedidosPendientes, count: totalPedidosPendientes } = await supabase
    .from("pedidos")
    .select("id, numero_pedido, fecha, total, cliente:clientes(nombre_razon_social)", { count: "exact" })
    .in("estado", ["pendiente", "en_preparacion"])
    .order("fecha", { ascending: true })
    .limit(5)

  const { data: saldosProveedores } = await supabase
    .from("comprobantes_compra")
    .select(`
      id,
      numero_comprobante,
      fecha_vencimiento,
      total_factura_declarado,
      saldo_pendiente,
      proveedor:proveedores(nombre)
    `)
    .gt("saldo_pendiente", 0)
    .not("fecha_vencimiento", "is", null)
    .order("fecha_vencimiento", { ascending: true })
    .limit(5)

  return {
    viajes: viajes || [],
    pedidosPendientes: pedidosPendientes || [],
    totalPedidosPendientes: totalPedidosPendientes || 0,
    saldosProveedores: saldosProveedores || [],
  }
}

export default async function HomePage() {
  const { viajes, pedidosPendientes, totalPedidosPendientes, saldosProveedores } = await getResumenData()

  return (
    <div className="container mx-auto px-6 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-neutral-900 mb-2">PANEL DE CONTROL</h1>
        <p className="text-neutral-600">Gestiona tu inventario, compras y ventas desde un solo lugar</p>
      </div>

      {/* Tarjetas principales: Proveedores, Clientes, Artículos, Tablas */}
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4 mb-8">
        <Link href="/proveedores" className="group">
          <Card className="transition-all duration-200 hover:shadow-lg hover:scale-105 cursor-pointer border-l-4 border-l-blue-500 h-full">
            <CardHeader>
              <div className="flex items-start justify-between mb-3">
                <div className="p-3 bg-blue-50 rounded-lg group-hover:bg-blue-100 transition-colors">
                  <ShoppingBag className="h-6 w-6 text-blue-600" />
                </div>
              </div>
              <CardTitle className="text-xl mb-2">PROVEEDORES</CardTitle>
              <CardDescription className="text-sm">
                Gestiona proveedores, órdenes de compra y comprobantes
              </CardDescription>
            </CardHeader>
          </Card>
        </Link>

        <Link href="/clientes" className="group">
          <Card className="transition-all duration-200 hover:shadow-lg hover:scale-105 cursor-pointer border-l-4 border-l-green-500 h-full">
            <CardHeader>
              <div className="flex items-start justify-between mb-3">
                <div className="p-3 bg-green-50 rounded-lg group-hover:bg-green-100 transition-colors">
                  <Users className="h-6 w-6 text-green-600" />
                </div>
              </div>
              <CardTitle className="text-xl mb-2">CLIENTES</CardTitle>
              <CardDescription className="text-sm">Administra clientes, pedidos, viajes y facturación</CardDescription>
            </CardHeader>
          </Card>
        </Link>

        <Link href="/articulos" className="group">
          <Card className="transition-all duration-200 hover:shadow-lg hover:scale-105 cursor-pointer border-l-4 border-l-purple-500 h-full">
            <CardHeader>
              <div className="flex items-start justify-between mb-3">
                <div className="p-3 bg-purple-50 rounded-lg group-hover:bg-purple-100 transition-colors">
                  <Package className="h-6 w-6 text-purple-600" />
                </div>
              </div>
              <CardTitle className="text-xl mb-2">ARTÍCULOS</CardTitle>
              <CardDescription className="text-sm">Catálogo de productos, stock y precios</CardDescription>
            </CardHeader>
          </Card>
        </Link>

        <Link href="/tablas" className="group">
          <Card className="transition-all duration-200 hover:shadow-lg hover:scale-105 cursor-pointer border-l-4 border-l-orange-500 h-full">
            <CardHeader>
              <div className="flex items-start justify-between mb-3">
                <div className="p-3 bg-orange-50 rounded-lg group-hover:bg-orange-100 transition-colors">
                  <Table2 className="h-6 w-6 text-orange-600" />
                </div>
              </div>
              <CardTitle className="text-xl mb-2">TABLAS</CardTitle>
              <CardDescription className="text-sm">Viajantes, transportes, zonas y localidades</CardDescription>
            </CardHeader>
          </Card>
        </Link>
      </div>

      {/* Accesos Rápidos: Órdenes de compra, Pedidos, $Precios, Revisión pagos, Revisión devoluciones */}
      <div className="mb-8">
        <h2 className="text-xl font-bold text-neutral-900 mb-4">ACCESOS RÁPIDOS</h2>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-5">
          <Link href="/ordenes-compra" className="group">
            <Card className="hover:shadow-md transition-shadow border-neutral-200">
              <CardHeader className="p-4">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-blue-100 rounded-lg group-hover:bg-blue-200 transition-colors">
                    <FileText className="h-5 w-5 text-blue-600" />
                  </div>
                  <div>
                    <CardTitle className="text-sm font-semibold">ÓRDENES DE COMPRA</CardTitle>
                    <CardDescription className="text-xs">Gestionar compras</CardDescription>
                  </div>
                </div>
              </CardHeader>
            </Card>
          </Link>

          <Link href="/clientes-pedidos" className="group">
            <Card className="hover:shadow-md transition-shadow border-neutral-200">
              <CardHeader className="p-4">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-green-100 rounded-lg group-hover:bg-green-200 transition-colors">
                    <ClipboardList className="h-5 w-5 text-green-600" />
                  </div>
                  <div>
                    <CardTitle className="text-sm font-semibold">PEDIDOS</CardTitle>
                    <CardDescription className="text-xs">Gestionar pedidos</CardDescription>
                  </div>
                </div>
              </CardHeader>
            </Card>
          </Link>

          <Link href="/articulos/consulta-precios" className="group">
            <Card className="hover:shadow-md transition-shadow border-neutral-200">
              <CardHeader className="p-4">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-amber-100 rounded-lg group-hover:bg-amber-200 transition-colors">
                    <DollarSign className="h-5 w-5 text-amber-600" />
                  </div>
                  <div>
                    <CardTitle className="text-sm font-semibold">$PRECIOS</CardTitle>
                    <CardDescription className="text-xs">Consultar precios</CardDescription>
                  </div>
                </div>
              </CardHeader>
            </Card>
          </Link>

          <Link href="/revision-pagos" className="group">
            <Card className="hover:shadow-md transition-shadow border-neutral-200">
              <CardHeader className="p-4">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-purple-100 rounded-lg group-hover:bg-purple-200 transition-colors">
                    <CreditCard className="h-5 w-5 text-purple-600" />
                  </div>
                  <div>
                    <CardTitle className="text-sm font-semibold">REVISIÓN PAGOS</CardTitle>
                    <CardDescription className="text-xs">Confirmar pagos</CardDescription>
                  </div>
                </div>
              </CardHeader>
            </Card>
          </Link>

          <Link href="/revision-devoluciones" className="group">
            <Card className="hover:shadow-md transition-shadow border-neutral-200">
              <CardHeader className="p-4">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-red-100 rounded-lg group-hover:bg-red-200 transition-colors">
                    <RotateCcw className="h-5 w-5 text-red-600" />
                  </div>
                  <div>
                    <CardTitle className="text-sm font-semibold">REVISIÓN DEVOLUCIONES</CardTitle>
                    <CardDescription className="text-xs">Confirmar devoluciones</CardDescription>
                  </div>
                </div>
              </CardHeader>
            </Card>
          </Link>
        </div>
      </div>

      {/* Resumen: Próximos viajes, Pedidos pendientes, Saldos a vencer */}
      <div>
        <h2 className="text-xl font-bold text-neutral-900 mb-4">RESUMEN</h2>
        <div className="grid gap-6 md:grid-cols-3">
          {/* Próximos Viajes */}
          <Card className="border-neutral-200">
            <CardHeader className="pb-2">
              <div className="flex items-center gap-2">
                <div className="p-2 bg-blue-50 rounded-lg">
                  <Truck className="h-5 w-5 text-blue-600" />
                </div>
                <CardTitle className="text-base">PRÓXIMOS VIAJES</CardTitle>
              </div>
            </CardHeader>
            <CardContent className="pt-2">
              {viajes.length > 0 ? (
                <div className="space-y-2">
                  {viajes.map((viaje: any) => (
                    <div
                      key={viaje.id}
                      className="flex items-center justify-between p-2 bg-neutral-50 rounded-lg text-sm"
                    >
                      <div className="flex items-center gap-2">
                        <Calendar className="h-4 w-4 text-neutral-500" />
                        <span className="font-medium">
                          {new Date(viaje.fecha).toLocaleDateString("es-AR", { day: "2-digit", month: "2-digit" })}
                        </span>
                      </div>
                      <span className="text-neutral-600 truncate max-w-[120px]">
                        {viaje.chofer || viaje.nombre || viaje.zona?.nombre || "Sin asignar"}
                      </span>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-neutral-500 text-center py-4">No hay viajes próximos</p>
              )}
              <Link href="/viajes" className="block mt-3 text-xs text-primary hover:underline text-center">
                Ver todos los viajes
              </Link>
            </CardContent>
          </Card>

          {/* Pedidos Pendientes */}
          <Card className="border-neutral-200">
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="p-2 bg-green-50 rounded-lg">
                    <ClipboardList className="h-5 w-5 text-green-600" />
                  </div>
                  <CardTitle className="text-base">PEDIDOS PENDIENTES</CardTitle>
                </div>
                <span className="text-2xl font-bold text-green-600">{totalPedidosPendientes}</span>
              </div>
            </CardHeader>
            <CardContent className="pt-2">
              {pedidosPendientes.length > 0 ? (
                <div className="space-y-2">
                  {pedidosPendientes.map((pedido: any) => (
                    <div
                      key={pedido.id}
                      className="flex items-center justify-between p-2 bg-neutral-50 rounded-lg text-sm"
                    >
                      <div>
                        <span className="font-medium">#{pedido.numero_pedido}</span>
                        <p className="text-xs text-neutral-500 truncate max-w-[120px]">
                          {pedido.cliente?.nombre_razon_social}
                        </p>
                      </div>
                      <span className="font-semibold text-neutral-900">
                        ${pedido.total?.toLocaleString("es-AR") || "0"}
                      </span>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-neutral-500 text-center py-4">No hay pedidos pendientes</p>
              )}
              <Link href="/clientes-pedidos" className="block mt-3 text-xs text-primary hover:underline text-center">
                Ver todos los pedidos
              </Link>
            </CardContent>
          </Card>

          {/* Saldos a Vencer de Proveedores */}
          <Card className="border-neutral-200">
            <CardHeader className="pb-2">
              <div className="flex items-center gap-2">
                <div className="p-2 bg-amber-50 rounded-lg">
                  <AlertCircle className="h-5 w-5 text-amber-600" />
                </div>
                <CardTitle className="text-base">SALDOS A VENCER</CardTitle>
              </div>
            </CardHeader>
            <CardContent className="pt-2">
              {saldosProveedores.length > 0 ? (
                <div className="space-y-2">
                  {saldosProveedores.map((comp: any) => (
                    <div
                      key={comp.id}
                      className="flex items-center justify-between p-2 bg-neutral-50 rounded-lg text-sm"
                    >
                      <div>
                        <span className="font-medium truncate max-w-[100px] block">
                          {comp.proveedor?.nombre || "N/A"}
                        </span>
                        <p className="text-xs text-neutral-500">
                          Vence:{" "}
                          {comp.fecha_vencimiento
                            ? new Date(comp.fecha_vencimiento).toLocaleDateString("es-AR", {
                                day: "2-digit",
                                month: "2-digit",
                              })
                            : "S/F"}
                        </p>
                      </div>
                      <span className="font-semibold text-amber-600">
                        ${comp.saldo_pendiente?.toLocaleString("es-AR") || "0"}
                      </span>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-neutral-500 text-center py-4">No hay saldos pendientes</p>
              )}
              <Link href="/proveedores" className="block mt-3 text-xs text-primary hover:underline text-center">
                Ver cuenta corriente
              </Link>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
