import { createClient } from "@/lib/supabase/server"
import { type NextRequest, NextResponse } from "next/server"

export async function GET(request: NextRequest) {
  try {
    const supabase = await createClient()
    const { searchParams } = new URL(request.url)
    const estado = searchParams.get("estado") || "pendiente"

    const { data: pagos, error } = await supabase
      .from("pagos_clientes")
      .select(
        `
        *,
        clientes(nombre, razon_social),
        vendedor:usuarios!pagos_clientes_vendedor_id_fkey(nombre)
      `
      )
      .eq("estado", estado)
      .order("created_at", { ascending: false })

    if (error) throw error

    // Obtener detalle de cada pago (formas de pago)
    const pagosConDetalle = await Promise.all(
      (pagos || []).map(async (pago) => {
        const { data: detalles } = await supabase.from("pagos_detalle").select("*").eq("pago_id", pago.id)

        return {
          ...pago,
          detalles: detalles || [],
        }
      })
    )

    return NextResponse.json(pagosConDetalle)
  } catch (error: any) {
    console.error("[v0] Error obteniendo pagos:", error)
    return NextResponse.json({ error: error.message || "Error obteniendo pagos" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const supabase = await createClient()
    const body = await request.json()

    const {
      cliente_id,
      vendedor_id,
      fecha_pago,
      observaciones,
      detalles, // [{ tipo_pago, monto, numero_cheque?, banco?, fecha_cheque? }]
      imputaciones, // [{ comprobante_id, monto_imputado }] - opcional
    } = body

    // Validaciones
    if (!cliente_id || !detalles || detalles.length === 0) {
      return NextResponse.json({ error: "cliente_id y detalles son requeridos" }, { status: 400 })
    }

    // Calcular monto total
    const montoTotal = detalles.reduce((sum: number, d: any) => sum + Number(d.monto), 0)

    if (montoTotal <= 0) {
      return NextResponse.json({ error: "El monto total debe ser mayor a 0" }, { status: 400 })
    }

    // Crear pago en estado pendiente
    const { data: pago, error: pagoError } = await supabase
      .from("pagos_clientes")
      .insert({
        cliente_id,
        vendedor_id,
        monto: montoTotal,
        fecha_pago: fecha_pago || new Date().toISOString().split("T")[0],
        observaciones,
        estado: "pendiente",
      })
      .select()
      .single()

    if (pagoError) throw pagoError

    // Crear detalles del pago (formas de pago)
    const detallesConPagoId = detalles.map((d: any) => ({
      pago_id: pago.id,
      tipo_pago: d.tipo_pago,
      monto: d.monto,
      numero_cheque: d.numero_cheque || null,
      banco: d.banco || null,
      fecha_cheque: d.fecha_cheque || null,
    }))

    const { error: detallesError } = await supabase.from("pagos_detalle").insert(detallesConPagoId)

    if (detallesError) throw detallesError

    if (imputaciones && imputaciones.length > 0) {
      const imputacionesData = imputaciones.map((imp: any) => ({
        pago_id: pago.id,
        comprobante_id: imp.comprobante_id,
        tipo_comprobante: "venta",
        monto_imputado: imp.monto_imputado,
        estado: "pendiente", // Se confirmará junto con el pago
      }))

      const { error: impError } = await supabase.from("imputaciones").insert(imputacionesData)

      if (impError) {
        console.error("[v0] Error guardando imputaciones:", impError)
      }
    }

    return NextResponse.json({
      success: true,
      pago,
      mensaje: "Pago registrado. Pendiente de confirmación por el ERP.",
    })
  } catch (error: any) {
    console.error("[v0] Error registrando pago:", error)
    return NextResponse.json({ error: error.message || "Error registrando pago" }, { status: 500 })
  }
}
