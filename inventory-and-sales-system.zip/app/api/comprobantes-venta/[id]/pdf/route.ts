import { createServerClient } from "@supabase/ssr"
import { cookies } from "next/headers"
import { NextResponse } from "next/server"

export async function GET(request: Request, { params }: { params: { id: string } }) {
  try {
    const cookieStore = await cookies()
    const supabase = createServerClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!, {
      cookies: {
        get(name: string) {
          return cookieStore.get(name)?.value
        },
      },
    })

    const comprobanteId = params.id

    // Obtener comprobante con todos los datos
    const { data: comprobante, error: comprobanteError } = await supabase
      .from("comprobantes_venta")
      .select(
        `
        *,
        cliente:clientes!comprobantes_venta_cliente_id_fkey(
          nombre_razon_social,
          cuit,
          direccion,
          condicion_iva
        ),
        pedido:pedidos!comprobantes_venta_pedido_id_fkey(
          numero_pedido
        ),
        detalle:comprobantes_venta_detalle(
          *,
          articulo:articulos!comprobantes_venta_detalle_articulo_id_fkey(
            descripcion,
            sku
          )
        )
      `,
      )
      .eq("id", comprobanteId)
      .single()

    if (comprobanteError || !comprobante) {
      console.error("[v0] Error obteniendo comprobante:", comprobanteError)
      return NextResponse.json({ error: "Comprobante no encontrado" }, { status: 404 })
    }

    const { data: empresaArray } = await supabase.from("configuracion_empresa").select("*").limit(1)

    const empresa = empresaArray?.[0] || {
      razon_social: "CIA DE HIGIENE TOTAL S.R.L",
      cuit: "30-71234567-8",
      direccion: "Dirección de la empresa",
      telefono: "Teléfono",
      email: "info@empresa.com",
      condicion_iva: "Responsable Inscripto",
    }

    // Generar HTML del PDF
    const html = generarHTMLComprobante(comprobante, empresa)

    return new NextResponse(html, {
      headers: {
        "Content-Type": "application/pdf",
        "Content-Disposition": `attachment; filename="Comprobante-${comprobante.numero_comprobante}.pdf"`,
      },
    })
  } catch (error: any) {
    console.error("[v0] Error generando PDF:", error)
    return NextResponse.json({ error: error.message || "Error generando PDF" }, { status: 500 })
  }
}

function generarHTMLComprobante(comprobante: any, empresa: any): string {
  const tipoComprobante = {
    FA: "FACTURA A",
    FB: "FACTURA B",
    FC: "FACTURA C",
    NCA: "NOTA DE CRÉDITO A",
    NCB: "NOTA DE CRÉDITO B",
    NCC: "NOTA DE CRÉDITO C",
    PRES: "PRESUPUESTO",
    REM: "REMITO",
    REV: "REVERSA",
  }[comprobante.tipo_comprobante]

  const detalleHTML = comprobante.detalle
    ?.map(
      (item: any, index: number) => `
    <tr style="border-bottom: 1px solid #e5e7eb;">
      <td style="padding: 8px; text-align: center;">${item.articulo?.sku || "-"}</td>
      <td style="padding: 8px;">${item.descripcion || item.articulo?.descripcion}</td>
      <td style="padding: 8px; text-align: center;">${item.cantidad}</td>
      <td style="padding: 8px; text-align: right;">$${item.precio_unitario?.toFixed(2)}</td>
      <td style="padding: 8px; text-align: right; font-weight: 600;">$${item.precio_total?.toFixed(2)}</td>
    </tr>
  `,
    )
    .join("")

  const mostrarIVA = comprobante.tipo_comprobante === "FA" || comprobante.tipo_comprobante === "FB"

  return `
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${tipoComprobante} ${comprobante.numero_comprobante}</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 20px;
      font-size: 12px;
    }
    .container {
      max-width: 800px;
      margin: 0 auto;
      border: 2px solid #000;
      padding: 20px;
    }
    .header {
      display: flex;
      justify-content: space-between;
      border-bottom: 2px solid #000;
      padding-bottom: 15px;
      margin-bottom: 15px;
    }
    .empresa {
      flex: 1;
    }
    .tipo-comprobante {
      width: 100px;
      text-align: center;
      border: 2px solid #000;
      padding: 10px;
      font-size: 24px;
      font-weight: bold;
    }
    .datos-comprobante {
      flex: 1;
      text-align: right;
    }
    .cliente-section {
      border: 1px solid #000;
      padding: 10px;
      margin-bottom: 15px;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      margin: 15px 0;
    }
    th {
      background-color: #f3f4f6;
      padding: 10px;
      text-align: left;
      border: 1px solid #000;
      font-weight: bold;
    }
    td {
      padding: 8px;
      border: 1px solid #e5e7eb;
    }
    .totales {
      margin-top: 20px;
      text-align: right;
    }
    .totales table {
      margin-left: auto;
      width: 300px;
    }
    .total-final {
      font-size: 16px;
      font-weight: bold;
      background-color: #f3f4f6;
    }
    .footer {
      margin-top: 30px;
      padding-top: 15px;
      border-top: 1px solid #000;
      font-size: 10px;
      text-align: center;
    }
  </style>
</head>
<body>
  <div class="container">
    <!-- HEADER -->
    <div class="header">
      <div class="empresa">
        <h2 style="margin: 0;">${empresa?.razon_social || "CIA DE HIGIENE TOTAL S.R.L"}</h2>
        <p style="margin: 5px 0;">CUIT: ${empresa?.cuit || "30-71234567-8"}</p>
        <p style="margin: 5px 0;">${empresa?.direccion || "Dirección de la empresa"}</p>
        <p style="margin: 5px 0;">Tel: ${empresa?.telefono || "-"}</p>
        <p style="margin: 5px 0;">${empresa?.condicion_iva || "Responsable Inscripto"}</p>
      </div>
      
      <div class="tipo-comprobante">
        ${comprobante.tipo_comprobante.charAt(comprobante.tipo_comprobante.length - 1) || "X"}
      </div>
      
      <div class="datos-comprobante">
        <h3 style="margin: 0;">${tipoComprobante}</h3>
        <p style="margin: 5px 0;"><strong>Nº:</strong> ${comprobante.numero_comprobante}</p>
        <p style="margin: 5px 0;"><strong>Fecha:</strong> ${new Date(comprobante.fecha).toLocaleDateString()}</p>
        ${comprobante.pedido ? `<p style="margin: 5px 0;"><strong>Pedido:</strong> ${comprobante.pedido.numero_pedido}</p>` : ""}
      </div>
    </div>

    <!-- DATOS DEL CLIENTE -->
    <div class="cliente-section">
      <h4 style="margin: 0 0 10px 0;">DATOS DEL CLIENTE</h4>
      <p style="margin: 3px 0;"><strong>Razón Social:</strong> ${comprobante.cliente?.nombre_razon_social || "Cliente"}</p>
      <p style="margin: 3px 0;"><strong>CUIT:</strong> ${comprobante.cliente?.cuit || "-"}</p>
      <p style="margin: 3px 0;"><strong>Dirección:</strong> ${comprobante.cliente?.direccion || "-"}</p>
      <p style="margin: 3px 0;"><strong>Condición IVA:</strong> ${comprobante.cliente?.condicion_iva || "-"}</p>
    </div>

    <!-- DETALLE DE ITEMS -->
    <table>
      <thead>
        <tr>
          <th style="width: 10%; text-align: center;">Código</th>
          <th style="width: 40%;">Descripción</th>
          <th style="width: 10%; text-align: center;">Cantidad</th>
          <th style="width: 15%; text-align: right;">Precio Unit.</th>
          <th style="width: 15%; text-align: right;">Subtotal</th>
        </tr>
      </thead>
      <tbody>
        ${detalleHTML}
      </tbody>
    </table>

    <!-- TOTALES -->
    <div class="totales">
      <table>
        ${
          mostrarIVA
            ? `
        <tr>
          <td style="padding: 5px; text-align: right;"><strong>Subtotal (Neto):</strong></td>
          <td style="padding: 5px; text-align: right;">$${comprobante.total_neto?.toFixed(2)}</td>
        </tr>
        <tr>
          <td style="padding: 5px; text-align: right;"><strong>IVA 21%:</strong></td>
          <td style="padding: 5px; text-align: right;">$${comprobante.total_iva?.toFixed(2)}</td>
        </tr>
        ${
          comprobante.percepcion_iva > 0
            ? `
        <tr>
          <td style="padding: 5px; text-align: right;"><strong>Percepción IVA:</strong></td>
          <td style="padding: 5px; text-align: right;">$${comprobante.percepcion_iva?.toFixed(2)}</td>
        </tr>
        `
            : ""
        }
        ${
          comprobante.percepcion_iibb > 0
            ? `
        <tr>
          <td style="padding: 5px; text-align: right;"><strong>Percepción IIBB:</strong></td>
          <td style="padding: 5px; text-align: right;">$${comprobante.percepcion_iibb?.toFixed(2)}</td>
        </tr>
        `
            : ""
        }
        `
            : ""
        }
        <tr class="total-final">
          <td style="padding: 10px; text-align: right;"><strong>TOTAL:</strong></td>
          <td style="padding: 10px; text-align: right;"><strong>$${comprobante.total_factura?.toFixed(2)}</strong></td>
        </tr>
      </table>
    </div>

    ${
      comprobante.observaciones
        ? `
    <div style="margin-top: 20px; padding: 10px; border: 1px solid #e5e7eb;">
      <strong>Observaciones:</strong> ${comprobante.observaciones}
    </div>
    `
        : ""
    }

    <!-- FOOTER -->
    <div class="footer">
      <p>Este comprobante fue generado electrónicamente por el Sistema ERP+CRM</p>
      <p>Para consultas: ${empresa?.email || "info@empresa.com"} | Tel: ${empresa?.telefono || "-"}</p>
    </div>
  </div>

  <script>
    // Auto-print cuando se abre
    window.onload = function() {
      // Dar un momento para que se cargue el contenido
      setTimeout(function() {
        window.print();
      }, 500);
    }
  </script>
</body>
</html>
  `
}
