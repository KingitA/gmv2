"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Plus, Pencil, ArrowLeft, Upload, Download, DollarSign, Search, Filter } from "lucide-react"
import Link from "next/link"
import { getSupabase } from "@/lib/supabase"
import type { Articulo, Proveedor } from "@/lib/types"
import * as XLSX from "xlsx"

export default function ArticulosPage() {
  const [articulos, setArticulos] = useState<Articulo[]>([])
  const [proveedores, setProveedores] = useState<Proveedor[]>([])
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [editingArticulo, setEditingArticulo] = useState<Articulo | null>(null)
  const [importing, setImporting] = useState(false)

  const [filtroProveedor, setFiltroProveedor] = useState("all")
  const [filtroRubro, setFiltroRubro] = useState("all")
  const [filtroCategoria, setFiltroCategoria] = useState("")
  const [busqueda, setBusqueda] = useState("")

  useEffect(() => {
    loadArticulos()
    loadProveedores()
  }, [])

  async function loadProveedores() {
    const supabase = getSupabase()
    const { data, error } = await supabase.from("proveedores").select("*").eq("activo", true).order("nombre")

    if (error) {
      console.error("[v0] Error loading proveedores:", error)
      return
    }

    setProveedores(data || [])
  }

  async function loadArticulos() {
    const supabase = getSupabase()

    let allArticulos: any[] = []
    let rangeStart = 0
    const batchSize = 1000
    let hasMore = true

    while (hasMore) {
      const { data, error } = await supabase
        .from("articulos")
        .select("*, proveedor:proveedores(*)")
        .eq("activo", true)
        .order("descripcion")
        .range(rangeStart, rangeStart + batchSize - 1)

      if (error) {
        console.error("[v0] Error loading articulos:", error)
        break
      }

      if (data && data.length > 0) {
        allArticulos = [...allArticulos, ...data]
        rangeStart += batchSize

        // Si se obtuvieron menos registros que el tamaño del lote, ya no hay más
        if (data.length < batchSize) {
          hasMore = false
        }
      } else {
        hasMore = false
      }
    }

    console.log("[v0] Artículos cargados desde BD:", allArticulos.length)
    setArticulos(allArticulos)
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    const supabase = getSupabase()

    const dataToSave = {
      ...formData,
      proveedor_id: formData.proveedor_id || null,
      rubro: formData.rubro || null,
      categoria: formData.categoria || null,
      subcategoria: formData.subcategoria || null,
    }

    if (editingArticulo) {
      const { error } = await supabase.from("articulos").update(dataToSave).eq("id", editingArticulo.id)

      if (error) {
        console.error("[v0] Error updating articulo:", error)
        alert("Error al actualizar artículo")
        return
      }
    } else {
      const { error } = await supabase.from("articulos").insert([dataToSave])

      if (error) {
        console.error("[v0] Error creating articulo:", error)
        alert("Error al crear artículo")
        return
      }
    }

    setIsDialogOpen(false)
    resetForm()
    loadArticulos()
  }

  async function handleDelete(id: string) {
    if (!confirm("¿Está seguro de eliminar este artículo?")) return

    const supabase = getSupabase()
    const { error } = await supabase.from("articulos").update({ activo: false }).eq("id", id)

    if (error) {
      console.error("[v0] Error deleting articulo:", error)
      return
    }

    loadArticulos()
  }

  function resetForm() {
    setFormData({
      sku: "",
      sigla: "",
      ean13: "",
      descripcion: "",
      proveedor_id: "",
      rubro: "",
      categoria: "",
      subcategoria: "",
      unidad_medida: "unidad",
      unidades_por_bulto: 1,
      porcentaje_ganancia: 20,
      iva_compras: "factura",
      iva_ventas: "factura",
    })
    setEditingArticulo(null)
  }

  function openEditDialog(articulo: Articulo) {
    setEditingArticulo(articulo)
    setFormData({
      sku: articulo.sku,
      sigla: articulo.sigla || "",
      ean13: articulo.ean13 || "",
      descripcion: articulo.descripcion,
      proveedor_id: articulo.proveedor_id || "",
      rubro: articulo.rubro || "",
      categoria: articulo.categoria || "",
      subcategoria: articulo.subcategoria || "",
      unidad_medida: articulo.unidad_medida,
      unidades_por_bulto: articulo.unidades_por_bulto || 1,
      porcentaje_ganancia: (articulo as any).porcentaje_ganancia || 20,
      iva_compras: (articulo as any).iva_compras || "factura",
      iva_ventas: (articulo as any).iva_ventas || "factura",
    })
    setIsDialogOpen(true)
  }

  function downloadTemplate() {
    const template = [
      {
        sku: "123456",
        sigla: "AB",
        ean13: "7798123456789",
        descripcion: "Ejemplo Artículo",
        proveedor_codigo: "PROV01",
        rubro: "limpieza",
        categoria: "Limpieza General",
        subcategoria: "Trapos",
        unidad_medida: "bulto",
        unidades_por_bulto: 12,
        stock_actual: 0,
        porcentaje_ganancia: 20,
        iva_compras: "factura",
        iva_ventas: "factura",
      },
    ]

    const ws = XLSX.utils.json_to_sheet(template)
    const wb = XLSX.utils.book_new()
    XLSX.utils.book_append_sheet(wb, ws, "Articulos")

    const wbout = XLSX.write(wb, { bookType: "xlsx", type: "array" })
    const blob = new Blob([wbout], { type: "application/octet-stream" })
    const url = URL.createObjectURL(blob)
    const link = document.createElement("a")
    link.href = url
    link.download = "plantilla_articulos.xlsx"
    link.click()
    URL.revokeObjectURL(url)
  }

  async function handleImport(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]
    if (!file) return

    setImporting(true)

    try {
      const data = await file.arrayBuffer()
      const workbook = XLSX.read(data)
      const worksheet = workbook.Sheets[workbook.SheetNames[0]]
      const jsonData = XLSX.utils.sheet_to_json(worksheet) as Array<{
        sku: string
        sigla?: string
        ean13?: string
        descripcion: string
        proveedor_codigo?: string
        rubro?: string
        categoria?: string
        subcategoria?: string
        unidad_medida?: "unidad" | "bulto"
        stock_actual?: number
        unidades_por_bulto?: number
        porcentaje_ganancia?: number
        iva_compras?: "factura" | "adquisicion_stock" | "mixto"
        iva_ventas?: "factura" | "presupuesto"
      }>

      const supabase = getSupabase()

      const proveedorCodigos = [...new Set(jsonData.map((row) => row.proveedor_codigo).filter(Boolean))]
      let proveedorMap: Record<string, string> = {}

      if (proveedorCodigos.length > 0) {
        const { data: proveedoresData } = await supabase
          .from("proveedores")
          .select("id, codigo_proveedor")
          .in("codigo_proveedor", proveedorCodigos)

        if (proveedoresData) {
          proveedorMap = Object.fromEntries(proveedoresData.map((p) => [p.codigo_proveedor, p.id]))
        }
      }

      const articulosData = jsonData.map((row) => {
        const articulo: any = {
          sku: String(row.sku), // SKU siempre es obligatorio
        }

        // Solo agregar campos que tienen valor en el Excel
        if (row.sigla !== undefined && row.sigla !== null && row.sigla !== "") {
          articulo.sigla = String(row.sigla).toUpperCase()
        }
        if (row.ean13 !== undefined && row.ean13 !== null && row.ean13 !== "") {
          articulo.ean13 = String(row.ean13)
        }
        if (row.descripcion !== undefined && row.descripcion !== null && row.descripcion !== "") {
          articulo.descripcion = row.descripcion
        }
        if (row.proveedor_codigo && proveedorMap[row.proveedor_codigo]) {
          articulo.proveedor_id = proveedorMap[row.proveedor_codigo]
        }
        if (row.rubro !== undefined && row.rubro !== null && row.rubro !== "") {
          articulo.rubro = row.rubro
        }
        if (row.categoria !== undefined && row.categoria !== null && row.categoria !== "") {
          articulo.categoria = row.categoria
        }
        if (row.subcategoria !== undefined && row.subcategoria !== null && row.subcategoria !== "") {
          articulo.subcategoria = row.subcategoria
        }
        if (row.unidad_medida !== undefined && row.unidad_medida !== null && row.unidad_medida !== "") {
          articulo.unidad_medida = row.unidad_medida
        }
        if (row.unidades_por_bulto !== undefined && row.unidades_por_bulto !== null) {
          articulo.unidades_por_bulto = row.unidades_por_bulto
        }
        if (row.stock_actual !== undefined && row.stock_actual !== null) {
          articulo.stock_actual = row.stock_actual
        }
        if (row.porcentaje_ganancia !== undefined && row.porcentaje_ganancia !== null) {
          articulo.porcentaje_ganancia = row.porcentaje_ganancia
        }
        if (row.iva_compras !== undefined && row.iva_compras !== null && row.iva_compras !== "") {
          articulo.iva_compras = row.iva_compras
        }
        if (row.iva_ventas !== undefined && row.iva_ventas !== null && row.iva_ventas !== "") {
          articulo.iva_ventas = row.iva_ventas
        }

        return articulo
      })

      const skuMap = new Map<string, (typeof articulosData)[0]>()
      articulosData.forEach((articulo) => {
        skuMap.set(articulo.sku, articulo)
      })
      const articulosUnicos = Array.from(skuMap.values())

      const duplicadosCount = articulosData.length - articulosUnicos.length
      if (duplicadosCount > 0) {
        console.log(
          `[v0] Se detectaron ${duplicadosCount} SKUs duplicados en el archivo, se mantendrá el último valor de cada uno`,
        )
      }

      const { error } = await supabase.from("articulos").upsert(articulosUnicos, {
        onConflict: "sku",
        ignoreDuplicates: false,
      })

      if (error) {
        console.error("[v0] Error importing articulos:", error.message)
        alert(`Error al importar artículos: ${error.message}`)
      } else {
        const mensaje =
          duplicadosCount > 0
            ? `Se importaron/actualizaron ${articulosUnicos.length} artículos correctamente (se eliminaron ${duplicadosCount} duplicados del archivo)`
            : `Se importaron/actualizaron ${articulosUnicos.length} artículos correctamente`
        alert(mensaje)
        loadArticulos()
      }
    } catch (error) {
      console.error("[v0] Error processing file:", error)
      alert("Error al procesar el archivo. Verifique que sea un archivo Excel válido.")
    } finally {
      setImporting(false)
      e.target.value = ""
    }
  }

  const articulosFiltrados = articulos.filter((art) => {
    const matchProveedor = filtroProveedor === "all" || art.proveedor_id === filtroProveedor
    const matchRubro = filtroRubro === "all" || art.rubro === filtroRubro
    const matchCategoria = !filtroCategoria || art.categoria?.toLowerCase().includes(filtroCategoria.toLowerCase())
    const matchBusqueda =
      !busqueda ||
      art.sku.toLowerCase().includes(busqueda.toLowerCase()) ||
      art.descripcion.toLowerCase().includes(busqueda.toLowerCase())

    return matchProveedor && matchRubro && matchCategoria && matchBusqueda
  })

  console.log("[v0] Artículos filtrados para mostrar:", articulosFiltrados.length) // Agregado log para verificar cuántos artículos se muestran después del filtro

  const [formData, setFormData] = useState({
    sku: "",
    sigla: "",
    ean13: "",
    descripcion: "",
    proveedor_id: "",
    rubro: "",
    categoria: "",
    subcategoria: "",
    unidad_medida: "unidad" as "unidad" | "bulto",
    unidades_por_bulto: 1,
    porcentaje_ganancia: 20,
    iva_compras: "factura" as "factura" | "adquisicion_stock" | "mixto",
    iva_ventas: "factura" as "factura" | "presupuesto",
  })

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-10 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Link href="/">
                <Button variant="ghost" size="icon" className="hover:bg-accent">
                  <ArrowLeft className="h-5 w-5" />
                </Button>
              </Link>
              <div>
                <h1 className="text-2xl font-bold text-foreground">Artículos</h1>
                <p className="text-sm text-muted-foreground">Catálogo de productos</p>
              </div>
            </div>
            <Link href="/articulos/precios">
              <Button variant="outline" className="gap-2 bg-transparent">
                <DollarSign className="h-4 w-4" />
                Gestionar Precios
              </Button>
            </Link>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-6 py-8">
        <Card className="shadow-sm">
          <CardHeader className="border-b bg-muted/30">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
              <div>
                <CardTitle className="text-xl">Catálogo de Artículos</CardTitle>
                <p className="text-sm text-muted-foreground mt-1">
                  {articulosFiltrados.length} artículo{articulosFiltrados.length !== 1 ? "s" : ""} encontrado
                  {articulosFiltrados.length !== 1 ? "s" : ""}
                </p>
              </div>
              <div className="flex flex-wrap gap-2">
                <Button variant="outline" onClick={downloadTemplate} className="gap-2 bg-transparent">
                  <Download className="h-4 w-4" />
                  Plantilla
                </Button>
                <Button variant="outline" disabled={importing} asChild>
                  <label className="cursor-pointer gap-2">
                    <Upload className="h-4 w-4" />
                    {importing ? "Importando..." : "Importar"}
                    <input type="file" accept=".xlsx,.xls" onChange={handleImport} className="hidden" />
                  </label>
                </Button>
                <Dialog
                  open={isDialogOpen}
                  onOpenChange={(open) => {
                    setIsDialogOpen(open)
                    if (!open) resetForm()
                  }}
                >
                  <DialogTrigger asChild>
                    <Button className="gap-2 bg-primary hover:bg-primary/90">
                      <Plus className="h-4 w-4" />
                      Nuevo Artículo
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                    <DialogHeader>
                      <DialogTitle>{editingArticulo ? "Editar Artículo" : "Nuevo Artículo"}</DialogTitle>
                    </DialogHeader>
                    <form onSubmit={handleSubmit} className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="sku">SKU (6 dígitos) *</Label>
                          <Input
                            id="sku"
                            value={formData.sku}
                            onChange={(e) => setFormData({ ...formData, sku: e.target.value })}
                            maxLength={6}
                            required
                            disabled={!!editingArticulo}
                          />
                        </div>
                        <div>
                          <Label htmlFor="sigla">Sigla (2 dígitos) *</Label>
                          <Input
                            id="sigla"
                            value={formData.sigla}
                            onChange={(e) => setFormData({ ...formData, sigla: e.target.value.toUpperCase() })}
                            maxLength={2}
                            required
                            placeholder="AB"
                          />
                        </div>
                        <div>
                          <Label htmlFor="ean13">EAN13</Label>
                          <Input
                            id="ean13"
                            value={formData.ean13}
                            onChange={(e) => setFormData({ ...formData, ean13: e.target.value })}
                            maxLength={13}
                          />
                        </div>
                      </div>

                      <div>
                        <Label htmlFor="descripcion">Descripción *</Label>
                        <Input
                          id="descripcion"
                          value={formData.descripcion}
                          onChange={(e) => setFormData({ ...formData, descripcion: e.target.value })}
                          required
                        />
                      </div>

                      <div>
                        <Label htmlFor="proveedor">Proveedor</Label>
                        <Select
                          value={formData.proveedor_id}
                          onValueChange={(value) => setFormData({ ...formData, proveedor_id: value })}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Seleccionar proveedor" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="none">Sin proveedor</SelectItem>
                            {proveedores.map((prov) => (
                              <SelectItem key={prov.id} value={prov.id}>
                                {prov.nombre}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>

                      <div>
                        <Label htmlFor="rubro">Rubro</Label>
                        <Select
                          value={formData.rubro}
                          onValueChange={(value) => setFormData({ ...formData, rubro: value })}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Seleccionar rubro" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="none">Sin rubro</SelectItem>
                            <SelectItem value="limpieza">Limpieza</SelectItem>
                            <SelectItem value="perfumeria">Perfumería</SelectItem>
                            <SelectItem value="bazar">Bazar</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="categoria">Categoría</Label>
                          <Input
                            id="categoria"
                            value={formData.categoria}
                            onChange={(e) => setFormData({ ...formData, categoria: e.target.value })}
                            placeholder="Ej: Limpieza General"
                          />
                        </div>
                        <div>
                          <Label htmlFor="subcategoria">Subcategoría</Label>
                          <Input
                            id="subcategoria"
                            value={formData.subcategoria}
                            onChange={(e) => setFormData({ ...formData, subcategoria: e.target.value })}
                            placeholder="Ej: Trapos"
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="unidad_medida">Unidad de Medida *</Label>
                          <Select
                            value={formData.unidad_medida}
                            onValueChange={(value: "unidad" | "bulto") =>
                              setFormData({ ...formData, unidad_medida: value })
                            }
                          >
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="unidad">Unidad</SelectItem>
                              <SelectItem value="bulto">Bulto</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div>
                          <Label htmlFor="unidades_por_bulto">Unidades por Bulto *</Label>
                          <Input
                            id="unidades_por_bulto"
                            type="number"
                            min="1"
                            value={formData.unidades_por_bulto || ""}
                            onChange={(e) =>
                              setFormData({
                                ...formData,
                                unidades_por_bulto: e.target.value ? Number.parseInt(e.target.value) : 1,
                              })
                            }
                            required
                          />
                        </div>
                      </div>

                      <div className="space-y-4 pt-4 border-t">
                        <h3 className="font-semibold text-lg">Configuración de Precios</h3>
                        <div className="grid grid-cols-3 gap-4">
                          <div>
                            <Label htmlFor="porcentaje_ganancia">% Ganancia *</Label>
                            <Input
                              id="porcentaje_ganancia"
                              type="number"
                              step="0.01"
                              min="0"
                              value={formData.porcentaje_ganancia}
                              onChange={(e) =>
                                setFormData({
                                  ...formData,
                                  porcentaje_ganancia: Number.parseFloat(e.target.value) || 0,
                                })
                              }
                              required
                            />
                            <p className="text-xs text-muted-foreground mt-1">
                              Margen de ganancia sobre el costo bruto
                            </p>
                          </div>
                          <div>
                            <Label htmlFor="iva_compras">IVA en Compras *</Label>
                            <Select
                              value={formData.iva_compras}
                              onValueChange={(value: "factura" | "adquisicion_stock" | "mixto") =>
                                setFormData({ ...formData, iva_compras: value })
                              }
                            >
                              <SelectTrigger>
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="factura">En Factura (21%)</SelectItem>
                                <SelectItem value="adquisicion_stock">Adquisición de Stock (0%)</SelectItem>
                                <SelectItem value="mixto">Mixto (10.5%)</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                          <div>
                            <Label htmlFor="iva_ventas">IVA en Ventas *</Label>
                            <Select
                              value={formData.iva_ventas}
                              onValueChange={(value: "factura" | "presupuesto") =>
                                setFormData({ ...formData, iva_ventas: value })
                              }
                            >
                              <SelectTrigger>
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="factura">Factura (discriminado)</SelectItem>
                                <SelectItem value="presupuesto">Presupuesto (incluido)</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                        </div>
                        <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
                          <p className="text-xs text-blue-800">
                            <strong>Matriz de IVA:</strong> El sistema calculará automáticamente los impuestos según la
                            combinación de IVA en compras y ventas.
                          </p>
                        </div>
                      </div>

                      <div className="flex gap-2 justify-end">
                        <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                          Cancelar
                        </Button>
                        <Button type="submit">{editingArticulo ? "Actualizar" : "Crear"}</Button>
                      </div>
                    </form>
                  </DialogContent>
                </Dialog>
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-6">
            <div className="space-y-4 mb-6">
              <div className="flex items-center gap-2 text-sm font-medium text-muted-foreground">
                <Filter className="h-4 w-4" />
                Filtros
              </div>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Buscar por SKU o descripción..."
                    value={busqueda}
                    onChange={(e) => setBusqueda(e.target.value)}
                    className="pl-10"
                  />
                </div>
                <Select value={filtroProveedor} onValueChange={setFiltroProveedor}>
                  <SelectTrigger>
                    <SelectValue placeholder="Todos los proveedores" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos los proveedores</SelectItem>
                    {proveedores.map((prov) => (
                      <SelectItem key={prov.id} value={prov.id}>
                        {prov.nombre}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Select value={filtroRubro} onValueChange={setFiltroRubro}>
                  <SelectTrigger>
                    <SelectValue placeholder="Todos los rubros" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos los rubros</SelectItem>
                    <SelectItem value="limpieza">Limpieza</SelectItem>
                    <SelectItem value="perfumeria">Perfumería</SelectItem>
                    <SelectItem value="bazar">Bazar</SelectItem>
                  </SelectContent>
                </Select>
                <Input
                  placeholder="Filtrar por categoría..."
                  value={filtroCategoria}
                  onChange={(e) => setFiltroCategoria(e.target.value)}
                />
              </div>
            </div>

            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow className="bg-muted/50">
                    <TableHead className="font-semibold">SKU</TableHead>
                    <TableHead className="font-semibold">Descripción</TableHead>
                    <TableHead className="font-semibold">Proveedor</TableHead>
                    <TableHead className="font-semibold text-right">Stock</TableHead>
                    <TableHead className="text-right font-semibold">Acciones</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {articulosFiltrados.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={5} className="text-center py-8 text-muted-foreground">
                        {busqueda || filtroProveedor !== "all" || filtroRubro !== "all" || filtroCategoria
                          ? "No se encontraron artículos con los filtros aplicados"
                          : "No hay artículos registrados"}
                      </TableCell>
                    </TableRow>
                  ) : (
                    articulosFiltrados.map((articulo) => (
                      <TableRow key={articulo.id} className="hover:bg-muted/50 transition-colors">
                        <TableCell className="font-mono font-medium">{articulo.sku}</TableCell>
                        <TableCell>{articulo.descripcion}</TableCell>
                        <TableCell className="text-muted-foreground">{articulo.proveedor?.nombre || "-"}</TableCell>
                        <TableCell className="text-right">
                          <span
                            className={`font-semibold ${
                              articulo.stock_actual <= 0
                                ? "text-red-600"
                                : articulo.stock_actual < 10
                                  ? "text-yellow-600"
                                  : "text-green-600"
                            }`}
                          >
                            {articulo.stock_actual}
                          </span>
                        </TableCell>
                        <TableCell className="text-right">
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => openEditDialog(articulo)}
                            className="hover:bg-blue-50 hover:text-blue-600"
                          >
                            <Pencil className="h-4 w-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  )
}
