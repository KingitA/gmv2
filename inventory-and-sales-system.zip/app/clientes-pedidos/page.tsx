"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Search,
  Truck,
  GripVertical,
  Loader2,
  FileText,
  MoreHorizontal,
  Pencil,
  Receipt,
  ExternalLink,
} from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"

type Pedido = {
  id: string
  numero_pedido: string
  fecha: string
  estado: string
  cliente_id: string
  vendedor_id: string
  viaje_id: string | null
  subtotal: number
  descuento_general: number
  total_flete: number
  total_comision: number
  total_impuestos: number
  total: number
  observaciones: string | null
  prioridad: number
  condicion_entrega: string
  clientes?: {
    nombre_razon_social: string
    cuit: string
  }
  vendedores?: {
    nombre: string
  }
  viajes?: {
    nombre: string
    fecha: string
  }
}

type PedidoDetalle = {
  id: string
  articulo_id: string
  cantidad: number
  precio_base: number
  precio_final: number
  subtotal: number
  descuento_articulo: number
  flete: number
  comision: number
  impuestos: number
  articulos?: {
    sku: string
    descripcion: string
    sigla: string
  }
}

type Viaje = {
  id: string
  nombre: string
  fecha: string
  estado: string
  zona_id: string
  zonas?: {
    nombre: string
  }
}

type Comprobante = {
  id: string
  tipo_comprobante: string
  numero_comprobante: string
  total_factura: number
}

const ESTADOS_PEDIDO = [
  { value: "pendiente", label: "Pendiente", color: "bg-yellow-500" },
  { value: "en_preparacion", label: "En Preparación", color: "bg-blue-500" },
  { value: "pendiente_facturacion", label: "Pendiente Facturación", color: "bg-orange-500" },
  { value: "facturado", label: "Facturado", color: "bg-emerald-600" },
  { value: "listo_para_retirar", label: "Listo para Retirar", color: "bg-cyan-500" },
  { value: "listo_para_enviar", label: "Listo para Enviar", color: "bg-teal-500" },
  { value: "en_viaje", label: "En Viaje", color: "bg-purple-500" },
  { value: "entregado", label: "Entregado", color: "bg-green-600" },
  { value: "rechazado", label: "Rechazado", color: "bg-red-500" },
]

export default function ClientesPedidosPage() {
  const [pedidos, setPedidos] = useState<Pedido[]>([])
  const [viajes, setViajes] = useState<Viaje[]>([])
  const [busqueda, setBusqueda] = useState("")
  const [filtroEstado, setFiltroEstado] = useState<string>("todos")
  const [pedidoSeleccionado, setPedidoSeleccionado] = useState<Pedido | null>(null)
  const [detallesPedido, setDetallesPedido] = useState<PedidoDetalle[]>([])
  const [viajeAsignado, setViajeAsignado] = useState<string>("")
  const [cargando, setCargando] = useState(true)
  const [draggedIndex, setDraggedIndex] = useState<number | null>(null)
  const [guardandoCambios, setGuardandoCambios] = useState(false)
  const [generandoComprobante, setGenerandoComprobante] = useState<string | null>(null)
  const [comprobantesGenerados, setComprobantesGenerados] = useState<{ [pedidoId: string]: Comprobante[] }>({})
  const [modalDetalleAbierto, setModalDetalleAbierto] = useState(false)

  const supabase = createClient()

  useEffect(() => {
    cargarPedidos()
    cargarViajes()
  }, [])

  useEffect(() => {
    if (pedidos.length > 0) {
      cargarComprobantesExistentes()
    }
  }, [pedidos])

  const cargarPedidos = async () => {
    try {
      setCargando(true)
      const { data, error } = await supabase
        .from("pedidos")
        .select(`
          *,
          clientes (nombre_razon_social, cuit),
          vendedores (nombre),
          viajes (nombre, fecha)
        `)
        .order("prioridad", { ascending: true })
        .order("fecha", { ascending: false })

      if (error) throw error
      setPedidos(data || [])
    } catch (error) {
      console.error("Error cargando pedidos:", error)
    } finally {
      setCargando(false)
    }
  }

  const cargarComprobantesExistentes = async () => {
    try {
      const pedidoIds = pedidos.map((p) => p.id)
      const { data, error } = await supabase
        .from("comprobantes_venta")
        .select("id, tipo_comprobante, numero_comprobante, total_factura, pedido_id")
        .in("pedido_id", pedidoIds)

      if (error) throw error

      // Agrupar comprobantes por pedido_id
      const comprobantesAgrupados: { [pedidoId: string]: Comprobante[] } = {}
      data?.forEach((comp) => {
        if (!comprobantesAgrupados[comp.pedido_id]) {
          comprobantesAgrupados[comp.pedido_id] = []
        }
        comprobantesAgrupados[comp.pedido_id].push(comp)
      })
      setComprobantesGenerados(comprobantesAgrupados)
    } catch (error) {
      console.error("Error cargando comprobantes:", error)
    }
  }

  const cargarViajes = async () => {
    try {
      const { data, error } = await supabase
        .from("viajes")
        .select("*, zonas (nombre)")
        .in("estado", ["pendiente", "en_curso"])
        .order("fecha", { ascending: true })

      if (error) throw error
      setViajes(data || [])
    } catch (error) {
      console.error("Error cargando viajes:", error)
    }
  }

  const cargarDetallesPedido = async (pedidoId: string) => {
    try {
      const { data, error } = await supabase
        .from("pedidos_detalle")
        .select(`
          *,
          articulos (sku, descripcion, sigla)
        `)
        .eq("pedido_id", pedidoId)

      if (error) throw error
      setDetallesPedido(data || [])
    } catch (error) {
      console.error("Error cargando detalles del pedido:", error)
    }
  }

  const cambiarEstadoPedido = async (pedidoId: string, nuevoEstado: string) => {
    try {
      const { error } = await supabase.from("pedidos").update({ estado: nuevoEstado }).eq("id", pedidoId)

      if (error) throw error

      await cargarPedidos()
      if (pedidoSeleccionado?.id === pedidoId) {
        setPedidoSeleccionado({ ...pedidoSeleccionado, estado: nuevoEstado })
      }
    } catch (error) {
      console.error("Error cambiando estado:", error)
    }
  }

  const asignarViaje = async (pedidoId: string, viajeId: string) => {
    try {
      const { error } = await supabase
        .from("pedidos")
        .update({ viaje_id: viajeId, estado: "en_viaje" })
        .eq("id", pedidoId)

      if (error) throw error

      await cargarPedidos()
      setViajeAsignado("")
    } catch (error) {
      console.error("Error asignando viaje:", error)
    }
  }

  const generarComprobantes = async (pedidoId: string) => {
    setGenerandoComprobante(pedidoId)
    try {
      const response = await fetch("/api/comprobantes-venta/generar", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ pedido_id: pedidoId }),
      })

      const result = await response.json()

      if (!response.ok) {
        throw new Error(result.error || "Error generando comprobantes")
      }

      alert(
        `Comprobantes generados exitosamente:\n${result.comprobantes.map((c: any) => `${c.tipo_comprobante} ${c.numero}`).join("\n")}`,
      )

      // Recargar pedidos y comprobantes
      await cargarPedidos()
      await cargarComprobantesExistentes()
    } catch (error: any) {
      console.error("Error generando comprobantes:", error)
      alert(error.message || "Error al generar comprobantes")
    } finally {
      setGenerandoComprobante(null)
    }
  }

  const verComprobante = (comprobanteId: string) => {
    window.open(`/api/comprobantes-venta/${comprobanteId}/imagen`, "_blank")
  }

  const getTipoComprobanteLabel = (tipo: string) => {
    const tipos: { [key: string]: string } = {
      FA: "Factura A",
      FB: "Factura B",
      FC: "Factura C",
      PRES: "Presupuesto",
      REM: "Remito",
      NCA: "Nota Crédito A",
      NCB: "Nota Crédito B",
      NCC: "Nota Crédito C",
    }
    return tipos[tipo] || tipo
  }

  const guardarCambiosModal = async () => {
    if (!pedidoSeleccionado) return

    setGuardandoCambios(true)
    try {
      if (viajeAsignado && !pedidoSeleccionado.viaje_id) {
        await asignarViaje(pedidoSeleccionado.id, viajeAsignado)
      }

      alert("Cambios guardados exitosamente")
      await cargarPedidos()

      const { data } = await supabase
        .from("pedidos")
        .select(`
          *,
          clientes (nombre_razon_social, cuit),
          vendedores (nombre),
          viajes (nombre, fecha)
        `)
        .eq("id", pedidoSeleccionado.id)
        .single()

      if (data) setPedidoSeleccionado(data)
    } catch (error) {
      console.error("Error guardando cambios:", error)
      alert("Error al guardar cambios")
    } finally {
      setGuardandoCambios(false)
    }
  }

  const pedidosFiltrados = pedidos.filter((pedido) => {
    const coincideBusqueda =
      pedido.numero_pedido?.toLowerCase().includes(busqueda.toLowerCase()) ||
      pedido.clientes?.nombre_razon_social?.toLowerCase().includes(busqueda.toLowerCase()) ||
      pedido.clientes?.cuit?.includes(busqueda)

    const coincideEstado = filtroEstado === "todos" || pedido.estado === filtroEstado

    return coincideBusqueda && coincideEstado
  })

  const getEstadoBadge = (estado: string) => {
    const estadoConfig = ESTADOS_PEDIDO.find((e) => e.value === estado)
    return <Badge className={`${estadoConfig?.color} text-white`}>{estadoConfig?.label || estado}</Badge>
  }

  const handleDragStart = (e: React.DragEvent, index: number) => {
    setDraggedIndex(index)
    e.dataTransfer.effectAllowed = "move"
  }

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault()
    e.dataTransfer.dropEffect = "move"
  }

  const handleDrop = async (e: React.DragEvent, dropIndex: number) => {
    e.preventDefault()

    if (draggedIndex === null || draggedIndex === dropIndex) {
      setDraggedIndex(null)
      return
    }

    const reordenados = [...pedidosFiltrados]
    const [pedidoArrastrado] = reordenados.splice(draggedIndex, 1)
    reordenados.splice(dropIndex, 0, pedidoArrastrado)

    try {
      const updates = reordenados.map((pedido, index) => ({
        id: pedido.id,
        prioridad: index + 1,
      }))

      for (const update of updates) {
        await supabase.from("pedidos").update({ prioridad: update.prioridad }).eq("id", update.id)
      }

      await cargarPedidos()
    } catch (error) {
      console.error("Error actualizando prioridades:", error)
    }

    setDraggedIndex(null)
  }

  const handleDragEnd = () => {
    setDraggedIndex(null)
  }

  const tieneComprobantes = (pedidoId: string) => {
    return comprobantesGenerados[pedidoId]?.length > 0
  }

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Gestión de Pedidos</h1>
          <p className="text-muted-foreground">Administra todos los pedidos de clientes</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" asChild>
            <a href="/viajes">
              <Truck className="h-4 w-4 mr-2" />
              Ver Viajes
            </a>
          </Button>
          <Button asChild>
            <a href="/viajes/nuevo">
              <Truck className="h-4 w-4 mr-2" />
              Crear Viaje
            </a>
          </Button>
        </div>
      </div>

      <div className="flex gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
          <Input
            placeholder="Buscar por número de pedido, cliente o CUIT..."
            value={busqueda}
            onChange={(e) => setBusqueda(e.target.value)}
            className="pl-10"
          />
        </div>
        <Select value={filtroEstado} onValueChange={setFiltroEstado}>
          <SelectTrigger className="w-[200px]">
            <SelectValue placeholder="Filtrar por estado" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="todos">Todos los estados</SelectItem>
            {ESTADOS_PEDIDO.map((estado) => (
              <SelectItem key={estado.value} value={estado.value}>
                {estado.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-[50px]">Orden</TableHead>
                <TableHead>Nº Pedido</TableHead>
                <TableHead>Fecha</TableHead>
                <TableHead>Cliente</TableHead>
                <TableHead>Vendedor</TableHead>
                <TableHead>Estado</TableHead>
                <TableHead>Viaje</TableHead>
                <TableHead>Comprobantes</TableHead>
                <TableHead className="text-right">Total</TableHead>
                <TableHead className="text-right">Acciones</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {cargando ? (
                <TableRow>
                  <TableCell colSpan={10} className="text-center py-8">
                    Cargando pedidos...
                  </TableCell>
                </TableRow>
              ) : pedidosFiltrados.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={10} className="text-center py-8">
                    No se encontraron pedidos
                  </TableCell>
                </TableRow>
              ) : (
                pedidosFiltrados.map((pedido, index) => (
                  <TableRow
                    key={pedido.id}
                    draggable
                    onDragStart={(e) => handleDragStart(e, index)}
                    onDragOver={handleDragOver}
                    onDrop={(e) => handleDrop(e, index)}
                    onDragEnd={handleDragEnd}
                    className={`cursor-move ${draggedIndex === index ? "opacity-50" : ""}`}
                  >
                    <TableCell>
                      <GripVertical className="h-5 w-5 text-muted-foreground" />
                    </TableCell>
                    <TableCell className="font-medium">{pedido.numero_pedido}</TableCell>
                    <TableCell>{new Date(pedido.fecha).toLocaleDateString()}</TableCell>
                    <TableCell>
                      <div>
                        <div className="font-medium">{pedido.clientes?.nombre_razon_social}</div>
                        <div className="text-sm text-muted-foreground">{pedido.clientes?.cuit}</div>
                      </div>
                    </TableCell>
                    <TableCell>{pedido.vendedores?.nombre}</TableCell>
                    <TableCell>{getEstadoBadge(pedido.estado)}</TableCell>
                    <TableCell>
                      {pedido.viajes ? (
                        <div className="text-sm">
                          <div className="font-medium">{pedido.viajes.nombre}</div>
                          <div className="text-muted-foreground">
                            {new Date(pedido.viajes.fecha).toLocaleDateString()}
                          </div>
                        </div>
                      ) : (
                        <span className="text-muted-foreground">Sin asignar</span>
                      )}
                    </TableCell>
                    <TableCell>
                      {comprobantesGenerados[pedido.id]?.length > 0 ? (
                        <div className="space-y-1">
                          {comprobantesGenerados[pedido.id].map((comp) => (
                            <button
                              key={comp.id}
                              onClick={() => verComprobante(comp.id)}
                              className="flex items-center gap-1 text-xs text-primary hover:underline"
                            >
                              <FileText className="h-3 w-3" />
                              {comp.numero_comprobante}
                            </button>
                          ))}
                        </div>
                      ) : (
                        <span className="text-muted-foreground text-sm">-</span>
                      )}
                    </TableCell>
                    <TableCell className="text-right font-medium">${pedido.total?.toFixed(2)}</TableCell>
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem
                            onClick={() => {
                              setPedidoSeleccionado(pedido)
                              cargarDetallesPedido(pedido.id)
                              setModalDetalleAbierto(true)
                            }}
                          >
                            <Pencil className="h-4 w-4 mr-2" />
                            Editar / Ver Detalle
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          {!tieneComprobantes(pedido.id) ? (
                            <DropdownMenuItem
                              onClick={() => generarComprobantes(pedido.id)}
                              disabled={generandoComprobante === pedido.id}
                            >
                              {generandoComprobante === pedido.id ? (
                                <>
                                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                                  Generando...
                                </>
                              ) : (
                                <>
                                  <Receipt className="h-4 w-4 mr-2" />
                                  Generar Comprobantes
                                </>
                              )}
                            </DropdownMenuItem>
                          ) : (
                            <>
                              {comprobantesGenerados[pedido.id]?.map((comp) => (
                                <DropdownMenuItem key={comp.id} onClick={() => verComprobante(comp.id)}>
                                  <ExternalLink className="h-4 w-4 mr-2" />
                                  Ver {getTipoComprobanteLabel(comp.tipo_comprobante)}
                                </DropdownMenuItem>
                              ))}
                            </>
                          )}
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Dialog open={modalDetalleAbierto} onOpenChange={setModalDetalleAbierto}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Detalle del Pedido {pedidoSeleccionado?.numero_pedido}</DialogTitle>
            <DialogDescription>Información completa del pedido y sus artículos</DialogDescription>
          </DialogHeader>

          {pedidoSeleccionado && (
            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-sm">Información del Cliente</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    <div>
                      <Label className="text-muted-foreground">Cliente</Label>
                      <p className="font-medium">{pedidoSeleccionado.clientes?.nombre_razon_social}</p>
                    </div>
                    <div>
                      <Label className="text-muted-foreground">CUIT</Label>
                      <p>{pedidoSeleccionado.clientes?.cuit}</p>
                    </div>
                    <div>
                      <Label className="text-muted-foreground">Vendedor</Label>
                      <p>{pedidoSeleccionado.vendedores?.nombre}</p>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-sm">Estado y Logística</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    <div>
                      <Label className="text-muted-foreground">Estado Actual</Label>
                      <div className="mt-1">{getEstadoBadge(pedidoSeleccionado.estado)}</div>
                    </div>
                    <div>
                      <Label className="text-muted-foreground">Cambiar Estado</Label>
                      <Select
                        value={pedidoSeleccionado.estado}
                        onValueChange={(value) => cambiarEstadoPedido(pedidoSeleccionado.id, value)}
                      >
                        <SelectTrigger className="mt-1">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {ESTADOS_PEDIDO.map((estado) => (
                            <SelectItem key={estado.value} value={estado.value}>
                              {estado.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    {!pedidoSeleccionado.viaje_id && (
                      <div>
                        <Label className="text-muted-foreground">Asignar a Viaje</Label>
                        <div className="flex gap-2 mt-1">
                          <Select value={viajeAsignado} onValueChange={setViajeAsignado}>
                            <SelectTrigger>
                              <SelectValue placeholder="Seleccionar viaje" />
                            </SelectTrigger>
                            <SelectContent>
                              {viajes.map((viaje) => (
                                <SelectItem key={viaje.id} value={viaje.id}>
                                  {viaje.nombre} - {viaje.zonas?.nombre} ({new Date(viaje.fecha).toLocaleDateString()})
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <Button
                            size="sm"
                            onClick={() => asignarViaje(pedidoSeleccionado.id, viajeAsignado)}
                            disabled={!viajeAsignado}
                          >
                            <Truck className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    )}
                    <div>
                      <Label className="text-muted-foreground">Condición de Entrega</Label>
                      <div className="mt-1 text-sm">
                        {pedidoSeleccionado.condicion_entrega === "retira_mostrador" && "Retira en Mostrador"}
                        {pedidoSeleccionado.condicion_entrega === "transporte" && "Envío por Transporte"}
                        {pedidoSeleccionado.condicion_entrega === "entregamos_nosotros" && "Entregamos Nosotros"}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Comprobantes del pedido */}
              {comprobantesGenerados[pedidoSeleccionado.id]?.length > 0 && (
                <Card>
                  <CardHeader>
                    <CardTitle className="text-sm">Comprobantes Generados</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex flex-wrap gap-2">
                      {comprobantesGenerados[pedidoSeleccionado.id].map((comp) => (
                        <Button key={comp.id} variant="outline" size="sm" onClick={() => verComprobante(comp.id)}>
                          <FileText className="h-4 w-4 mr-2" />
                          {getTipoComprobanteLabel(comp.tipo_comprobante)} {comp.numero_comprobante}
                          <ExternalLink className="h-3 w-3 ml-2" />
                        </Button>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}

              <Card>
                <CardHeader>
                  <CardTitle className="text-sm">Artículos del Pedido</CardTitle>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>SKU</TableHead>
                        <TableHead>Descripción</TableHead>
                        <TableHead className="text-right">Cantidad</TableHead>
                        <TableHead className="text-right">Precio Unit.</TableHead>
                        <TableHead className="text-right">Subtotal</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {detallesPedido.map((detalle) => (
                        <TableRow key={detalle.id}>
                          <TableCell className="font-mono text-sm">{detalle.articulos?.sku}</TableCell>
                          <TableCell>{detalle.articulos?.descripcion}</TableCell>
                          <TableCell className="text-right">{detalle.cantidad}</TableCell>
                          <TableCell className="text-right">${detalle.precio_final?.toFixed(2)}</TableCell>
                          <TableCell className="text-right font-medium">${detalle.subtotal?.toFixed(2)}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-sm">Resumen de Totales</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span>Subtotal:</span>
                      <span className="font-medium">${pedidoSeleccionado.subtotal?.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between text-muted-foreground">
                      <span>Descuento:</span>
                      <span>-${pedidoSeleccionado.descuento_general?.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between text-muted-foreground">
                      <span>Flete:</span>
                      <span>${pedidoSeleccionado.total_flete?.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between text-muted-foreground">
                      <span>Comisión:</span>
                      <span>${pedidoSeleccionado.total_comision?.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between text-muted-foreground">
                      <span>Impuestos:</span>
                      <span>${pedidoSeleccionado.total_impuestos?.toFixed(2)}</span>
                    </div>
                    <div className="border-t pt-2 flex justify-between text-lg font-bold">
                      <span>Total:</span>
                      <span>${pedidoSeleccionado.total?.toFixed(2)}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {pedidoSeleccionado.observaciones && (
                <Card>
                  <CardHeader>
                    <CardTitle className="text-sm">Observaciones</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm">{pedidoSeleccionado.observaciones}</p>
                  </CardContent>
                </Card>
              )}

              {/* Botones de acción del modal */}
              <div className="flex justify-between">
                <div>
                  {!tieneComprobantes(pedidoSeleccionado.id) && (
                    <Button
                      onClick={() => generarComprobantes(pedidoSeleccionado.id)}
                      disabled={generandoComprobante === pedidoSeleccionado.id}
                    >
                      {generandoComprobante === pedidoSeleccionado.id ? (
                        <>
                          <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                          Generando...
                        </>
                      ) : (
                        <>
                          <Receipt className="h-4 w-4 mr-2" />
                          Generar Comprobantes
                        </>
                      )}
                    </Button>
                  )}
                </div>
                <Button variant="outline" onClick={() => setModalDetalleAbierto(false)}>
                  Cerrar
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}
