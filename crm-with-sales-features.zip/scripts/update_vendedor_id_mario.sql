-- Script para actualizar el vendedor_id del usuario MARIO SILVA al ID correcto

-- Verificar el vendedor_id actual del usuario
SELECT id, email, nombre, vendedor_id, rol 
FROM usuarios_crm 
WHERE email = 'AAAA@GMAIL.COM';

-- Actualizar al vendedor_id correcto de MARIO SILVA
UPDATE usuarios_crm 
SET vendedor_id = 'c63ed924-c270-4a5a-9564-96e641bfdf2f',
    updated_at = NOW()
WHERE email = 'AAAA@GMAIL.COM';

-- Verificar que se actualizó correctamente
SELECT id, email, nombre, vendedor_id, rol 
FROM usuarios_crm 
WHERE email = 'AAAA@GMAIL.COM';
