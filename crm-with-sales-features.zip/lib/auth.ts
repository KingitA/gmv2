import { createClient } from "./supabase/server"
import type { UserRole } from "./types" // Declare or import UserRole here

export async function getCurrentUser() {
  const supabase = await createClient()

  const {
    data: { user },
    error: authError,
  } = await supabase.auth.getUser()

  if (authError || !user) {
    return null
  }

  // Get user data from usuarios_crm table
  const { data: usuarioCrm, error: crmError } = await supabase
    .from("usuarios_crm")
    .select("*")
    .eq("id", user.id)
    .single()

  if (crmError || !usuarioCrm) {
    return null
  }

  return {
    id: user.id,
    email: user.email!,
    ...usuarioCrm,
  }
}

export async function requireAuth() {
  const user = await getCurrentUser()

  if (!user) {
    throw new Error("No autenticado")
  }

  return user
}

export async function requireActiveUser() {
  const user = await requireAuth()

  if (user.estado !== "activo") {
    throw new Error("Usuario no activo")
  }

  return user
}

export async function requireRole(role: UserRole | UserRole[]) {
  const user = await requireActiveUser()

  const roles = Array.isArray(role) ? role : [role]

  if (!roles.includes(user.rol)) {
    throw new Error("No autorizado")
  }

  return user
}
