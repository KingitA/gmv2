"use server"

import { createClient } from "@/lib/supabase/server"

export async function getViajanteDashboardData() {
  const supabase = await createClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()
  if (!user) throw new Error("No autenticado")

  // Get viajante info
  const { data: viajante } = await supabase.from("viajantes").select("*").eq("id", user.id).single()

  // Get upcoming trips
  const { data: viajes } = await supabase
    .from("viajes")
    .select("*")
    .eq("viajante_id", user.id)
    .eq("completado", false)
    .order("fecha_salida", { ascending: true })
    .limit(5)

  // Get pending commissions
  const { data: comisionesPendientes } = await supabase
    .from("comisiones")
    .select("*")
    .eq("viajante_id", user.id)
    .eq("pagado", false)

  // Get paid commissions this month
  const firstDayOfMonth = new Date()
  firstDayOfMonth.setDate(1)
  firstDayOfMonth.setHours(0, 0, 0, 0)

  const { data: comisionesPagadas } = await supabase
    .from("comisiones")
    .select("*")
    .eq("viajante_id", user.id)
    .eq("pagado", true)
    .gte("fecha_pago", firstDayOfMonth.toISOString())

  // Get client count
  const { count: clienteCount } = await supabase
    .from("clientes")
    .select("*", { count: "exact", head: true })
    .eq("viajante_id", user.id)
    .eq("activo", true)

  // Calculate totals
  const totalComisionesPendientes = comisionesPendientes?.reduce((sum, c) => sum + Number(c.monto), 0) || 0

  const totalComisionesPagadas = comisionesPagadas?.reduce((sum, c) => sum + Number(c.monto), 0) || 0

  return {
    viajante,
    viajes: viajes || [],
    totalComisionesPendientes,
    totalComisionesPagadas,
    clienteCount: clienteCount || 0,
  }
}
