"use server"

import { createClient } from "@/lib/supabase/server"
import { revalidatePath } from "next/cache"

export async function createPedido(data: {
  cliente_id: string
  items: Array<{
    producto_id: string
    cantidad: number
    precio_unitario: number
    descuento: number
  }>
  observaciones?: string
  zona_entrega?: string
}) {
  const supabase = await createClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()
  if (!user) throw new Error("No autenticado")

  const { data: usuarioCrm } = await supabase
    .from("usuarios_crm")
    .select("rol, vendedor_id")
    .eq("email", user.email)
    .single()

  if (!usuarioCrm || (usuarioCrm.rol !== "vendedor" && usuarioCrm.rol !== "admin")) {
    throw new Error("No autorizado")
  }

  const { data: cliente } = await supabase.from("clientes").select("*").eq("id", data.cliente_id).single()

  if (!cliente) throw new Error("Cliente no encontrado")

  if (usuarioCrm.rol === "vendedor" && cliente.vendedor_id !== usuarioCrm.vendedor_id) {
    throw new Error("No autorizado para crear pedidos para este cliente")
  }

  // Generate order number
  const { count } = await supabase.from("pedidos").select("*", { count: "exact", head: true })
  const numeroPedido = `PED-${String((count || 0) + 1).padStart(6, "0")}`

  // Calculate totals
  let subtotal = 0
  const itemsWithSubtotal = data.items.map((item) => {
    const itemSubtotal = item.cantidad * item.precio_unitario * (1 - item.descuento / 100)
    subtotal += itemSubtotal
    return {
      ...item,
      subtotal: itemSubtotal,
    }
  })

  // Get client info for IVA calculation
  const { data: clienteInfo } = await supabase.from("clientes").select("*").eq("id", data.cliente_id).single()

  if (!clienteInfo) throw new Error("Cliente no encontrado")

  // Calculate IVA (21% for most cases)
  const iva = clienteInfo.condicion_iva === "responsable_inscripto" ? 0 : subtotal * 0.21

  // Calculate percepciones (3% if applicable)
  const percepciones = clienteInfo.aplica_percepciones ? subtotal * 0.03 : 0

  // Flete (can be calculated based on zone, for now 0)
  const flete = 0

  const total = subtotal + iva + percepciones + flete

  // Create pedido
  const { data: pedido, error: pedidoError } = await supabase
    .from("pedidos")
    .insert({
      numero_pedido: numeroPedido,
      cliente_id: data.cliente_id,
      viajante_id: usuarioCrm.rol === "vendedor" ? user.id : null,
      status: "pendiente",
      subtotal,
      descuento: 0,
      flete,
      iva,
      percepciones,
      total,
      zona_entrega: data.zona_entrega || clienteInfo.zona,
      observaciones: data.observaciones,
    })
    .select()
    .single()

  if (pedidoError) throw pedidoError

  // Create pedido items and reserve stock
  for (const item of itemsWithSubtotal) {
    // Insert item
    const { error: itemError } = await supabase.from("pedido_items").insert({
      pedido_id: pedido.id,
      producto_id: item.producto_id,
      cantidad: item.cantidad,
      precio_unitario: item.precio_unitario,
      descuento: item.descuento,
      subtotal: item.subtotal,
    })

    if (itemError) throw itemError

    // Reserve stock
    const { data: producto } = await supabase
      .from("productos")
      .select("stock_reservado")
      .eq("id", item.producto_id)
      .single()

    if (producto) {
      await supabase
        .from("productos")
        .update({
          stock_reservado: producto.stock_reservado + item.cantidad,
        })
        .eq("id", item.producto_id)
    }
  }

  // Create cuenta corriente entry
  await supabase.from("cuenta_corriente").insert({
    cliente_id: data.cliente_id,
    pedido_id: pedido.id,
    tipo: "debe",
    concepto: `Pedido #${numeroPedido}`,
    monto: total,
    saldo: total, // This should be calculated based on previous balance
    fecha: new Date().toISOString(),
  })

  // Calculate and create commission
  const { data: proveedor } = await supabase
    .from("proveedores")
    .select("comision_viajante")
    .eq("id", itemsWithSubtotal[0].producto_id)
    .single()

  if (proveedor && usuarioCrm.rol === "vendedor") {
    await supabase.from("comisiones").insert({
      viajante_id: user.id,
      pedido_id: pedido.id,
      monto: total * (proveedor.comision_viajante / 100),
      porcentaje: proveedor.comision_viajante,
      pagado: false,
    })
  }

  revalidatePath("/viajante/pedidos")
  return pedido
}

export async function getPedidoById(pedidoId: string) {
  const supabase = await createClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()
  if (!user) throw new Error("No autenticado")

  const { data: usuarioCrm } = await supabase
    .from("usuarios_crm")
    .select("rol, vendedor_id, cliente_id")
    .eq("email", user.email)
    .single()

  if (!usuarioCrm) throw new Error("Usuario no encontrado")

  const { data, error } = await supabase
    .from("pedidos")
    .select(`
      *,
      clientes:cliente_id (
        razon_social,
        direccion,
        zona,
        telefono,
        vendedor_id
      ),
      pedido_items (
        *,
        productos:producto_id (
          nombre,
          sku,
          proveedores:proveedor_id (
            nombre
          )
        )
      )
    `)
    .eq("id", pedidoId)
    .single()

  if (error) throw error
  if (!data) throw new Error("Pedido no encontrado")

  // Verify authorization
  const cliente = data.clientes as any
  if (usuarioCrm.rol === "vendedor") {
    if (cliente.vendedor_id !== usuarioCrm.vendedor_id) {
      throw new Error("No autorizado para ver este pedido")
    }
  } else if (usuarioCrm.rol === "cliente") {
    if (data.cliente_id !== usuarioCrm.cliente_id) {
      throw new Error("No autorizado para ver este pedido")
    }
  } else if (usuarioCrm.rol !== "admin") {
    throw new Error("No autorizado")
  }

  return data
}

export async function updatePedidoStatus(pedidoId: string, status: string) {
  const supabase = await createClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()
  if (!user) throw new Error("No autenticado")

  const { data: usuarioCrm } = await supabase
    .from("usuarios_crm")
    .select("rol, vendedor_id")
    .eq("email", user.email)
    .single()

  if (!usuarioCrm || (usuarioCrm.rol !== "vendedor" && usuarioCrm.rol !== "admin")) {
    throw new Error("No autorizado")
  }

  const { data, error } = await supabase.from("pedidos").select("cliente_id").eq("id", pedidoId).single()

  if (error) throw error
  if (!data) throw new Error("Pedido no encontrado")

  const { data: cliente } = await supabase.from("clientes").select("vendedor_id").eq("id", data.cliente_id).single()

  if (!cliente) throw new Error("Cliente no encontrado")

  if (usuarioCrm.rol === "vendedor" && cliente.vendedor_id !== usuarioCrm.vendedor_id) {
    throw new Error("No autorizado para actualizar este pedido")
  }

  const { error: updateError } = await supabase.from("pedidos").update({ status }).eq("id", pedidoId)

  if (updateError) throw updateError

  revalidatePath("/viajante/pedidos")
  return { success: true }
}
