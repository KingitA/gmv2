"use server"

import { createClient } from "@/lib/supabase/server"
import { revalidatePath } from "next/cache"

export async function getViajanteClientes() {
  const supabase = await createClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()
  if (!user) throw new Error("No autenticado")

  const { data: profile } = await supabase.from("profiles").select("role").eq("id", user.id).single()

  if (profile?.role !== "viajante" && profile?.role !== "admin") {
    throw new Error("No autorizado")
  }

  const query = supabase.from("clientes").select("*").eq("activo", true).order("razon_social")

  if (profile.role === "viajante") {
    query.eq("viajante_id", user.id)
  }

  const { data, error } = await query

  if (error) throw error
  return data
}

export async function searchClientes(searchTerm: string) {
  const supabase = await createClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()
  if (!user) throw new Error("No autenticado")

  const { data: profile } = await supabase.from("profiles").select("role").eq("id", user.id).single()

  if (profile?.role !== "viajante" && profile?.role !== "admin") {
    throw new Error("No autorizado")
  }

  let query = supabase.from("clientes").select("*").eq("activo", true)

  if (profile.role === "viajante") {
    query = query.eq("viajante_id", user.id)
  }

  // Search by multiple fields
  query = query.or(
    `razon_social.ilike.%${searchTerm}%,` +
      `direccion.ilike.%${searchTerm}%,` +
      `zona.ilike.%${searchTerm}%,` +
      `cuit.ilike.%${searchTerm}%`,
  )

  const { data, error } = await query.order("razon_social")

  if (error) throw error
  return data
}

export async function createCliente(formData: {
  razon_social: string
  cuit?: string
  direccion: string
  zona: string
  telefono?: string
  email?: string
  dias_credito?: number
  limite_credito?: number
  descuento_especial?: number
  condicion_iva?: string
  aplica_percepciones?: boolean
  observaciones?: string
}) {
  const supabase = await createClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()
  if (!user) throw new Error("No autenticado")

  const { data: profile } = await supabase.from("profiles").select("role").eq("id", user.id).single()

  if (profile?.role !== "viajante" && profile?.role !== "admin") {
    throw new Error("No autorizado")
  }

  const { data, error } = await supabase
    .from("clientes")
    .insert({
      ...formData,
      viajante_id: profile.role === "viajante" ? user.id : null,
    })
    .select()
    .single()

  if (error) throw error

  revalidatePath("/viajante/clientes")
  return data
}

export async function updateCliente(
  clienteId: string,
  updates: Partial<{
    razon_social: string
    cuit: string
    direccion: string
    zona: string
    telefono: string
    email: string
    dias_credito: number
    limite_credito: number
    descuento_especial: number
    condicion_iva: string
    aplica_percepciones: boolean
    observaciones: string
  }>,
) {
  const supabase = await createClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()
  if (!user) throw new Error("No autenticado")

  // Create a pending change request instead of direct update
  const { data: cliente } = await supabase.from("clientes").select("*").eq("id", clienteId).single()

  if (!cliente) throw new Error("Cliente no encontrado")

  const { error } = await supabase.from("cambios_pendientes").insert({
    viajante_id: user.id,
    cliente_id: clienteId,
    tipo_cambio: "datos_cliente",
    datos_anteriores: cliente,
    datos_nuevos: { ...cliente, ...updates },
  })

  if (error) throw error

  revalidatePath("/viajante/clientes")
  return { success: true, message: "Cambio enviado para aprobación" }
}

export async function getClienteById(clienteId: string) {
  const supabase = await createClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()
  if (!user) throw new Error("No autenticado")

  const { data: usuarioCrm } = await supabase
    .from("usuarios_crm")
    .select("rol, vendedor_id, cliente_id")
    .eq("email", user.email)
    .single()

  if (!usuarioCrm) throw new Error("Usuario no encontrado")

  const { data, error } = await supabase.from("clientes").select("*").eq("id", clienteId).single()

  if (error) throw error
  if (!data) throw new Error("Cliente no encontrado")

  // Verify authorization
  if (usuarioCrm.rol === "vendedor") {
    if (data.vendedor_id !== usuarioCrm.vendedor_id) {
      throw new Error("No autorizado para ver este cliente")
    }
  } else if (usuarioCrm.rol === "cliente") {
    if (data.id !== usuarioCrm.cliente_id) {
      throw new Error("No autorizado para ver este cliente")
    }
  } else if (usuarioCrm.rol !== "admin") {
    throw new Error("No autorizado")
  }

  return data
}
