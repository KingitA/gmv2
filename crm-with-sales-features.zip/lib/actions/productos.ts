"use server"

import { createClient } from "@/lib/supabase/server"

export async function searchProductos(searchTerm: string) {
  const supabase = await createClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()
  if (!user) throw new Error("No autenticado")

  let query = supabase
    .from("productos")
    .select(`
      *,
      proveedores:proveedor_id (
        nombre,
        codigo
      )
    `)
    .eq("activo", true)

  // Search by multiple fields
  if (searchTerm) {
    query = query.or(
      `nombre.ilike.%${searchTerm}%,` +
        `sku.ilike.%${searchTerm}%,` +
        `ean13.ilike.%${searchTerm}%,` +
        `descripcion.ilike.%${searchTerm}%`,
    )
  }

  const { data, error } = await query.order("nombre").limit(50)

  if (error) throw error
  return data
}

export async function getProductoById(productoId: string) {
  const supabase = await createClient()

  const { data, error } = await supabase
    .from("productos")
    .select(`
      *,
      proveedores:proveedor_id (
        nombre,
        codigo,
        margen_base,
        comision_viajante
      )
    `)
    .eq("id", productoId)
    .single()

  if (error) throw error
  return data
}

export async function checkStockDisponible(productoId: string, cantidad: number) {
  const supabase = await createClient()

  const { data: producto } = await supabase
    .from("productos")
    .select("stock_actual, stock_reservado")
    .eq("id", productoId)
    .single()

  if (!producto) throw new Error("Producto no encontrado")

  const stockDisponible = producto.stock_actual - producto.stock_reservado
  return {
    disponible: stockDisponible >= cantidad,
    stockDisponible,
    stockActual: producto.stock_actual,
    stockReservado: producto.stock_reservado,
  }
}

export async function getProductos() {
  const supabase = await createClient()

  const { data, error } = await supabase
    .from("productos")
    .select(`
      *,
      proveedores:proveedor_id (
        nombre,
        codigo
      )
    `)
    .eq("activo", true)
    .order("nombre")

  if (error) throw error

  // Transform to match expected format
  return data.map((p) => ({
    id: p.id,
    codigo: p.sku,
    nombre: p.nombre,
    descripcion: p.descripcion,
    precio_base: p.precio_base,
    stock_disponible: p.stock_actual,
    stock_reservado: p.stock_reservado,
    unidad_medida: p.unidad_medida || "unidad",
    activo: p.activo,
  }))
}
