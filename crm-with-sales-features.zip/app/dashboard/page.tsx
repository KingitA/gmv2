import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"

// Force dynamic rendering to avoid build-time prerendering
export const dynamic = "force-dynamic"

export default async function DashboardPage() {
  const supabase = await createClient()

  const {
    data: { user },
    error,
  } = await supabase.auth.getUser()

  if (error || !user) {
    redirect("/auth/login")
  }

  // Check user in usuarios_crm table
  const { data: usuarioCrm } = await supabase.from("usuarios_crm").select("*").eq("email", user.email).single()

  if (!usuarioCrm) {
    // User doesn't exist in usuarios_crm, show error
    return (
      <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-background via-secondary/20 to-background p-6">
        <div className="w-full max-w-md space-y-6 rounded-lg border border-border bg-card p-8 shadow-lg">
          <div className="space-y-2 text-center">
            <h1 className="text-2xl font-bold text-foreground">Usuario No Encontrado</h1>
            <p className="text-muted-foreground">
              Tu cuenta no está registrada en el sistema. Por favor, contacta al administrador.
            </p>
            <p className="text-sm text-muted-foreground">Usuario: {user.email}</p>
          </div>
          <form
            action={async () => {
              "use server"
              const supabase = await createClient()
              await supabase.auth.signOut()
              redirect("/auth/login")
            }}
          >
            <button
              type="submit"
              className="w-full rounded-lg bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:bg-primary/90"
            >
              Cerrar Sesión
            </button>
          </form>
        </div>
      </div>
    )
  }

  // Check user status
  if (usuarioCrm.estado === "pendiente") {
    redirect("/auth/pendiente")
  }

  if (usuarioCrm.estado === "rechazado") {
    await supabase.auth.signOut()
    redirect("/auth/login?error=Tu cuenta ha sido rechazada")
  }

  // Redirect based on role
  if (usuarioCrm.rol === "vendedor") {
    redirect("/vendedor")
  } else if (usuarioCrm.rol === "cliente") {
    redirect("/cliente")
  } else if (usuarioCrm.rol === "admin") {
    redirect("/admin")
  }

  // Fallback if no role matched
  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-background via-secondary/20 to-background p-6">
      <div className="w-full max-w-md space-y-6 rounded-lg border border-border bg-card p-8 shadow-lg">
        <div className="space-y-2 text-center">
          <h1 className="text-2xl font-bold text-foreground">Configuración Pendiente</h1>
          <p className="text-muted-foreground">
            Tu cuenta está activa pero no tiene un rol asignado. Por favor, contacta al administrador.
          </p>
          <p className="text-sm text-muted-foreground">Usuario: {user.email}</p>
        </div>
        <form
          action={async () => {
            "use server"
            const supabase = await createClient()
            await supabase.auth.signOut()
            redirect("/auth/login")
          }}
        >
          <button
            type="submit"
            className="w-full rounded-lg bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:bg-primary/90"
          >
            Cerrar Sesión
          </button>
        </form>
      </div>
    </div>
  )
}
