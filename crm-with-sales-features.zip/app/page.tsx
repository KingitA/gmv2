import { Button } from "@/components/ui/button"
import Link from "next/link"
import { Package, Users, TrendingUp, Shield } from "lucide-react"

export default function HomePage() {
  return (
    <div className="flex min-h-screen flex-col">
      {/* Header */}
      <header className="border-b border-border/50 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto flex h-16 items-center justify-between px-4">
          <div className="flex items-center gap-2">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary">
              <Package className="h-5 w-5 text-primary-foreground" />
            </div>
            <span className="text-xl font-semibold">Sistema de Ventas</span>
          </div>
          <div className="flex items-center gap-3">
            <Button variant="ghost" asChild>
              <Link href="/auth/login">Iniciar Sesión</Link>
            </Button>
            <Button asChild>
              <Link href="/auth/sign-up">Registrarse</Link>
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="flex flex-1 items-center justify-center bg-gradient-to-br from-background via-secondary/20 to-background px-4 py-20">
        <div className="container mx-auto max-w-5xl text-center">
          <h1 className="mb-6 text-balance text-4xl font-bold leading-tight tracking-tight text-foreground md:text-6xl">
            Gestión de Ventas y Pedidos Simplificada
          </h1>
          <p className="mx-auto mb-8 max-w-2xl text-pretty text-lg text-muted-foreground md:text-xl">
            Sistema completo para viajantes y clientes. Gestiona pedidos, cuenta corriente, comisiones y más desde una
            plataforma integrada.
          </p>
          <div className="flex flex-col items-center justify-center gap-4 sm:flex-row">
            <Button size="lg" asChild className="h-12 px-8">
              <Link href="/auth/sign-up">Comenzar Ahora</Link>
            </Button>
            <Button size="lg" variant="outline" asChild className="h-12 px-8 bg-transparent">
              <Link href="/auth/login">Iniciar Sesión</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="border-t border-border/50 bg-muted/30 px-4 py-20">
        <div className="container mx-auto max-w-6xl">
          <h2 className="mb-12 text-center text-3xl font-bold text-foreground">Características Principales</h2>
          <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-4">
            <div className="flex flex-col items-center text-center">
              <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-xl bg-primary/10">
                <Package className="h-8 w-8 text-primary" />
              </div>
              <h3 className="mb-2 text-lg font-semibold">Gestión de Pedidos</h3>
              <p className="text-sm text-muted-foreground">Crea y gestiona pedidos con reserva automática de stock</p>
            </div>
            <div className="flex flex-col items-center text-center">
              <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-xl bg-accent/10">
                <Users className="h-8 w-8 text-accent" />
              </div>
              <h3 className="mb-2 text-lg font-semibold">Gestión de Clientes</h3>
              <p className="text-sm text-muted-foreground">Administra clientes, zonas y condiciones comerciales</p>
            </div>
            <div className="flex flex-col items-center text-center">
              <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-xl bg-chart-3/10">
                <TrendingUp className="h-8 w-8 text-chart-3" />
              </div>
              <h3 className="mb-2 text-lg font-semibold">Cuenta Corriente</h3>
              <p className="text-sm text-muted-foreground">Control completo de pagos y saldos de clientes</p>
            </div>
            <div className="flex flex-col items-center text-center">
              <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-xl bg-chart-4/10">
                <Shield className="h-8 w-8 text-chart-4" />
              </div>
              <h3 className="mb-2 text-lg font-semibold">Sistema Seguro</h3>
              <p className="text-sm text-muted-foreground">Roles y permisos para proteger tu información</p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border/50 bg-background px-4 py-8">
        <div className="container mx-auto text-center text-sm text-muted-foreground">
          <p>&copy; 2025 Sistema de Ventas. Todos los derechos reservados.</p>
        </div>
      </footer>
    </div>
  )
}
