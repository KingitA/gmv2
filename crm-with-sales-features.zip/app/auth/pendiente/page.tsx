import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Clock, Package } from "lucide-react"
import { createClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"

// Force dynamic rendering to avoid build-time prerendering
export const dynamic = "force-dynamic"

export default async function PendientePage() {
  const supabase = await createClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/auth/login")
  }

  const { data: usuarioCrm } = await supabase.from("usuarios_crm").select("*").eq("id", user.id).single()

  const handleSignOut = async () => {
    "use server"
    const supabase = await createClient()
    await supabase.auth.signOut()
    redirect("/auth/login")
  }

  return (
    <div className="flex min-h-screen w-full items-center justify-center bg-gradient-to-br from-background via-secondary/20 to-background p-4">
      <div className="w-full max-w-md">
        <div className="mb-8 flex flex-col items-center gap-2">
          <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary">
            <Package className="h-6 w-6 text-primary-foreground" />
          </div>
          <h1 className="text-2xl font-semibold text-foreground">Sistema de Ventas CRM</h1>
        </div>

        <Card className="border-border/50 shadow-lg">
          <CardHeader className="space-y-1 text-center">
            <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-amber-500/10">
              <Clock className="h-8 w-8 text-amber-500" />
            </div>
            <CardTitle className="text-2xl font-semibold">Cuenta Pendiente de Aprobación</CardTitle>
            <CardDescription className="text-base">Tu solicitud está siendo revisada</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="rounded-lg bg-muted/50 p-4 space-y-3">
              <div className="text-sm">
                <p className="font-medium text-foreground mb-1">Información de tu solicitud:</p>
                <ul className="space-y-1 text-muted-foreground">
                  <li>
                    <span className="font-medium">Email:</span> {usuarioCrm?.email}
                  </li>
                  <li>
                    <span className="font-medium">Nombre:</span> {usuarioCrm?.nombre}
                  </li>
                  <li>
                    <span className="font-medium">Teléfono:</span> {usuarioCrm?.telefono || "No proporcionado"}
                  </li>
                  {usuarioCrm?.cuit && (
                    <li>
                      <span className="font-medium">CUIT:</span> {usuarioCrm.cuit}
                    </li>
                  )}
                  {usuarioCrm?.observaciones && (
                    <li>
                      <span className="font-medium">Tipo solicitado:</span> {usuarioCrm.observaciones}
                    </li>
                  )}
                </ul>
              </div>

              <div className="pt-3 border-t border-border/50">
                <p className="text-sm text-muted-foreground">
                  Un administrador revisará tu solicitud pronto. Recibirás un email cuando tu cuenta sea aprobada.
                </p>
              </div>
            </div>

            <div className="space-y-2 text-sm text-muted-foreground">
              <p className="font-medium text-foreground">¿Qué sigue?</p>
              <ul className="list-inside list-disc space-y-1">
                <li>El administrador verificará tu información</li>
                <li>Te asignará los permisos correspondientes</li>
                <li>Recibirás un email de confirmación</li>
                <li>Podrás acceder al sistema completo</li>
              </ul>
            </div>

            <form action={handleSignOut}>
              <Button type="submit" variant="outline" className="w-full bg-transparent">
                Cerrar Sesión
              </Button>
            </form>
          </CardContent>
        </Card>

        <p className="mt-6 text-center text-xs text-muted-foreground">
          Si tienes alguna duda, contacta al administrador del sistema
        </p>
      </div>
    </div>
  )
}
