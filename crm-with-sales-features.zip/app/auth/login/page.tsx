"use client"

import type React from "react"
import { useEffect, useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Alert, AlertDescription } from "@/components/ui/alert"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { Package, AlertCircle } from "lucide-react"

export default function LoginPage() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [error, setError] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const router = useRouter()

  useEffect(() => {
    const params = new URLSearchParams(window.location.search)
    const errorParam = params.get("error")
    if (errorParam) {
      setError(errorParam === "unauthorized" ? "Debes iniciar sesión para acceder a esta página" : errorParam)
    }
  }, [])

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    const supabase = createClient()
    setIsLoading(true)
    setError(null)

    try {
      const { data: authData, error: authError } = await supabase.auth.signInWithPassword({
        email,
        password,
      })

      if (authError) throw authError
      if (!authData.user) throw new Error("No se pudo iniciar sesión")

      const { data: usuarioCrm, error: crmError } = await supabase
        .from("usuarios_crm")
        .select("*")
        .eq("email", email)
        .maybeSingle()

      if (crmError) {
        console.error("CRM lookup error:", crmError)
        throw new Error("Error al verificar el estado de tu cuenta")
      }

      if (!usuarioCrm) {
        await supabase.auth.signOut()
        throw new Error(
          "Tu cuenta no está completamente configurada. Por favor, contacta al administrador o intenta registrarte nuevamente.",
        )
      }

      if (usuarioCrm.estado === "pendiente_aprobacion") {
        router.push("/auth/pendiente")
        return
      }

      if (usuarioCrm.estado === "rechazado") {
        await supabase.auth.signOut()
        throw new Error("Tu cuenta ha sido rechazada. Contacta al administrador.")
      }

      if (usuarioCrm.estado === "suspendido") {
        await supabase.auth.signOut()
        throw new Error("Tu cuenta ha sido suspendida. Contacta al administrador.")
      }

      if (usuarioCrm.rol === "vendedor") {
        router.push("/vendedor")
      } else if (usuarioCrm.rol === "cliente") {
        router.push("/cliente")
      } else if (usuarioCrm.rol === "admin") {
        router.push("/admin")
      } else {
        router.push("/dashboard")
      }
    } catch (error: unknown) {
      console.error("Login error:", error)
      setError(error instanceof Error ? error.message : "Error al iniciar sesión")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="flex min-h-screen w-full items-center justify-center bg-gradient-to-br from-background via-secondary/20 to-background p-4">
      <div className="w-full max-w-md">
        <div className="mb-8 flex flex-col items-center gap-2">
          <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary">
            <Package className="h-6 w-6 text-primary-foreground" />
          </div>
          <h1 className="text-2xl font-semibold text-foreground">Sistema de Ventas CRM</h1>
          <p className="text-sm text-muted-foreground">Gestión de pedidos y clientes</p>
        </div>

        <Card className="border-border/50 shadow-lg">
          <CardHeader className="space-y-1">
            <CardTitle className="text-2xl font-semibold">Iniciar Sesión</CardTitle>
            <CardDescription>Ingresa tus credenciales para acceder al sistema</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleLogin} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="tu@email.com"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="h-11"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="password">Contraseña</Label>
                <Input
                  id="password"
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="h-11"
                />
              </div>
              {error && (
                <Alert variant="destructive">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}
              <Button type="submit" className="h-11 w-full" disabled={isLoading}>
                {isLoading ? "Iniciando sesión..." : "Iniciar Sesión"}
              </Button>
            </form>
            <div className="mt-6 text-center text-sm">
              <span className="text-muted-foreground">¿No tienes una cuenta? </span>
              <Link href="/auth/sign-up" className="font-medium text-primary hover:underline">
                Solicitar Acceso
              </Link>
            </div>
          </CardContent>
        </Card>

        <p className="mt-6 text-center text-xs text-muted-foreground">
          Al iniciar sesión, aceptas nuestros términos de servicio y política de privacidad
        </p>
      </div>
    </div>
  )
}
