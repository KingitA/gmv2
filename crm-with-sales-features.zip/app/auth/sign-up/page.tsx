"use client"

import type React from "react"

import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { useState } from "react"
import { Package } from "lucide-react"

export default function SignUpPage() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [repeatPassword, setRepeatPassword] = useState("")
  const [nombre, setNombre] = useState("")
  const [telefono, setTelefono] = useState("")
  const [cuit, setCuit] = useState("")
  const [direccion, setDireccion] = useState("")
  const [tipoSolicitud, setTipoSolicitud] = useState<"vendedor" | "cliente">("cliente")
  const [error, setError] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const router = useRouter()

  const handleSignUp = async (e: React.FormEvent) => {
    e.preventDefault()
    const supabase = createClient()
    setIsLoading(true)
    setError(null)

    if (password !== repeatPassword) {
      setError("Las contraseñas no coinciden")
      setIsLoading(false)
      return
    }

    if (password.length < 6) {
      setError("La contraseña debe tener al menos 6 caracteres")
      setIsLoading(false)
      return
    }

    try {
      // Create auth user
      const { data: authData, error: authError } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            nombre: nombre,
          },
        },
      })

      if (authError) throw authError
      if (!authData.user) throw new Error("No se pudo crear el usuario")

      // nombre_completo -> nombre, viajante_id -> vendedor_id, removed empresa
      const { error: crmError } = await supabase.from("usuarios_crm").insert({
        id: authData.user.id,
        email: email,
        nombre: nombre,
        telefono: telefono || null,
        cuit: cuit || null,
        direccion: direccion || null,
        rol: "pendiente", // Always 'pendiente' until admin approves
        estado: "pendiente_aprobacion", // Changed from 'pendiente' to 'pendiente_aprobacion'
        cliente_id: null,
        vendedor_id: null,
        observaciones: `Solicitud de cuenta tipo: ${tipoSolicitud}`, // Store requested type in observations
      })

      if (crmError) {
        console.error("[v0] Signup error:", crmError.message)
        throw new Error(crmError.message)
      }

      // Redirect to pending page
      router.push("/auth/pendiente")
    } catch (error: unknown) {
      console.error("[v0] Signup error:", error)
      setError(error instanceof Error ? error.message : "Error al crear la cuenta")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="flex min-h-screen w-full items-center justify-center bg-gradient-to-br from-background via-secondary/20 to-background p-4">
      <div className="w-full max-w-md">
        <div className="mb-8 flex flex-col items-center gap-2">
          <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary">
            <Package className="h-6 w-6 text-primary-foreground" />
          </div>
          <h1 className="text-2xl font-semibold text-foreground">Sistema de Ventas CRM</h1>
          <p className="text-sm text-muted-foreground">Solicita acceso al sistema</p>
        </div>

        <Card className="border-border/50 shadow-lg">
          <CardHeader className="space-y-1">
            <CardTitle className="text-2xl font-semibold">Solicitar Cuenta</CardTitle>
            <CardDescription>Tu solicitud será revisada por un administrador</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSignUp} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="nombre">Nombre Completo *</Label>
                <Input
                  id="nombre"
                  type="text"
                  placeholder="Juan Pérez"
                  required
                  value={nombre}
                  onChange={(e) => setNombre(e.target.value)}
                  className="h-11"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="email">Email *</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="tu@email.com"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="h-11"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="telefono">Teléfono *</Label>
                <Input
                  id="telefono"
                  type="tel"
                  placeholder="+54 9 11 1234-5678"
                  required
                  value={telefono}
                  onChange={(e) => setTelefono(e.target.value)}
                  className="h-11"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="cuit">CUIT (opcional)</Label>
                <Input
                  id="cuit"
                  type="text"
                  placeholder="20-12345678-9"
                  value={cuit}
                  onChange={(e) => setCuit(e.target.value)}
                  className="h-11"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="direccion">Dirección (opcional)</Label>
                <Input
                  id="direccion"
                  type="text"
                  placeholder="Calle 123, Ciudad"
                  value={direccion}
                  onChange={(e) => setDireccion(e.target.value)}
                  className="h-11"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="tipoSolicitud">Tipo de Cuenta *</Label>
                <Select
                  value={tipoSolicitud}
                  onValueChange={(value: "vendedor" | "cliente") => setTipoSolicitud(value)}
                >
                  <SelectTrigger className="h-11">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="cliente">Cliente - Realizar pedidos</SelectItem>
                    <SelectItem value="vendedor">Vendedor - Gestionar clientes y pedidos</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="password">Contraseña *</Label>
                <Input
                  id="password"
                  type="password"
                  placeholder="Mínimo 6 caracteres"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="h-11"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="repeat-password">Repetir Contraseña *</Label>
                <Input
                  id="repeat-password"
                  type="password"
                  required
                  value={repeatPassword}
                  onChange={(e) => setRepeatPassword(e.target.value)}
                  className="h-11"
                />
              </div>

              {error && <div className="rounded-md bg-destructive/10 p-3 text-sm text-destructive">{error}</div>}

              <Button type="submit" className="h-11 w-full" disabled={isLoading}>
                {isLoading ? "Enviando solicitud..." : "Solicitar Acceso"}
              </Button>
            </form>
            <div className="mt-6 text-center text-sm">
              <span className="text-muted-foreground">¿Ya tienes una cuenta? </span>
              <Link href="/auth/login" className="font-medium text-primary hover:underline">
                Iniciar Sesión
              </Link>
            </div>
          </CardContent>
        </Card>

        <p className="mt-6 text-center text-xs text-muted-foreground">
          Tu solicitud será revisada por un administrador. Recibirás un email cuando sea aprobada.
        </p>
      </div>
    </div>
  )
}
