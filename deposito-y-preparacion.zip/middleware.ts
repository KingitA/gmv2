import { updateSession } from "@/lib/supabase/middleware"
import type { NextRequest } from "next/server"
import { NextResponse } from "next/server"

export async function middleware(request: NextRequest) {
  if (request.nextUrl.pathname === "/deposito/login") {
    return NextResponse.next()
  }

  if (request.nextUrl.pathname.startsWith("/deposito")) {
    return await updateSession(request)
  }

  // For all other routes, just update session
  return await updateSession(request)
}

export const config = {
  matcher: ["/((?!_next/static|_next/image|favicon.ico|.*\\.(?:svg|png|jpg|jpeg|gif|webp)$).*)"],
}
