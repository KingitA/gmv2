-- Tabla profiles para manejar roles de usuarios
CREATE TABLE IF NOT EXISTS profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email VARCHAR(255) NOT NULL,
  rol VARCHAR(50) NOT NULL DEFAULT 'vendedor' CHECK (rol IN ('vendedor', 'operario_deposito', 'admin')),
  nombre VARCHAR(255),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Índices para profiles
CREATE INDEX IF NOT EXISTS idx_profiles_rol ON profiles(rol);
CREATE INDEX IF NOT EXISTS idx_profiles_email ON profiles(email);

-- Tabla para sesiones de picking (cuando un operario toma un pedido)
CREATE TABLE IF NOT EXISTS picking_sesiones (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  pedido_id UUID NOT NULL REFERENCES pedidos(id) ON DELETE CASCADE,
  usuario_id UUID NOT NULL REFERENCES auth.users(id),
  usuario_email VARCHAR(255) NOT NULL,
  estado VARCHAR(50) NOT NULL DEFAULT 'EN_PROGRESO' CHECK (estado IN ('EN_PROGRESO', 'TERMINADO', 'CANCELADO')),
  inicio_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
  fin_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Índices para picking_sesiones
CREATE INDEX IF NOT EXISTS idx_picking_sesiones_pedido ON picking_sesiones(pedido_id);
CREATE INDEX IF NOT EXISTS idx_picking_sesiones_usuario ON picking_sesiones(usuario_id);
CREATE INDEX IF NOT EXISTS idx_picking_sesiones_estado ON picking_sesiones(estado);

-- Tabla para registrar cada escaneo de código de barras
CREATE TABLE IF NOT EXISTS picking_scans_log (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  picking_sesion_id UUID NOT NULL REFERENCES picking_sesiones(id) ON DELETE CASCADE,
  pedido_item_id UUID NOT NULL REFERENCES pedidos_detalle(id),
  articulo_id UUID NOT NULL REFERENCES articulos(id),
  ean_leido VARCHAR(255) NOT NULL,
  cantidad_sumada NUMERIC(10, 2) NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Índices para picking_scans_log
CREATE INDEX IF NOT EXISTS idx_picking_scans_sesion ON picking_scans_log(picking_sesion_id);
CREATE INDEX IF NOT EXISTS idx_picking_scans_pedido_item ON picking_scans_log(pedido_item_id);

-- Agregar columnas necesarias a pedidos_detalle si no existen
DO $$ 
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns 
                 WHERE table_name='pedidos_detalle' AND column_name='cantidad_preparada') THEN
    ALTER TABLE pedidos_detalle ADD COLUMN cantidad_preparada NUMERIC(10, 2) DEFAULT 0;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns 
                 WHERE table_name='pedidos_detalle' AND column_name='estado_item') THEN
    ALTER TABLE pedidos_detalle ADD COLUMN estado_item VARCHAR(50) DEFAULT 'PENDIENTE' 
      CHECK (estado_item IN ('PENDIENTE', 'PARCIAL', 'COMPLETO', 'FALTANTE'));
  END IF;
END $$;

-- Agregar columna asignado_a en pedidos si no existe
DO $$ 
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns 
                 WHERE table_name='pedidos' AND column_name='asignado_a') THEN
    ALTER TABLE pedidos ADD COLUMN asignado_a VARCHAR(255);
  END IF;
END $$;

-- Función para crear profile automáticamente al registrarse un usuario
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (id, email, rol)
  VALUES (NEW.id, NEW.email, 'vendedor');
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger para crear profile automático
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- RLS Policies para profiles
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view all profiles"
  ON profiles FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can update their own profile"
  ON profiles FOR UPDATE
  TO authenticated
  USING (auth.uid() = id);

-- RLS Policies para picking_sesiones
ALTER TABLE picking_sesiones ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view all picking sessions"
  ON picking_sesiones FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can create picking sessions"
  ON picking_sesiones FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Users can update their own picking sessions"
  ON picking_sesiones FOR UPDATE
  TO authenticated
  USING (usuario_id = auth.uid());

-- RLS Policies para picking_scans_log
ALTER TABLE picking_scans_log ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view all scan logs"
  ON picking_scans_log FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can create scan logs"
  ON picking_scans_log FOR INSERT
  TO authenticated
  WITH CHECK (true);
