-- Create test user for deposito with deposito role
-- Run this script after the user is authenticated in Supabase

-- Updated to work directly with existing user
INSERT INTO profiles (id, email, rol, nombre)
VALUES (
  (SELECT id FROM auth.users WHERE email = 'juancruzrossi072@gmail.com'),
  'juancruzrossi072@gmail.com',
  'deposito',
  'Juan Cruz Rossi'
)
ON CONFLICT (id) 
DO UPDATE SET 
  rol = 'deposito',
  nombre = 'Juan Cruz Rossi',
  updated_at = NOW();

-- Verify the update
SELECT id, email, rol, nombre FROM profiles WHERE email = 'juancruzrossi072@gmail.com';
