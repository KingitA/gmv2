-- Modificar el constraint de la tabla profiles para permitir el rol "deposito"
-- en lugar de "operario_deposito"

ALTER TABLE profiles DROP CONSTRAINT IF EXISTS profiles_rol_check;

ALTER TABLE profiles ADD CONSTRAINT profiles_rol_check 
  CHECK (rol IN ('vendedor', 'deposito', 'admin'));

-- Actualizar cualquier usuario que tenga "operario_deposito" a "deposito"
UPDATE profiles SET rol = 'deposito' WHERE rol = 'operario_deposito';

-- Verificar cambios
SELECT id, email, rol, nombre FROM profiles;
