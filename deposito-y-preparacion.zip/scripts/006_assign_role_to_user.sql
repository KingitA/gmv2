-- Asigna rol de operario_deposito al usuario 4e2b43c5-7462-4588-8d8a-8ead1c8042ec

-- Elimina el perfil si existe para empezar de cero
DELETE FROM profiles WHERE id = '4e2b43c5-7462-4588-8d8a-8ead1c8042ec';

-- Crea el perfil con rol de operario
INSERT INTO profiles (id, rol, nombre, created_at)
VALUES (
  '4e2b43c5-7462-4588-8d8a-8ead1c8042ec',
  'operario_deposito',
  'Juan Cruz Rossi',
  now()
);

-- Verifica que se creó correctamente
SELECT id, rol, nombre FROM profiles WHERE id = '4e2b43c5-7462-4588-8d8a-8ead1c8042ec';
