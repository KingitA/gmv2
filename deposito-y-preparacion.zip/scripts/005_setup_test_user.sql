-- Primero verificar si ya existe el perfil para cualquier usuario con ese email
-- Si existe, actualizar el rol. Si no, insertar.

-- NOTA: Este script actualiza el rol del usuario test@local si ya se registró
-- O puedes ejecutar esto después de registrarte manualmente en /auth/sign-up

-- Buscar el usuario por email en auth.users y crear/actualizar su perfil
DO $$
DECLARE
  v_user_id uuid;
BEGIN
  -- Buscar el UUID del usuario con email test@local
  SELECT id INTO v_user_id 
  FROM auth.users 
  WHERE email = 'test@local';
  
  -- Si existe el usuario
  IF v_user_id IS NOT NULL THEN
    -- Insertar o actualizar el perfil
    INSERT INTO profiles (id, email, nombre, rol, created_at, updated_at)
    VALUES (
      v_user_id,
      'test@local',
      'Operario de Prueba',
      'operario_deposito',
      NOW(),
      NOW()
    )
    ON CONFLICT (id) 
    DO UPDATE SET
      rol = 'operario_deposito',
      nombre = 'Operario de Prueba',
      updated_at = NOW();
      
    RAISE NOTICE 'Perfil actualizado para usuario test@local con UUID: %', v_user_id;
  ELSE
    RAISE NOTICE 'Usuario test@local no encontrado. Regístrate primero en /auth/sign-up con email: test@local y password: 123456';
  END IF;
END $$;

-- Crear algunos pedidos de prueba si no existen
DO $$
DECLARE
  v_cliente_id uuid;
  v_pedido_id uuid;
  v_articulo_id uuid;
BEGIN
  -- Tomar un cliente existente al azar
  SELECT id INTO v_cliente_id FROM clientes LIMIT 1;
  
  -- Tomar un artículo existente al azar
  SELECT id INTO v_articulo_id FROM articulos WHERE ean13 IS NOT NULL LIMIT 1;
  
  -- Si hay cliente y artículo, crear un pedido de prueba
  IF v_cliente_id IS NOT NULL AND v_articulo_id IS NOT NULL THEN
    INSERT INTO pedidos (
      id, numero_pedido, cliente_id, fecha, estado, prioridad,
      subtotal, total, created_at, observaciones
    ) VALUES (
      gen_random_uuid(),
      'TEST-001',
      v_cliente_id,
      CURRENT_DATE,
      'PENDIENTE',
      1,
      1000,
      1000,
      NOW(),
      'Pedido de prueba para depósito'
    )
    RETURNING id INTO v_pedido_id;
    
    -- Agregar detalle al pedido
    INSERT INTO pedidos_detalle (
      id, pedido_id, articulo_id, cantidad, precio_base, subtotal,
      estado_item, cantidad_preparada, created_at
    ) VALUES (
      gen_random_uuid(),
      v_pedido_id,
      v_articulo_id,
      5,
      100,
      500,
      'PENDIENTE',
      0,
      NOW()
    );
    
    RAISE NOTICE 'Pedido de prueba TEST-001 creado correctamente';
  ELSE
    RAISE NOTICE 'No hay clientes o artículos en la base de datos. Agrega datos primero.';
  END IF;
END $$;
