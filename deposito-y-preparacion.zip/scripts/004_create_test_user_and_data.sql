-- IMPORTANTE: Este script crea un usuario de prueba y datos de ejemplo
-- Solo ejecutar en entorno de desarrollo/pruebas

-- Insertar usuario de prueba en profiles (asumiendo que ya existe en auth.users)
-- Si el usuario auth con email test@local ya existe, actualizar su rol
UPDATE profiles 
SET rol = 'operario_deposito', nombre = 'Operario Prueba'
WHERE email = 'test@local';

-- Si no existe, necesitarás crear el usuario en Supabase Auth primero:
-- Email: test@local
-- Password: 123456
-- Luego este script actualizará el rol automáticamente

-- Crear algunos pedidos de prueba si no existen
-- (Asumiendo que ya tienes clientes y artículos creados)

-- Nota: Ajusta estos IDs según tus datos reales
-- Este es solo un ejemplo de cómo estructurar los datos de prueba
