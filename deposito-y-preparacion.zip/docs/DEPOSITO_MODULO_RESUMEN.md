# MÓDULO DEPÓSITO / PREPARACIÓN DE PEDIDOS
**Sistema ERP+CRM - Documentación No Técnica**

---

## RESUMEN EJECUTIVO

El módulo de Depósito elimina completamente el uso de papel en la preparación de pedidos, reemplazando las listas impresas por un sistema digital guiado con validación por escaneo de códigos de barras. Esto evita errores humanos (confundir artículos, cantidades incorrectas), mejora la velocidad de preparación y proporciona trazabilidad completa de quién preparó cada pedido y cuándo.

### Beneficios Clave:
- **Cero papel**: Todo el proceso es digital en tablets o dispositivos móviles
- **Validación automática**: El escaneo verifica que el artículo correcto sea el que se está preparando
- **Control de cantidades**: El sistema suma automáticamente las unidades escaneadas y alerta cuando se completa
- **Trazabilidad**: Registro de quién, cuándo y qué artículos preparó cada operario
- **Reducción de errores**: No hay confusión entre productos similares o errores de lectura manual
- **Velocidad**: Los operarios ven en tiempo real qué artículos faltan preparar

---

## 1. FLUJO OPERATIVO COMPLETO

### 1.1 Inicio de Sesión
El operario de depósito ingresa con sus credenciales en `/deposito/login`. El sistema verifica que tenga el rol "deposito" asignado. Si no tiene permisos, se le niega el acceso.

### 1.2 Cola de Pedidos Pendientes
Una vez autenticado, el operario ve una lista de todos los pedidos con estado:
- **PENDIENTE**: Nuevos pedidos sin asignar
- **EN PREPARACIÓN**: Pedidos que ya fueron tomados por algún operario

Los pedidos se ordenan por:
1. **Prioridad** (pedidos urgentes primero)
2. **Fecha** (más antiguos primero)

Cada tarjeta de pedido muestra:
- Número de pedido
- Cliente y localidad
- Fecha
- Total del pedido
- Badge visual del estado y prioridad

### 1.3 Tomar un Pedido
El operario presiona el botón **"EMPEZAR"** en el pedido que desea preparar:
- El sistema cambia el estado del pedido a `en_preparacion`
- Asigna el pedido al operario (guarda su email en `asignado_a`)
- Crea una sesión de picking para trackear el tiempo y los escaneos
- Redirecciona a la pantalla de preparación

### 1.4 Pantalla de Preparación (El corazón del picking)

El operario ve:

**Header fijo:**
- Información del pedido (número, cliente, localidad)
- Resumen visual con contadores:
  - **Completos** (verde): Artículos preparados al 100%
  - **Pendientes** (amarillo): Aún no escaneados
  - **Parciales** (naranja): Preparados pero falta cantidad
  - **Faltantes** (rojo): Artículos sin stock

**Lista de artículos:**
Cada artículo muestra:
- SKU y descripción
- Badge de estado (PENDIENTE, COMPLETO, PARCIAL, FALTANTE)
- Código EAN para referencia
- Barra de progreso visual: X/Y unidades preparadas
- Botones de acción según el estado

**Footer fijo:**
- Botón grande **"ESCANEAR ARTÍCULO"**
- Botón **"FINALIZAR PREPARACIÓN"** (activo solo cuando no hay pendientes)

### 1.5 Proceso de Escaneo

El operario presiona **"ESCANEAR ARTÍCULO"** y se abre un diálogo:

1. **Escaneo o ingreso manual del EAN**:
   - Puede usar un lector de códigos o escribir el EAN manualmente
   - El sistema busca el artículo en el pedido

2. **Validación**:
   - ✅ **Artículo correcto**: Si el EAN pertenece a un artículo del pedido, muestra:
     - Descripción y SKU
     - Cantidad pedida vs. cantidad ya preparada
     - Input para ajustar cuántas unidades se están sumando
   
   - ❌ **Artículo incorrecto**: Si el EAN no pertenece al pedido:
     - Muestra error: "Este artículo no forma parte del pedido"
     - Evita preparar productos equivocados

3. **Confirmación**:
   - Operario confirma la cantidad a sumar (por defecto 1)
   - El sistema actualiza:
     - `cantidad_preparada` += cantidad sumada
     - Cambia `estado_item` a COMPLETO si se alcanzó la cantidad pedida
     - Registra el escaneo en `picking_scans_log` (trazabilidad)
   - Toast de confirmación: "1 unidad agregada a [Nombre del artículo]"

### 1.6 Manejo de Faltantes y Parciales

**Faltante**: 
- Si un artículo no hay stock disponible
- Operario presiona **"Faltante"**
- Sistema marca el item como `FALTANTE`
- El pedido puede continuar sin ese artículo

**Parcial**:
- Si se preparó parte de la cantidad solicitada
- Operario presiona **"Cerrar"**
- Sistema marca como `PARCIAL` si cantidad_preparada < cantidad pedida
- O como `COMPLETO` si se alcanzó la cantidad

### 1.7 Finalización del Pedido

Cuando todos los artículos están en estado COMPLETO, PARCIAL o FALTANTE:
- El botón **"FINALIZAR PREPARACIÓN"** se activa (verde)
- Al presionarlo:
  - Cambia el estado del pedido a `listo`
  - Cierra la sesión de picking (registra `fin_at`)
  - El pedido desaparece de la cola de pendientes
  - El operario vuelve a la bandeja principal

Si aún hay artículos PENDIENTES:
- El botón muestra: **"HAY X ARTÍCULO(S) PENDIENTE(S)"** (deshabilitado)
- Obliga al operario a resolver todos los items antes de finalizar

---

## 2. PREVENCIÓN DE ERRORES

### 2.1 El problema del "X/F" (Equivocación/Faltante)
**Antes**: En listas de papel, el operario marcaba con "X" (listo) o "F" (faltante), pero:
- Podía confundir productos similares
- Errores de lectura de cantidad
- No había validación de que el producto sea el correcto

**Ahora**: 
- El escaneo OBLIGA a que el código EAN coincida
- Si escanea un producto equivocado, el sistema lo rechaza
- No hay ambigüedad: el artículo correcto tiene su EAN único

### 2.2 Salteos y Omisiones
**Antes**: Era fácil saltear un artículo en la lista de papel

**Ahora**:
- Contador visual muestra cuántos PENDIENTES quedan
- El botón de finalizar está deshabilitado hasta resolver todos
- Lista ordenada y visual facilita ver qué falta

### 2.3 Confusión de Artículos Similares
**Antes**: "Shampoo Sedal 400ml" vs "Shampoo Sedal 500ml" podían confundirse

**Ahora**:
- Cada producto tiene EAN único
- El escaneo valida el producto exacto
- Descripción completa + SKU visibles en pantalla

---

## 3. MEJORAS EN PRECISIÓN Y VELOCIDAD

### Precisión:
- **Validación automática**: 100% de certeza de que se prepara el producto correcto
- **Control de cantidades**: No se puede "pasar de largo" la cantidad pedida
- **Trazabilidad**: Registro de cada escaneo con timestamp

### Velocidad:
- **Sin búsquedas de papel**: Todo en la pantalla
- **Progreso visual**: El operario sabe exactamente cuánto falta
- **Menos devoluciones**: Al reducir errores, menos pedidos vuelven
- **Métricas**: El sistema puede medir tiempo de preparación por pedido

---

## 4. MÉTRICAS Y REPORTES (Potencial)

El sistema actualmente registra en `picking_sesiones` y `picking_scans_log`:

**Métricas calculables**:
- Tiempo promedio de preparación por pedido
- Artículos escaneados por hora por operario
- Tasa de faltantes por artículo
- Pedidos preparados por día/semana
- Comparativa de rendimiento entre operarios

**Actualmente NO implementado** pero los datos están disponibles para:
- Dashboard de métricas
- Reportes de productividad
- Identificación de cuellos de botella

---

## 5. INTEGRACIÓN CON OTROS MÓDULOS

### 5.1 Con Stock (Pendiente)
**Objetivo**: Validar disponibilidad real antes de tomar el pedido
- Consultar `stock_actual` en tabla `articulos`
- Alertar si hay faltantes antes de empezar
- Actualizar stock al finalizar preparación

**Estado actual**: No está integrado, los faltantes se marcan manualmente

### 5.2 Con Facturación (Listo)
**Objetivo**: Pedidos preparados listos para facturar en "un clic"
- Estado `listo` indica que el pedido está preparado
- El módulo de facturación puede filtrar pedidos listos
- Genera comprobante automáticamente

**Estado actual**: El cambio a `listo` habilita la facturación

---

## 6. ESTADO ACTUAL Y LIMITACIONES

### ✅ Funcionalidades Implementadas:
- Autenticación con roles
- Cola de pedidos ordenada por prioridad
- Toma de pedidos con asignación
- Escaneo con validación de EAN
- Suma automática de cantidades
- Control de estados (completo/parcial/faltante)
- Trazabilidad de sesiones y escaneos
- Finalización de pedidos

### ⚠️ Limitaciones y TODOs:

1. **Impresión de etiquetas**: No genera etiquetas para bultos preparados
2. **Integración con stock**: No descuenta stock automáticamente
3. **Sugerencia de ubicación**: No indica dónde está físicamente cada artículo
4. **Picking por zona**: No agrupa artículos por pasillo/estantería
5. **Múltiples operarios**: No hay coordinación si dos operarios trabajan el mismo pedido
6. **Métricas visuales**: Los datos se registran pero no hay dashboard
7. **Notificaciones**: No alerta cuando un pedido se marca como listo
8. **Substituciones**: No permite reemplazar un artículo faltante por similar
9. **Fotos de bultos**: No captura evidencia visual del pedido preparado
10. **Impresión de remito**: No genera documento de entrega automático

---

## 7. ROI Y JUSTIFICACIÓN

### Antes (con papel):
- Tiempo perdido imprimiendo listas
- Errores de preparación → devoluciones → costos
- Sin trazabilidad de quién cometió el error
- Pedidos mal preparados → clientes insatisfechos
- Imposible medir productividad

### Después (digital):
- Preparación más rápida (operarios no buscan en papel)
- Reducción drástica de errores de artículos equivocados
- Trazabilidad completa para auditorías
- Base de datos para optimización futura
- Clientes reciben exactamente lo que pidieron

**Estimación conservadora**: 
- Reducción de 80% en errores de picking
- Ahorro de 15-20% de tiempo por pedido
- Reducción de devoluciones por error de preparación

---

## CONCLUSIÓN

El módulo de Depósito transforma el picking de pedidos de un proceso manual propenso a errores en un flujo guiado, validado y trazable. La clave está en la **validación por escaneo**, que garantiza que cada artículo preparado es el correcto. Esto no solo mejora la precisión, sino que también aumenta la confianza del cliente y reduce costos operativos por devoluciones.

El sistema está diseñado pensando en operarios de depósito con poca experiencia tecnológica: interfaz simple, botones grandes, feedback visual inmediato y flujo intuitivo. El siguiente paso natural es la integración con stock en tiempo real y la generación automática de documentación de entrega.
