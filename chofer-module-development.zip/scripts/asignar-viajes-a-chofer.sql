-- Script para asignar viajes existentes al chofer Juan Cruz Rossi
-- IMPORTANTE: Solo ejecutar DESPUÉS de ver los resultados del diagnóstico

-- Paso 1: Ver qué viajes se van a actualizar
SELECT 
  id,
  nombre,
  fecha,
  chofer as nombre_chofer_actual
FROM viajes
WHERE chofer ILIKE '%juan%rossi%' 
   OR chofer ILIKE '%rossi%'
ORDER BY fecha DESC;

-- Paso 2: Actualizar los viajes para asignarlos al chofer correcto
-- DESCOMENTA ESTAS LÍNEAS DESPUÉS DE VERIFICAR LOS RESULTADOS DEL PASO 1

/*
UPDATE viajes
SET chofer_id = 'd6ac25bb-8204-474d-9e3c-12c2807ac2b7'
WHERE chofer ILIKE '%juan%rossi%' 
   OR chofer ILIKE '%rossi%';

-- Verificar que se actualizaron correctamente
SELECT 
  id,
  nombre,
  fecha,
  chofer,
  chofer_id
FROM viajes
WHERE chofer_id = 'd6ac25bb-8204-474d-9e3c-12c2807ac2b7'
ORDER BY fecha DESC;
*/
