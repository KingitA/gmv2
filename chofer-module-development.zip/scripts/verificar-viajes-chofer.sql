-- Script para verificar y analizar viajes de choferes
-- Este script te mostrará qué datos tienes en la base

-- 1. Ver todos los choferes en la tabla usuarios
SELECT 
  u.id,
  u.nombre,
  u.email,
  u.estado,
  array_agg(r.nombre) as roles
FROM usuarios u
LEFT JOIN usuarios_roles ur ON u.id = ur.usuario_id
LEFT JOIN roles r ON ur.rol_id = r.id
WHERE r.nombre = 'chofer'
GROUP BY u.id, u.nombre, u.email, u.estado;

-- 2. Ver todos los viajes que existen
SELECT 
  id,
  nombre,
  chofer,
  chofer_id,
  estado,
  fecha,
  vehiculo,
  tipo_transporte
FROM viajes
ORDER BY fecha DESC
LIMIT 20;

-- 3. Ver cuántos pedidos hay asignados a viajes
SELECT 
  v.id as viaje_id,
  v.nombre as viaje_nombre,
  v.chofer,
  v.chofer_id,
  COUNT(p.id) as cantidad_pedidos
FROM viajes v
LEFT JOIN pedidos p ON p.viaje_id = v.id
GROUP BY v.id, v.nombre, v.chofer, v.chofer_id
ORDER BY v.fecha DESC
LIMIT 20;
