-- Script de diagnóstico para verificar viajes y choferes

-- 1. Verificar cuántos viajes hay en total
SELECT 
  'Total de viajes en la base de datos' as descripcion,
  COUNT(*) as cantidad
FROM viajes;

-- 2. Ver todos los viajes con información del chofer
SELECT 
  id,
  nombre as nombre_viaje,
  fecha,
  estado,
  vehiculo,
  chofer,  -- columna de texto con nombre del chofer
  chofer_id  -- columna UUID que debe referenciar a usuarios.id
FROM viajes
ORDER BY fecha DESC
LIMIT 10;

-- 3. Verificar qué choferes existen en la tabla usuarios
SELECT 
  u.id,
  u.nombre,
  u.email,
  r.nombre as rol
FROM usuarios u
JOIN usuarios_roles ur ON u.id = ur.usuario_id
JOIN roles r ON ur.rol_id = r.id
WHERE r.nombre = 'chofer'
AND u.estado = 'activo';

-- 4. Contar viajes por chofer_id (para ver si hay viajes asignados)
SELECT 
  chofer_id,
  COUNT(*) as cantidad_viajes
FROM viajes
WHERE chofer_id IS NOT NULL
GROUP BY chofer_id;

-- 5. Contar viajes con chofer_id NULL pero con nombre de chofer
SELECT 
  'Viajes sin chofer_id pero con nombre de chofer' as descripcion,
  COUNT(*) as cantidad
FROM viajes
WHERE chofer_id IS NULL 
AND chofer IS NOT NULL;
