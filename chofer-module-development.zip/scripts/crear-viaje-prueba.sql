-- Script para crear un viaje de prueba si NO HAY viajes en la base de datos
-- Solo ejecutar si el diagnóstico muestra que no hay viajes

/*
INSERT INTO viajes (
  nombre,
  fecha,
  estado,
  vehiculo,
  chofer,
  chofer_id,
  dinero_nafta,
  gastos_peon,
  gastos_hotel,
  gastos_adicionales,
  observaciones
) VALUES (
  'Viaje de Prueba - Zona Norte',
  CURRENT_DATE,
  'pendiente',
  'Camión Ford 2020',
  'Juan Cruz Rossi',
  'd6ac25bb-8204-474d-9e3c-12c2807ac2b7',
  5000.00,
  0.00,
  0.00,
  0.00,
  'Viaje de prueba para testear el módulo de choferes'
);

-- Verificar que se creó correctamente
SELECT * FROM viajes 
WHERE chofer_id = 'd6ac25bb-8204-474d-9e3c-12c2807ac2b7'
ORDER BY created_at DESC
LIMIT 1;
*/
