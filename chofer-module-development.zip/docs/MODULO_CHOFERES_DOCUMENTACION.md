# Documentación Técnica - Módulo de Choferes
## Sistema ERP+CRM - Gestión de Viajes y Entregas

**Versión:** 1.0  
**Fecha:** 17 de noviembre de 2025  
**Tipo:** Módulo móvil para choferes/viajantes  
**Estado:** En desarrollo activo

---

## Resumen Ejecutivo (Para no técnicos)

### ¿Qué hace este módulo?

El Módulo de Choferes es una aplicación web móvil que permite a los choferes/viajantes gestionar sus rutas de entrega y cobro en tiempo real. Es como tener una "oficina móvil" donde el chofer puede:

- Ver todos sus viajes asignados con los pedidos que debe entregar
- Registrar pagos que recibe de los clientes (efectivo, cheques, transferencias)
- Crear órdenes de devolución cuando un cliente devuelve mercadería
- Consultar el estado de cuenta de cada cliente
- Ver estadísticas de su desempeño

### ¿Por qué es importante?

**Antes:**
- El chofer anotaba todo en papel
- Al volver, pasaba horas cargando datos manualmente
- Había errores de transcripción y papeles perdidos
- El ERP no sabía en tiempo real qué se había cobrado

**Ahora:**
- Todo se registra digitalmente desde el celular
- Los datos llegan al ERP automáticamente
- Se reduce el tiempo de cierre de viaje de 2-3 horas a 15 minutos
- La empresa tiene visibilidad en tiempo real del estado de cobros

### Flujo de trabajo simple

1. **Inicio del día:** El chofer ve en su celular todos los viajes que tiene asignados
2. **Durante la entrega:** Por cada cliente, puede registrar si pagó algo y si devuelve mercadería
3. **Fin del día:** Marca el viaje como completado y todos los datos ya están en el sistema

### Seguridad y control

- Los pagos y devoluciones quedan en estado "pendiente" hasta que el ERP los aprueba
- Solo se pueden hacer operaciones durante viajes activos (no completados)
- Cada acción queda registrada con fecha, hora y usuario

---

## Documentación Técnica Completa (JSON)

\`\`\`json
{
  "modulo": {
    "nombre": "Módulo de Choferes",
    "codigo": "MOD_CHOFERES_V1",
    "descripcion": "Sistema web móvil para gestión de viajes, entregas, cobranzas y devoluciones",
    "tecnologias": {
      "framework": "Next.js 16 (App Router)",
      "runtime": "Next.js (entorno navegador)",
      "lenguaje": "TypeScript 5.x",
      "base_datos": "Supabase (PostgreSQL)",
      "ui": "Tailwind CSS v4 + shadcn/ui",
      "autenticacion": "Supabase Auth",
      "dependencias_principales": [
        "@supabase/supabase-js: latest",
        "next: 16.x",
        "react: 19.2",
        "tailwindcss: 4.x"
      ]
    },
    "arquitectura": {
      "patron": "Server-Side Rendering (SSR) + Client Components",
      "rutas": {
        "tipo": "File-based routing (Next.js App Router)",
        "estructura": "/app/**"
      },
      "componentes": {
        "servidor": "Server Components para data fetching",
        "cliente": "Client Components para interactividad (formularios, búsquedas)"
      }
    }
  },
  
  "entidades_base_datos": [
    {
      "nombre": "viajes",
      "descripcion": "Registro de viajes asignados a choferes",
      "campos_principales": [
        {"nombre": "id", "tipo": "uuid", "descripcion": "Identificador único"},
        {"nombre": "nombre", "tipo": "varchar", "descripcion": "Nombre descriptivo del viaje"},
        {"nombre": "fecha", "tipo": "date", "descripcion": "Fecha del viaje"},
        {"nombre": "estado", "tipo": "varchar", "descripcion": "Estados: pendiente, asignado, en_curso, completado, cancelado"},
        {"nombre": "chofer_id", "tipo": "uuid", "descripcion": "FK a usuarios (rol chofer)"},
        {"nombre": "vehiculo", "tipo": "varchar", "descripcion": "Identificación del vehículo"},
        {"nombre": "dinero_nafta", "tipo": "numeric", "descripcion": "Dinero entregado para nafta"},
        {"nombre": "gastos_peon", "tipo": "numeric", "descripcion": "Dinero para pago de peón"},
        {"nombre": "gastos_hotel", "tipo": "numeric", "descripcion": "Dinero para hotel"},
        {"nombre": "gastos_adicionales", "tipo": "numeric", "descripcion": "Otros gastos"}
      ],
      "relaciones": [
        {"tabla": "usuarios", "tipo": "many-to-one", "campo": "chofer_id"},
        {"tabla": "pedidos", "tipo": "one-to-many", "campo": "viaje_id"},
        {"tabla": "viajes_pagos", "tipo": "one-to-many", "campo": "viaje_id"}
      ]
    },
    {
      "nombre": "pedidos",
      "descripcion": "Pedidos asignados a cada viaje",
      "campos_principales": [
        {"nombre": "id", "tipo": "uuid"},
        {"nombre": "numero_pedido", "tipo": "varchar"},
        {"nombre": "viaje_id", "tipo": "uuid", "descripcion": "FK a viajes"},
        {"nombre": "cliente_id", "tipo": "uuid", "descripcion": "FK a clientes"},
        {"nombre": "fecha", "tipo": "date"},
        {"nombre": "estado", "tipo": "varchar", "descripcion": "Estado del pedido"},
        {"nombre": "total", "tipo": "numeric", "descripcion": "Total del pedido"},
        {"nombre": "bultos", "tipo": "integer", "descripcion": "Cantidad de bultos a entregar"}
      ],
      "relaciones": [
        {"tabla": "viajes", "tipo": "many-to-one", "campo": "viaje_id"},
        {"tabla": "clientes", "tipo": "many-to-one", "campo": "cliente_id"}
      ]
    },
    {
      "nombre": "viajes_pagos",
      "descripcion": "Pagos registrados durante los viajes",
      "campos_principales": [
        {"nombre": "id", "tipo": "uuid"},
        {"nombre": "viaje_id", "tipo": "uuid"},
        {"nombre": "pedido_id", "tipo": "uuid"},
        {"nombre": "cliente_id", "tipo": "uuid"},
        {"nombre": "monto", "tipo": "numeric"},
        {"nombre": "forma_pago", "tipo": "varchar", "descripcion": "efectivo, cheque, transferencia"},
        {"nombre": "fecha", "tipo": "timestamp"},
        {"nombre": "numero_cheque", "tipo": "varchar", "nullable": true},
        {"nombre": "banco", "tipo": "varchar", "nullable": true},
        {"nombre": "fecha_cheque", "tipo": "date", "nullable": true},
        {"nombre": "referencia_transferencia", "tipo": "varchar", "nullable": true},
        {"nombre": "registrado_por", "tipo": "uuid", "descripcion": "FK a usuarios"}
      ]
    },
    {
      "nombre": "devoluciones",
      "descripcion": "Órdenes de devolución creadas en viajes",
      "campos_principales": [
        {"nombre": "id", "tipo": "uuid"},
        {"nombre": "pedido_id", "tipo": "uuid"},
        {"nombre": "cliente_id", "tipo": "uuid"},
        {"nombre": "vendedor_id", "tipo": "uuid", "nullable": true},
        {"nombre": "estado", "tipo": "varchar", "descripcion": "pendiente, aprobado, rechazado"},
        {"nombre": "monto_total", "tipo": "numeric"},
        {"nombre": "retira_viajante", "tipo": "boolean"},
        {"nombre": "observaciones", "tipo": "text"},
        {"nombre": "fecha_confirmacion", "tipo": "timestamp", "nullable": true},
        {"nombre": "confirmado_por", "tipo": "varchar", "nullable": true}
      ]
    },
    {
      "nombre": "devoluciones_detalle",
      "descripcion": "Artículos incluidos en cada devolución",
      "campos_principales": [
        {"nombre": "id", "tipo": "uuid"},
        {"nombre": "devolucion_id", "tipo": "uuid"},
        {"nombre": "articulo_id", "tipo": "uuid"},
        {"nombre": "cantidad", "tipo": "numeric"},
        {"nombre": "precio_venta_original", "tipo": "numeric"},
        {"nombre": "subtotal", "tipo": "numeric", "descripcion": "Columna generada: cantidad * precio"},
        {"nombre": "fecha_venta_original", "tipo": "date", "nullable": true},
        {"nombre": "comprobante_venta_id", "tipo": "uuid", "nullable": true}
      ]
    },
    {
      "nombre": "pagos_clientes",
      "descripcion": "Registro de pagos de clientes (datos para el ERP)",
      "campos_principales": [
        {"nombre": "id", "tipo": "uuid"},
        {"nombre": "cliente_id", "tipo": "uuid"},
        {"nombre": "vendedor_id", "tipo": "uuid", "nullable": true},
        {"nombre": "monto", "tipo": "numeric"},
        {"nombre": "forma_pago", "tipo": "varchar"},
        {"nombre": "fecha_pago", "tipo": "date"},
        {"nombre": "estado", "tipo": "varchar", "descripcion": "pendiente, aprobado, rechazado"},
        {"nombre": "observaciones", "tipo": "text", "nullable": true}
      ]
    },
    {
      "nombre": "imputaciones",
      "descripcion": "Imputaciones de pagos a comprobantes específicos",
      "campos_principales": [
        {"nombre": "id", "tipo": "uuid"},
        {"nombre": "pago_id", "tipo": "uuid", "descripcion": "FK a pagos_clientes"},
        {"nombre": "comprobante_id", "tipo": "uuid", "descripcion": "FK a comprobantes_venta"},
        {"nombre": "monto_imputado", "tipo": "numeric"},
        {"nombre": "tipo_comprobante", "tipo": "varchar"}
      ]
    },
    {
      "nombre": "comprobantes_venta",
      "descripcion": "Facturas y comprobantes emitidos",
      "campos_principales": [
        {"nombre": "id", "tipo": "uuid"},
        {"nombre": "cliente_id", "tipo": "uuid"},
        {"nombre": "numero_comprobante", "tipo": "varchar"},
        {"nombre": "tipo_comprobante", "tipo": "varchar"},
        {"nombre": "fecha", "tipo": "date"},
        {"nombre": "total_factura", "tipo": "numeric"},
        {"nombre": "saldo_pendiente", "tipo": "numeric"},
        {"nombre": "estado_pago", "tipo": "varchar"}
      ]
    }
  ],

  "pantallas": [
    {
      "ruta": "/login",
      "archivo": "app/login/page.tsx",
      "tipo": "Client Component",
      "nombre": "Pantalla de Login",
      "descripcion": "Autenticación de choferes mediante Supabase Auth",
      "elementos": [
        "Formulario de email y password",
        "Botón de inicio de sesión",
        "Redirección a /dashboard tras login exitoso"
      ],
      "seguridad": {
        "autenticacion": "Supabase Auth (signInWithPassword)",
        "validacion": "Solo usuarios con rol 'chofer' pueden acceder"
      }
    },
    {
      "ruta": "/dashboard",
      "archivo": "app/dashboard/page.tsx",
      "tipo": "Server Component",
      "nombre": "Dashboard Principal",
      "descripcion": "Vista principal del chofer con acceso rápido a funciones",
      "funcionalidades": [
        "Resumen de viajes activos",
        "Acceso a lista de viajes",
        "Estadísticas del período",
        "Información del perfil"
      ]
    },
    {
      "ruta": "/viajes",
      "archivo": "app/viajes/page.tsx",
      "tipo": "Server Component",
      "nombre": "Lista de Viajes",
      "descripcion": "Listado de todos los viajes del chofer organizados por estado",
      "tabs": [
        {
          "nombre": "Activos",
          "descripcion": "Viajes en estado 'asignado' o 'en_curso'",
          "interaccion": "Clickeable para ir a detalle"
        },
        {
          "nombre": "Completados",
          "descripcion": "Viajes finalizados",
          "interaccion": "Solo lectura"
        },
        {
          "nombre": "Cancelados",
          "descripcion": "Viajes cancelados",
          "interaccion": "Solo lectura"
        }
      ],
      "datos_mostrados": [
        "Nombre del viaje",
        "Fecha",
        "Cantidad de pedidos",
        "Estado (badge con color)",
        "Zona/ubicación"
      ],
      "logica_negocio": {
        "obtener_chofer": "Se busca el primer usuario activo con rol 'chofer'",
        "filtrado": "Solo muestra viajes donde viaje.chofer_id = usuario.id"
      }
    },
    {
      "ruta": "/viajes/[id]",
      "archivo": "app/viajes/[id]/page.tsx",
      "tipo": "Server Component",
      "nombre": "Detalle del Viaje",
      "descripcion": "Vista completa de un viaje con tabla de pedidos y acciones",
      "seccion_encabezado": {
        "datos": [
          "Nombre del viaje",
          "Estado (badge)",
          "Fecha",
          "Vehículo",
          "Dinero total para gastos (suma de nafta + peon + hotel + adicionales)"
        ]
      },
      "seccion_tabla_pedidos": {
        "columnas": [
          "Cliente (nombre + número de pedido)",
          "Dirección (calle + localidad)",
          "Bultos",
          "Saldo Anterior",
          "Saldo Actual",
          "Acciones (botones)"
        ],
        "acciones_disponibles": [
          {
            "boton": "Generar Devolución",
            "ruta": "/viajes/[id]/devolucion?pedido=[pedido_id]",
            "condicion": "Solo si viaje.estado = 'asignado' o 'en_curso'"
          },
          {
            "boton": "Imputar Pago",
            "ruta": "/viajes/[id]/pago?pedido=[pedido_id]",
            "condicion": "Solo si viaje.estado = 'asignado' o 'en_curso'"
          }
        ]
      },
      "calculo_saldos": {
        "saldo_anterior": "Suma de comprobantes_venta.saldo_pendiente del cliente (excluyendo pedido actual)",
        "saldo_actual": "pedido.total",
        "total_a_cobrar": "saldo_anterior + saldo_actual"
      },
      "validaciones": {
        "mostrar_botones": "Solo si viaje.estado === 'asignado' o 'en_curso'",
        "mensaje_bloqueado": "Si viaje completado o cancelado: 'Viaje finalizado. No se pueden registrar operaciones.'"
      }
    },
    {
      "ruta": "/viajes/[id]/devolucion",
      "archivo": "app/viajes/[id]/devolucion/page.tsx",
      "tipo": "Client Component",
      "nombre": "Registrar Devolución",
      "descripcion": "Formulario para crear órdenes de devolución de mercadería",
      "flujo": [
        {
          "paso": 1,
          "accion": "Buscar artículo",
          "descripcion": "Input de búsqueda con autocompletado",
          "api_llamada": "GET articulos?descripcion.ilike.%term% o sku.ilike.%term%"
        },
        {
          "paso": 2,
          "accion": "Verificar precio",
          "descripcion": "Al seleccionar artículo, llamar a API para obtener último precio",
          "api_llamada": "GET /api/articulos/ultimo-precio?articulo_id=X&cliente_id=Y&pedido_id=Z",
          "respuestas_posibles": [
            {
              "caso": "Encontrado en pedido actual",
              "resultado": {"encontrado": true, "precio": 1500, "origen": "pedido_actual"}
            },
            {
              "caso": "Encontrado en última factura",
              "resultado": {"encontrado": true, "precio": 1450, "fecha": "2025-10-15", "origen": "ultima_factura"}
            },
            {
              "caso": "No vendido nunca",
              "resultado": {"encontrado": false, "mensaje": "No le hemos vendido este artículo"},
              "accion": "Mostrar toast error y no agregar"
            }
          ]
        },
        {
          "paso": 3,
          "accion": "Agregar a lista",
          "descripcion": "Artículo se agrega con precio obtenido y cantidad inicial 1"
        },
        {
          "paso": 4,
          "accion": "Ajustar cantidades",
          "descripcion": "Usuario puede modificar cantidad de cada artículo"
        },
        {
          "paso": 5,
          "accion": "Completar formulario",
          "campos": [
            {"nombre": "motivo", "tipo": "textarea", "requerido": true, "descripcion": "Razón de la devolución"},
            {"nombre": "retira_viajante", "tipo": "checkbox", "default": true, "descripcion": "Si el chofer retira la mercadería"}
          ]
        },
        {
          "paso": 6,
          "accion": "Enviar",
          "api_llamada": "POST /api/devoluciones",
          "payload": {
            "cliente_id": "uuid",
            "pedido_id": "uuid",
            "vendedor_id": "uuid | null",
            "retira_viajante": "boolean",
            "observaciones": "string",
            "items": [
              {
                "articulo_id": "uuid",
                "cantidad": "number",
                "precio_venta_original": "number",
                "fecha_venta_original": "date | null"
              }
            ]
          }
        }
      ],
      "calculo_automatico": {
        "monto_total": "Suma de todos los items: item.cantidad * item.precio_venta_original"
      },
      "validaciones": [
        "Debe haber al menos 1 artículo",
        "Motivo no puede estar vacío",
        "Solo artículos previamente vendidos al cliente"
      ]
    },
    {
      "ruta": "/viajes/[id]/pago",
      "archivo": "app/viajes/[id]/pago/page.tsx",
      "tipo": "Client Component",
      "nombre": "Registrar Pago",
      "descripcion": "Formulario para registrar pagos de clientes durante el viaje",
      "carga_inicial": {
        "datos_pedido": "Número, cliente, total",
        "comprobantes_pendientes": "Todos los comprobantes_venta con saldo_pendiente > 0 del cliente",
        "monto_sugerido": "Suma de todos los saldos pendientes"
      },
      "formulario_pago": {
        "campos_base": [
          {
            "nombre": "forma_pago",
            "tipo": "select",
            "opciones": ["efectivo", "cheque", "transferencia"],
            "default": "efectivo"
          },
          {
            "nombre": "monto",
            "tipo": "number",
            "validacion": "> 0",
            "descripcion": "Puede ser parcial o total"
          },
          {
            "nombre": "observaciones",
            "tipo": "textarea",
            "requerido": false
          }
        ],
        "campos_condicionales": {
          "si_cheque": [
            {"nombre": "numero_cheque", "tipo": "text", "requerido": true},
            {"nombre": "banco", "tipo": "text", "requerido": true},
            {"nombre": "fecha_cheque", "tipo": "date", "requerido": true}
          ],
          "si_transferencia": [
            {"nombre": "referencia", "tipo": "text", "requerido": true}
          ]
        }
      },
      "seccion_imputaciones": {
        "descripcion": "Lista de comprobantes para seleccionar y asignar montos",
        "por_cada_comprobante": {
          "mostrar": [
            "Tipo y número (ej: Factura #0001-00000123)",
            "Fecha",
            "Saldo pendiente"
          ],
          "interaccion": [
            "Checkbox para seleccionar",
            "Input para monto a imputar (max = saldo_pendiente)"
          ]
        },
        "calculo_total": "Suma de montos_imputar de comprobantes seleccionados"
      },
      "flujo_submit": [
        {
          "paso": 1,
          "accion": "Crear registro en pagos_clientes",
          "api": "POST /api/pagos",
          "datos": {
            "cliente_id": "uuid",
            "vendedor_id": "uuid",
            "monto": "number",
            "forma_pago": "string",
            "fecha_pago": "date (hoy)",
            "estado": "pendiente",
            "detalles": [
              {
                "tipo_pago": "string",
                "monto": "number",
                "numero_cheque": "string | null",
                "banco": "string | null",
                "fecha_cheque": "date | null"
              }
            ],
            "imputaciones": [
              {
                "comprobante_id": "uuid",
                "monto_imputado": "number"
              }
            ]
          }
        },
        {
          "paso": 2,
          "accion": "Crear registro en viajes_pagos",
          "descripcion": "Para tracking del viaje específico",
          "datos_adicionales": {
            "viaje_id": "uuid",
            "pedido_id": "uuid",
            "registrado_por": "uuid (usuario actual)"
          }
        },
        {
          "paso": 3,
          "accion": "Redirección",
          "destino": "/viajes/[id]",
          "mensaje": "Pago registrado correctamente y está pendiente de confirmación"
        }
      ],
      "validaciones": [
        "Monto > 0",
        "Si hay imputaciones, total_imputaciones <= monto_pago",
        "Viaje debe estar en estado 'asignado' o 'en_curso'"
      ]
    }
  ],

  "apis_endpoints": [
    {
      "ruta": "GET /api/articulos/ultimo-precio",
      "archivo": "app/api/articulos/ultimo-precio/route.ts",
      "descripcion": "Obtiene el último precio al que se le vendió un artículo a un cliente",
      "parametros": [
        {"nombre": "articulo_id", "tipo": "uuid", "requerido": true},
        {"nombre": "cliente_id", "tipo": "uuid", "requerido": true},
        {"nombre": "pedido_id", "tipo": "uuid", "requerido": true}
      ],
      "logica": [
        {
          "paso": 1,
          "descripcion": "Buscar en pedidos_detalle del pedido actual",
          "query": "SELECT precio_final FROM pedidos_detalle WHERE pedido_id = X AND articulo_id = Y",
          "si_encontrado": "Retornar {encontrado: true, precio, origen: 'pedido_actual'}"
        },
        {
          "paso": 2,
          "descripcion": "Si no está en pedido actual, buscar en última factura del cliente",
          "query": "SELECT precio_unitario, fecha FROM comprobantes_venta_detalle JOIN comprobantes_venta WHERE cliente_id = X AND articulo_id = Y ORDER BY fecha DESC LIMIT 1",
          "si_encontrado": "Retornar {encontrado: true, precio, fecha, origen: 'ultima_factura'}"
        },
        {
          "paso": 3,
          "descripcion": "Si no se encuentra en ningún lado",
          "retorno": "{encontrado: false, mensaje: 'No le hemos vendido este artículo'}"
        }
      ],
      "respuesta_exitosa": {
        "status": 200,
        "body": {
          "encontrado": true,
          "precio": 1500.50,
          "fecha": "2025-10-15",
          "origen": "pedido_actual"
        }
      }
    },
    {
      "ruta": "POST /api/devoluciones",
      "archivo": "app/api/devoluciones/route.ts",
      "descripcion": "Registra una nueva orden de devolución",
      "body": {
        "cliente_id": "uuid",
        "pedido_id": "uuid",
        "vendedor_id": "uuid | null",
        "retira_viajante": "boolean",
        "observaciones": "string",
        "items": [
          {
            "articulo_id": "uuid",
            "cantidad": "number",
            "precio_venta_original": "number",
            "fecha_venta_original": "date | null"
          }
        ]
      },
      "proceso": [
        {
          "paso": 1,
          "accion": "Crear registro en tabla devoluciones",
          "campos": {
            "estado": "'pendiente'",
            "monto_total": "Calculado automáticamente por columna generada"
          }
        },
        {
          "paso": 2,
          "accion": "Insertar items en devoluciones_detalle",
          "nota": "NO incluir campo 'subtotal' (es columna generada)"
        }
      ],
      "respuesta_exitosa": {
        "status": 200,
        "body": {
          "success": true,
          "devolucion_id": "uuid",
          "monto_total": 5400.75
        }
      },
      "errores_comunes": [
        {
          "caso": "Columna generada incluida",
          "error": "cannot insert a non-DEFAULT value into column 'subtotal'",
          "solucion": "Remover 'subtotal' del insert"
        }
      ]
    },
    {
      "ruta": "POST /api/pagos",
      "archivo": "app/api/pagos/route.ts",
      "descripcion": "Registra un nuevo pago de cliente con imputaciones",
      "body": {
        "cliente_id": "uuid",
        "vendedor_id": "uuid",
        "monto": "number",
        "forma_pago": "string",
        "fecha_pago": "date",
        "observaciones": "string | null",
        "detalles": [
          {
            "tipo_pago": "efectivo | cheque | transferencia",
            "monto": "number",
            "numero_cheque": "string | null",
            "banco": "string | null",
            "fecha_cheque": "date | null"
          }
        ],
        "imputaciones": [
          {
            "comprobante_id": "uuid",
            "monto_imputado": "number"
          }
        ]
      },
      "proceso": [
        {
          "paso": 1,
          "tabla": "pagos_clientes",
          "accion": "INSERT",
          "campos": {
            "estado": "'pendiente'",
            "monto": "from body"
          }
        },
        {
          "paso": 2,
          "tabla": "pagos_detalle",
          "accion": "INSERT (bulk)",
          "descripcion": "Un registro por cada item en detalles[]"
        },
        {
          "paso": 3,
          "tabla": "imputaciones",
          "accion": "INSERT (bulk)",
          "descripcion": "Un registro por cada imputación",
          "validacion": "suma(monto_imputado) <= monto_pago"
        }
      ],
      "respuesta_exitosa": {
        "status": 200,
        "body": {
          "success": true,
          "pago_id": "uuid",
          "monto_total": 15000
        }
      }
    }
  ],

  "workflows": [
    {
      "nombre": "Workflow: Registro completo de entrega con cobro",
      "actores": ["Chofer", "Sistema", "ERP"],
      "pasos": [
        {
          "numero": 1,
          "actor": "Chofer",
          "accion": "Inicia sesión en la app móvil",
          "pantalla": "/login"
        },
        {
          "numero": 2,
          "actor": "Sistema",
          "accion": "Verifica credenciales con Supabase Auth",
          "validacion": "Usuario debe tener rol 'chofer' y estado 'activo'"
        },
        {
          "numero": 3,
          "actor": "Chofer",
          "accion": "Navega a 'Mis Viajes'",
          "pantalla": "/viajes"
        },
        {
          "numero": 4,
          "actor": "Sistema",
          "accion": "Carga viajes del chofer filtrados por chofer_id",
          "query": "SELECT * FROM viajes WHERE chofer_id = X AND estado IN ('asignado', 'en_curso')"
        },
        {
          "numero": 5,
          "actor": "Chofer",
          "accion": "Selecciona un viaje activo",
          "pantalla": "/viajes/[id]"
        },
        {
          "numero": 6,
          "actor": "Sistema",
          "accion": "Muestra tabla de pedidos con saldos calculados",
          "logica": "Por cada pedido: buscar comprobantes pendientes y sumar saldos"
        },
        {
          "numero": 7,
          "actor": "Chofer",
          "accion": "Click en 'Imputar Pago' de un cliente",
          "pantalla": "/viajes/[id]/pago?pedido=Y"
        },
        {
          "numero": 8,
          "actor": "Sistema",
          "accion": "Carga comprobantes pendientes del cliente",
          "query": "SELECT * FROM comprobantes_venta WHERE cliente_id = X AND saldo_pendiente > 0"
        },
        {
          "numero": 9,
          "actor": "Chofer",
          "accion": "Completa formulario de pago",
          "datos": ["forma_pago", "monto", "comprobantes a imputar"]
        },
        {
          "numero": 10,
          "actor": "Sistema",
          "accion": "Registra pago en estado 'pendiente'",
          "tablas": ["pagos_clientes", "pagos_detalle", "imputaciones", "viajes_pagos"]
        },
        {
          "numero": 11,
          "actor": "Sistema",
          "accion": "Muestra confirmación y regresa a detalle del viaje"
        },
        {
          "numero": 12,
          "actor": "ERP",
          "accion": "Administrador revisa pagos pendientes",
          "nota": "Proceso externo al módulo de choferes"
        },
        {
          "numero": 13,
          "actor": "ERP",
          "accion": "Aprueba o rechaza el pago",
          "update": "UPDATE pagos_clientes SET estado = 'aprobado' WHERE id = X"
        }
      ]
    },
    {
      "nombre": "Workflow: Registro de devolución con artículos no facturados en el pedido actual",
      "pasos": [
        {
          "numero": 1,
          "actor": "Chofer",
          "accion": "En detalle de viaje, click 'Generar Devolución'",
          "pantalla": "/viajes/[id]/devolucion?pedido=Y"
        },
        {
          "numero": 2,
          "actor": "Chofer",
          "accion": "Busca artículo por nombre o código",
          "input": "Input con debounce de 500ms"
        },
        {
          "numero": 3,
          "actor": "Sistema",
          "accion": "Muestra resultados de búsqueda",
          "query": "SELECT * FROM articulos WHERE descripcion ILIKE '%term%' LIMIT 10"
        },
        {
          "numero": 4,
          "actor": "Chofer",
          "accion": "Selecciona un artículo",
          "ejemplo": "Detergente Ala 5L"
        },
        {
          "numero": 5,
          "actor": "Sistema",
          "accion": "Llama API para verificar precio",
          "endpoint": "GET /api/articulos/ultimo-precio",
          "flujo": [
            "Busca en pedido actual",
            "Si no está, busca en última factura del cliente",
            "Si no encuentra, muestra error"
          ]
        },
        {
          "numero": 6,
          "actor": "Sistema",
          "accion": "Si artículo no fue vendido antes",
          "mensaje": "Toast error: 'No le hemos vendido este artículo'",
          "resultado": "No se agrega a la lista"
        },
        {
          "numero": 7,
          "actor": "Sistema",
          "accion": "Si artículo fue vendido",
          "resultado": "Se agrega a lista con precio y origen (pedido_actual o ultima_factura)"
        },
        {
          "numero": 8,
          "actor": "Chofer",
          "accion": "Ajusta cantidades de artículos agregados"
        },
        {
          "numero": 9,
          "actor": "Chofer",
          "accion": "Completa motivo y confirma si retira mercadería"
        },
        {
          "numero": 10,
          "actor": "Sistema",
          "accion": "Calcula monto total",
          "formula": "SUM(cantidad * precio_venta_original)"
        },
        {
          "numero": 11,
          "actor": "Chofer",
          "accion": "Click 'Registrar Devolución'"
        },
        {
          "numero": 12,
          "actor": "Sistema",
          "accion": "Registra devolución en estado 'pendiente'",
          "tablas": ["devoluciones", "devoluciones_detalle"]
        },
        {
          "numero": 13,
          "actor": "ERP",
          "accion": "Administrador aprueba/rechaza devolución"
        }
      ]
    }
  ],

  "reglas_negocio": [
    {
      "regla": "RN-001: Control por estado de viaje",
      "descripcion": "El chofer SOLO puede registrar pagos y devoluciones si el viaje está en estado 'asignado' o 'en_curso'",
      "implementacion": [
        "Verificar viaje.estado antes de mostrar botones de acciones",
        "Mostrar mensaje: 'Viaje finalizado. No se pueden registrar operaciones.' si estado = 'completado' o 'cancelado'",
        "Validar estado en backend antes de procesar POST"
      ],
      "pantallas_afectadas": ["/viajes/[id]", "/viajes/[id]/pago", "/viajes/[id]/devolucion"]
    },
    {
      "regla": "RN-002: Aprobación de operaciones",
      "descripcion": "Todos los pagos y devoluciones quedan en estado 'pendiente' hasta ser confirmados desde el ERP",
      "flujo": [
        "Chofer registra → estado = 'pendiente'",
        "ERP revisa → puede 'aprobar' o 'rechazar'",
        "Si rechaza → debe indicar motivo_rechazo"
      ],
      "tablas": ["pagos_clientes.estado", "devoluciones.estado"]
    },
    {
      "regla": "RN-003: Validación de artículos en devoluciones",
      "descripcion": "Solo se pueden devolver artículos que se le hayan vendido previamente al cliente",
      "logica": [
        "Primero buscar en pedido actual del viaje",
        "Si no está, buscar en facturas históricas del cliente",
        "Si nunca se le vendió, mostrar error y no permitir agregar"
      ],
      "mensaje_error": "No le hemos vendido este artículo a este cliente"
    },
    {
      "regla": "RN-004: Cálculo de saldos",
      "descripcion": "El saldo de un cliente se compone de deuda anterior + factura actual",
      "formula": {
        "saldo_anterior": "SUM(comprobantes_venta.saldo_pendiente) WHERE cliente_id = X AND pedido_id != Y",
        "saldo_actual": "pedido.total",
        "total_a_cobrar": "saldo_anterior + saldo_actual"
      },
      "nota": "El saldo anterior NO incluye el pedido actual del viaje"
    },
    {
      "regla": "RN-005: Imputación de pagos",
      "descripcion": "Un pago puede imputarse total o parcialmente a uno o más comprobantes",
      "validaciones": [
        "monto_imputar <= comprobante.saldo_pendiente",
        "SUM(imputaciones.monto_imputado) <= pago.monto",
        "No es obligatorio imputar todo el monto del pago"
      ]
    },
    {
      "regla": "RN-006: Tracking de pagos por viaje",
      "descripcion": "Además de registrar en pagos_clientes, se registra en viajes_pagos para trazabilidad",
      "proposito": "Permite saber qué pagos se recibieron en qué viaje específico",
      "tablas": ["pagos_clientes (para ERP)", "viajes_pagos (para tracking del viaje)"]
    },
    {
      "regla": "RN-007: Autenticación y autorización",
      "descripcion": "Solo usuarios con rol 'chofer' pueden acceder al módulo",
      "implementacion": [
        "Verificar en login: usuarios_roles.rol_id = (SELECT id FROM roles WHERE nombre = 'chofer')",
        "Cada chofer solo ve sus propios viajes: WHERE viaje.chofer_id = usuario_autenticado.id"
      ]
    }
  ],

  "integracion_erp": {
    "descripcion": "El módulo de choferes es un sistema satélite que registra operaciones para ser procesadas por el ERP central",
    "variable_entorno": {
      "nombre": "NEXT_PUBLIC_ERP_URL",
      "valor_actual": "https://v0-inventory-and-sales-system-five.vercel.app",
      "descripcion": "URL base del sistema ERP principal"
    },
    "flujo_datos": {
      "direccion": "Bidireccional",
      "desde_erp": [
        "Asignación de viajes (viajes.chofer_id)",
        "Creación de pedidos (pedidos.viaje_id)",
        "Información de clientes y artículos",
        "Comprobantes de venta"
      ],
      "hacia_erp": [
        "Pagos registrados (pagos_clientes)",
        "Devoluciones creadas (devoluciones)",
        "Tracking de entregas"
      ]
    },
    "apis_llamadas_erp": [
      {
        "endpoint": "GET {ERP_URL}/api/viajes?chofer_id=X",
        "uso": "Obtener lista de viajes del chofer",
        "archivo": "lib/api/choferes.ts"
      },
      {
        "endpoint": "GET {ERP_URL}/api/viajes/{id}",
        "uso": "Obtener detalle de un viaje específico",
        "archivo": "lib/api/choferes.ts"
      },
      {
        "endpoint": "POST {ERP_URL}/api/viajes/{id}/pagos",
        "uso": "Notificar pago al ERP",
        "archivo": "lib/api/choferes.ts"
      }
    ],
    "sincronizacion": {
      "tipo": "Tiempo real vía Supabase",
      "mecanismo": "Ambos sistemas (ERP y módulo choferes) conectan a la misma base de datos Supabase",
      "ventajas": [
        "No hay delay en sincronización",
        "Datos siempre consistentes",
        "Transacciones atómicas"
      ]
    }
  },

  "estado_implementacion": {
    "completado": [
      "✓ Autenticación de choferes",
      "✓ Lista de viajes con filtros por estado",
      "✓ Detalle de viaje con tabla de pedidos",
      "✓ Cálculo de saldos anterior y actual",
      "✓ Formulario de registro de pagos",
      "✓ Imputación de pagos a comprobantes",
      "✓ Formulario de registro de devoluciones",
      "✓ Búsqueda de artículos con autocompletado",
      "✓ Verificación de último precio de artículos",
      "✓ API último-precio (pedido actual + última factura)",
      "✓ API registro de pagos con imputaciones",
      "✓ API registro de devoluciones",
      "✓ Validación por estado de viaje",
      "✓ Tracking de pagos por viaje (viajes_pagos)"
    ],
    "pendiente": [
      "⏳ Módulo de estadísticas del chofer",
      "⏳ Visualización de comprobantes (PDF)",
      "⏳ Firma digital de entregas",
      "⏳ Geolocalización de entregas",
      "⏳ Modo offline con sincronización",
      "⏳ Notificaciones push",
      "⏳ Exportación de reportes"
    ]
  },

  "consideraciones_tecnicas": {
    "performance": {
      "estrategia": "Server-Side Rendering para carga inicial rápida",
      "optimizaciones": [
        "Queries con selects específicos (no SELECT *)",
        "Cálculo de saldos en paralelo con Promise.all",
        "Debounce de 500ms en búsquedas de artículos",
        "Límite de 10 resultados en autocompletados"
      ]
    },
    "seguridad": {
      "autenticacion": "Supabase Auth con JWT",
      "autorizacion": "Row Level Security (RLS) en Supabase",
      "validaciones": [
        "Backend valida todos los datos antes de insertar",
        "Frontend valida formularios antes de enviar",
        "Solo el chofer ve sus propios viajes"
      ]
    },
    "offline_mode": {
      "estado": "Planeado, no implementado",
      "propuesta": "Usar IndexedDB para cache local + queue de operaciones pendientes",
      "desafio": "Sincronizar cuando vuelve conexión sin conflictos"
    }
  },

  "tipos_typescript": {
    "archivo": "lib/types.ts",
    "interfaces_principales": [
      {
        "nombre": "Viaje",
        "campos": ["id", "nombre", "fecha", "estado", "vehiculo", "chofer_id", "dinero_nafta", "gastos_*", "pedidos_count"]
      },
      {
        "nombre": "Pedido",
        "campos": ["id", "numero_pedido", "cliente_id", "cliente_nombre", "direccion", "bultos", "saldo_anterior", "saldo_actual", "total"]
      },
      {
        "nombre": "Pago",
        "campos": ["viaje_id", "pedido_id", "cliente_id", "monto", "forma_pago", "fecha", "numero_cheque", "banco", "referencia"]
      },
      {
        "nombre": "Devolucion",
        "campos": ["pedido_id", "cliente_id", "motivo", "retira_viajante", "items"]
      },
      {
        "nombre": "ArticuloItemDevolucion",
        "campos": ["articulo_id", "descripcion", "cantidad_devolver", "precio", "origen"]
      }
    ]
  },

  "ambientes": {
    "desarrollo": {
      "url": "http://localhost:3000",
      "base_datos": "Supabase (proyecto compartido con ERP)"
    },
    "produccion": {
      "url": "TBD",
      "deployment": "Vercel",
      "nota": "Comparte misma DB de Supabase con ERP principal"
    }
  }
}
\`\`\`

---

## Métricas y KPIs

### Métricas de Negocio
- **Tiempo de cierre de viaje:** Reducción de 2-3 horas → 15 minutos
- **Errores de transcripción:** De ~15% → <2%
- **Visibilidad de cobros:** De 24-48 horas → Tiempo real
- **Satisfacción del chofer:** Encuesta post-implementación (pendiente)

### Métricas Técnicas
- **Tiempo de carga inicial:** <2 segundos (SSR)
- **Tiempo de respuesta APIs:** <500ms promedio
- **Disponibilidad:** 99.5% objetivo
- **Tasa de errores:** <0.5%

---

## Próximos Pasos

### Corto Plazo (Sprint actual)
1. Validar flujo completo de pago + devolución en ambiente de prueba
2. Capacitar a un chofer piloto
3. Realizar prueba de campo de 1 semana

### Mediano Plazo (1-2 meses)
1. Implementar estadísticas del chofer
2. Agregar visualización de comprobantes PDF
3. Habilitar firma digital de entregas
4. Desplegar a producción con todos los choferes

### Largo Plazo (3-6 meses)
1. Modo offline completo con sincronización
2. Geolocalización de entregas
3. Notificaciones push para nuevos viajes
4. Integración con sistema de ruteo óptimo

---

## Glosario

- **Viaje:** Ruta de entrega asignada a un chofer con múltiples paradas/pedidos
- **Pedido:** Orden de compra de un cliente específico dentro de un viaje
- **Imputación:** Asignación de un pago a un comprobante específico
- **Devolución:** Mercadería que el cliente devuelve por distintos motivos
- **Comprobante:** Factura o documento comercial que respalda una venta
- **Saldo pendiente:** Monto que el cliente aún debe de comprobantes anteriores
- **Chofer/Viajante:** Usuario con rol de conductor que realiza entregas

---

## Contacto y Soporte

**Equipo de Desarrollo:**
- Desarrollador Principal: [TBD]
- Arquitecto: [TBD]

**Documentación Externa:**
- Next.js: https://nextjs.org/docs
- Supabase: https://supabase.com/docs
- shadcn/ui: https://ui.shadcn.com

---

*Documento generado el 17 de noviembre de 2025*  
*Última actualización: 17 de noviembre de 2025*
