import { createClient } from '@/lib/supabase/server'
import { redirect } from 'next/navigation'

export default function Home() {
  redirect('/viajes')
}
