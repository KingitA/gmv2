import { NextRequest, NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const supabase = createClient(
      process.env.NEXT_PUBLIC_SUPABASE_URL!,
      process.env.SUPABASE_SERVICE_ROLE_KEY!
    );

    const { data: pedido, error } = await supabase
      .from('pedidos')
      .select(`
        id,
        numero_pedido,
        cliente_id,
        clientes!inner (
          razon_social
        )
      `)
      .eq('id', params.id)
      .single();

    if (error || !pedido) {
      console.error('[v0] Error fetching pedido:', error);
      return NextResponse.json({ error: 'Pedido no encontrado' }, { status: 404 });
    }

    return NextResponse.json({
      id: pedido.id,
      numero_pedido: pedido.numero_pedido,
      cliente_id: pedido.cliente_id,
      cliente_nombre: pedido.clientes.razon_social,
    });
  } catch (error) {
    console.error('[v0] Error en API pedidos:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}
