"use client";

import { useState, useEffect, Suspense } from "react";
import { useRouter, useSearchParams } from 'next/navigation';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import Link from "next/link";
import { useToast } from "@/hooks/use-toast";

const ArrowLeftIcon = () => (
  <svg className="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
  </svg>
);

const Loader2Icon = () => (
  <svg className="h-5 w-5 animate-spin" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none"/>
    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"/>
  </svg>
);

const CreditCardIcon = () => (
  <svg className="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z" />
  </svg>
);

const DollarSignIcon = () => (
  <svg className="h-8 w-8 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
  </svg>
);

interface Comprobante {
  id: string;
  numero_comprobante: string;
  tipo_comprobante: string;
  fecha: string;
  total_factura: number;
  saldo_pendiente: number;
  seleccionado: boolean;
  monto_imputar: number;
}

interface PedidoData {
  id: string;
  numero_pedido: string;
  cliente_id: string;
  cliente_nombre: string;
  total: number;
  viaje_estado: string;
}

function PagoForm({ viajeId }: { viajeId: string }) {
  const router = useRouter();
  const searchParams = useSearchParams();
  const { toast } = useToast();
  const pedidoId = searchParams.get("pedido");

  const [pedido, setPedido] = useState<PedidoData | null>(null);
  const [comprobantes, setComprobantes] = useState<Comprobante[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const [formaPago, setFormaPago] = useState<"efectivo" | "cheque" | "transferencia">("efectivo");
  const [monto, setMonto] = useState("");
  const [observaciones, setObservaciones] = useState("");

  const [numeroCheque, setNumeroCheque] = useState("");
  const [banco, setBanco] = useState("");
  const [fechaCheque, setFechaCheque] = useState("");
  const [referencia, setReferencia] = useState("");

  useEffect(() => {
    const loadPedido = async () => {
      if (!pedidoId) {
        router.push(`/viajes/${viajeId}`);
        return;
      }

      const viajeResponse = await fetch(`/api/viajes/${viajeId}`);
      const viajeData = await viajeResponse.json();

      if (!viajeData || (viajeData.estado !== 'asignado' && viajeData.estado !== 'en_curso')) {
        toast({
          variant: "destructive",
          title: "Viaje no disponible",
          description: "Solo puedes registrar pagos en viajes asignados o en curso",
        });
        router.push(`/viajes/${viajeId}`);
        return;
      }

      const pedidoResponse = await fetch(`/api/pedidos/${pedidoId}?includeComprobantes=true`);
      const pedidoData = await pedidoResponse.json();

      if (!pedidoResponse.ok || !pedidoData) {
        toast({
          variant: "destructive",
          title: "Error",
          description: "No se pudo cargar el pedido",
        });
        router.push(`/viajes/${viajeId}`);
        return;
      }

      const comprobantesConEstado: Comprobante[] = (pedidoData.comprobantes || []).map((comp: any) => ({
        ...comp,
        seleccionado: false,
        monto_imputar: Number(comp.saldo_pendiente),
      }));

      setComprobantes(comprobantesConEstado);

      const totalAPagar = comprobantesConEstado.reduce((sum, c) => sum + Number(c.saldo_pendiente), 0);

      setPedido({
        id: pedidoData.id,
        numero_pedido: pedidoData.numero_pedido,
        cliente_id: pedidoData.cliente_id,
        cliente_nombre: pedidoData.cliente_nombre,
        total: totalAPagar,
        viaje_estado: viajeData.estado,
      });

      setMonto(totalAPagar.toString());
      setIsLoading(false);
    };

    loadPedido();
  }, [pedidoId, viajeId, router, toast]);

  const handleToggleComprobante = (id: string) => {
    setComprobantes(prev => prev.map(comp => 
      comp.id === id ? { ...comp, seleccionado: !comp.seleccionado } : comp
    ));
  };

  const handleMontoImputarChange = (id: string, nuevoMonto: number) => {
    setComprobantes(prev => prev.map(comp => 
      comp.id === id ? { 
        ...comp, 
        monto_imputar: Math.min(Math.max(0, nuevoMonto), Number(comp.saldo_pendiente))
      } : comp
    ));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!pedido) return;

    const montoNumerico = parseFloat(monto);
    if (isNaN(montoNumerico) || montoNumerico <= 0) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Ingresa un monto válido",
      });
      return;
    }

    setIsSubmitting(true);

    try {
      const comprobantesSeleccionados = comprobantes.filter(c => c.seleccionado);
      
      const pagoData = {
        viaje_id: viajeId,
        pedido_id: pedido.id,
        cliente_id: pedido.cliente_id,
        monto: montoNumerico,
        forma_pago: formaPago,
        observaciones: observaciones || undefined,
        ...(formaPago === "cheque" && {
          numero_cheque: numeroCheque,
          banco,
          fecha_cheque: fechaCheque,
        }),
        ...(formaPago === "transferencia" && {
          referencia_transferencia: referencia,
        }),
        detalles: [{
          tipo_pago: formaPago,
          monto: montoNumerico,
          ...(formaPago === "cheque" && {
            numero_cheque: numeroCheque,
            banco,
            fecha_cheque: fechaCheque,
          }),
        }],
        imputaciones: comprobantesSeleccionados.map(comp => ({
          comprobante_id: comp.id,
          monto_imputado: comp.monto_imputar,
        })),
      };

      const response = await fetch('/api/pagos', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(pagoData),
      });

      const resultado = await response.json();

      if (!response.ok) {
        throw new Error(resultado.error || 'Error al registrar pago');
      }

      toast({
        title: "Pago registrado",
        description: "El pago se registró correctamente y está pendiente de confirmación",
      });

      router.push(`/viajes/${viajeId}`);
    } catch (error) {
      console.error("[v0] Error registrando pago:", error);
      
      toast({
        variant: "destructive",
        title: "Error",
        description: "No se pudo registrar el pago. Intenta nuevamente.",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2Icon />
      </div>
    );
  }

  if (!pedido) return null;

  const comprobantesSeleccionados = comprobantes.filter(c => c.seleccionado);
  const totalImputaciones = comprobantesSeleccionados.reduce((sum, c) => sum + c.monto_imputar, 0);

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 to-accent/5">
      <header className="bg-card border-b border-border shadow-sm sticky top-0 z-10">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-3">
            <Link href={`/viajes/${viajeId}`}>
              <Button variant="ghost" size="icon">
                <ArrowLeftIcon />
              </Button>
            </Link>
            <div>
              <h1 className="text-xl font-bold">Registrar Pago</h1>
              <p className="text-sm text-muted-foreground">
                Pedido #{pedido.numero_pedido}
              </p>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-6 space-y-6">
        <Card className="shadow-md bg-primary/5 border-primary/20">
          <CardHeader>
            <CardTitle className="text-lg">{pedido.cliente_nombre}</CardTitle>
            <CardDescription>Total adeudado</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2">
              <DollarSignIcon />
              <span className="text-4xl font-bold text-primary">
                ${pedido.total.toLocaleString("es-AR")}
              </span>
            </div>
          </CardContent>
        </Card>

        <form onSubmit={handleSubmit} className="space-y-4">
          <Card className="shadow-md">
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <CreditCardIcon />
                Datos del Pago
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="forma_pago">Forma de Pago</Label>
                <Select value={formaPago} onValueChange={(value: any) => setFormaPago(value)}>
                  <SelectTrigger className="text-lg h-12">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="efectivo">Efectivo</SelectItem>
                    <SelectItem value="cheque">Cheque</SelectItem>
                    <SelectItem value="transferencia">Transferencia</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="monto">Monto</Label>
                <Input
                  id="monto"
                  type="number"
                  step="0.01"
                  required
                  value={monto}
                  onChange={(e) => setMonto(e.target.value)}
                  className="text-lg h-12"
                  placeholder="0.00"
                />
                <p className="text-xs text-muted-foreground">
                  Puede ser un pago parcial o el total
                </p>
              </div>

              {formaPago === "cheque" && (
                <>
                  <div className="space-y-2">
                    <Label htmlFor="numero_cheque">Número de Cheque</Label>
                    <Input
                      id="numero_cheque"
                      required
                      value={numeroCheque}
                      onChange={(e) => setNumeroCheque(e.target.value)}
                      className="text-lg h-12"
                      placeholder="12345678"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="banco">Banco</Label>
                    <Input
                      id="banco"
                      required
                      value={banco}
                      onChange={(e) => setBanco(e.target.value)}
                      className="text-lg h-12"
                      placeholder="Banco Nación"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="fecha_cheque">Fecha del Cheque</Label>
                    <Input
                      id="fecha_cheque"
                      type="date"
                      required
                      value={fechaCheque}
                      onChange={(e) => setFechaCheque(e.target.value)}
                      className="text-lg h-12"
                    />
                  </div>
                </>
              )}

              {formaPago === "transferencia" && (
                <div className="space-y-2">
                  <Label htmlFor="referencia">Referencia</Label>
                  <Input
                    id="referencia"
                    required
                    value={referencia}
                    onChange={(e) => setReferencia(e.target.value)}
                    className="text-lg h-12"
                    placeholder="TRF123456"
                  />
                </div>
              )}

              <div className="space-y-2">
                <Label htmlFor="observaciones">Observaciones (opcional)</Label>
                <Textarea
                  id="observaciones"
                  value={observaciones}
                  onChange={(e) => setObservaciones(e.target.value)}
                  className="min-h-[80px] text-base"
                  placeholder="Agregar notas sobre el pago..."
                />
              </div>
            </CardContent>
          </Card>

          {comprobantes.length > 0 && (
            <Card className="shadow-md">
              <CardHeader>
                <CardTitle className="text-lg">Imputar a Comprobantes</CardTitle>
                <CardDescription>
                  Selecciona los comprobantes a los que deseas imputar este pago
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                {comprobantes.map((comp) => (
                  <div
                    key={comp.id}
                    className={`border rounded-lg p-4 space-y-3 ${
                      comp.seleccionado ? "bg-primary/5 border-primary" : ""
                    }`}
                  >
                    <div className="flex items-start gap-3">
                      <Checkbox
                        id={`comp-${comp.id}`}
                        checked={comp.seleccionado}
                        onCheckedChange={() => handleToggleComprobante(comp.id)}
                        className="mt-1"
                      />
                      <div className="flex-1">
                        <Label htmlFor={`comp-${comp.id}`} className="text-base font-semibold cursor-pointer">
                          {comp.tipo_comprobante} #{comp.numero_comprobante}
                        </Label>
                        <p className="text-sm text-muted-foreground mt-1">
                          Fecha: {new Date(comp.fecha).toLocaleDateString('es-AR')} | 
                          Saldo: ${Number(comp.saldo_pendiente).toLocaleString('es-AR')}
                        </p>
                      </div>
                    </div>

                    {comp.seleccionado && (
                      <div className="pl-8 space-y-2">
                        <Label htmlFor={`monto-${comp.id}`}>Monto a imputar</Label>
                        <Input
                          id={`monto-${comp.id}`}
                          type="number"
                          step="0.01"
                          min="0"
                          max={comp.saldo_pendiente}
                          value={comp.monto_imputar}
                          onChange={(e) =>
                            handleMontoImputarChange(comp.id, parseFloat(e.target.value) || 0)
                          }
                          className="text-lg h-12 max-w-[200px]"
                        />
                      </div>
                    )}
                  </div>
                ))}

                {comprobantesSeleccionados.length > 0 && (
                  <div className="pt-3 border-t">
                    <div className="flex items-center justify-between">
                      <span className="font-semibold">Total imputado:</span>
                      <span className="font-bold text-lg text-primary">
                        ${totalImputaciones.toLocaleString('es-AR')}
                      </span>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          <div className="flex gap-3">
            <Link href={`/viajes/${viajeId}`} className="flex-1">
              <Button type="button" variant="outline" className="w-full h-12">
                Cancelar
              </Button>
            </Link>
            <Button
              type="submit"
              disabled={isSubmitting}
              className="flex-1 h-12"
            >
              {isSubmitting ? (
                <>
                  <Loader2Icon />
                  <span className="ml-2">Registrando...</span>
                </>
              ) : (
                "Registrar Pago"
              )}
            </Button>
          </div>
        </form>
      </main>
    </div>
  );
}

export default function PagoPage({ params }: { params: { id: string } }) {
  return (
    <Suspense fallback={
      <div className="min-h-screen flex items-center justify-center">
        <svg className="h-8 w-8 animate-spin" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none"/>
          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"/>
        </svg>
      </div>
    }>
      <PagoForm viajeId={params.id} />
    </Suspense>
  );
}
