export interface Viaje {
  id: string
  nombre: string
  fecha: string
  estado: 'pendiente' | 'asignado' | 'en_curso' | 'completado' | 'cancelado'
  vehiculo: string
  chofer_id: string
  chofer_nombre?: string
  chofer_email?: string
  pedidos_count?: number
  total_facturado?: number
  zonas?: string
  dinero_nafta: number
  gastos_peon: number
  gastos_hotel: number
  gastos_adicionales: number
  observaciones?: string
  created_at?: string
}

export interface Pedido {
  id: string
  numero_pedido: string
  fecha: string
  estado: 'pendiente' | 'asignado' | 'en_curso' | 'completado' | 'cancelado'
  cliente_id: string
  cliente_nombre: string
  direccion?: string
  telefono?: string
  localidad?: string
  bultos: number
  saldo_anterior: number
  saldo_actual: number
  total: number
  viaje_id?: string
  observaciones?: string
}

export interface Pago {
  id?: string
  viaje_id: string
  pedido_id: string
  cliente_id: string
  monto: number
  forma_pago: 'efectivo' | 'cheque' | 'transferencia'
  fecha: string
  observaciones?: string
  numero_cheque?: string
  banco?: string
  fecha_cheque?: string
  referencia_transferencia?: string
  registrado_por?: string
}

export interface Devolucion {
  id?: string
  pedido_id: string
  cliente_id: string
  motivo: string
  retira_viajante: boolean
  items: ArticuloItemDevolucion[]
  estado?: string
}

export interface ArticuloItemDevolucion {
  id: string
  articulo_id: string
  descripcion: string
  cantidad_original: number
  cantidad_devolver: number
  seleccionado: boolean
  precio?: number
  fecha_venta?: string
  origen?: 'pedido_actual' | 'ultima_factura'
}

export interface DevolucionItem {
  articulo_id: string
  cantidad: number
  descripcion?: string
}

export interface ResumenPagos {
  total_efectivo: number
  cantidad_cheques: number
  cantidad_transferencias: number
  total_cobrado: number
}

export interface Estadisticas {
  periodo: string
  total_viajes: number
  viajes_finalizados: number
  kilometros_recorridos: number
  pernoctadas: number
  total_facturado: number
  pedidos_entregados: number
  total_cobrado: number
}

export interface Profile {
  id: string
  nombre: string
  email: string
  rol: string
}

export interface Usuario {
  id: string
  nombre: string
  email: string
  telefono?: string
  estado: 'activo' | 'inactivo'
  created_at?: string
  updated_at?: string
}

export interface Role {
  id: string
  nombre: string
  descripcion?: string
}

export interface UsuarioConRoles extends Usuario {
  roles: string[]
}
