import { createClient } from '@/lib/supabase/server'

export async function getUserWithRoles(userId: string) {
  const supabase = await createClient()
  
  const { data, error } = await supabase
    .from('usuarios')
    .select(`
      *,
      usuarios_roles(
        roles(nombre)
      )
    `)
    .eq('id', userId)
    .single()
  
  if (error) throw error
  
  return {
    ...data,
    roles: data.usuarios_roles?.map((ur: any) => ur.roles.nombre) || []
  }
}

export async function hasRole(userId: string, roleName: string) {
  const user = await getUserWithRoles(userId)
  return user.roles.includes(roleName)
}

export async function getUsersByRole(roleName: string) {
  const supabase = await createClient()
  
  const { data, error } = await supabase
    .from('usuarios')
    .select(`
      id,
      nombre,
      email,
      telefono,
      estado,
      usuarios_roles!inner(
        roles!inner(nombre)
      )
    `)
    .eq('usuarios_roles.roles.nombre', roleName)
    .eq('estado', 'activo')
  
  if (error) throw error
  return data
}
